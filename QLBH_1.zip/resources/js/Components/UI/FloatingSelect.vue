<script setup>

const props = defineProps({

    modelValue: {
        type: [String, Number, null],
        default: '',
    },

    label: {
        type: String,
        required: true,
    },

    options: {
        type: Array,
        default: () => [],
    },

    optionLabel: {
        type: String,
        default: 'label',
    },

    optionValue: {
        type: String,
        default: 'value',
    },

    name: String,
    error: String,
    disabled: { type: Boolean, default: false },
    inputClass: { type: String, default: '' },
    wrapperClass: { type: String, default: '' },
    wrapperStyle: { type: Object, default: null },
    compact: { type: Boolean, default: false },
    hideLabel: { type: Boolean, default: false },
    placeholderText: { type: String, default: 'Chọn...' },
    showPlaceholder: { type: Boolean, default: true },
    floatOnValue: { type: Boolean, default: false },
    createLabel: { type: String, default: '' },
    // true: mục "+ createLabel" nằm cuối danh sách chọn thay vì nút nhỏ bên dưới ô
    createInList: { type: Boolean, default: false },

})

const emit = defineEmits([
    'update:modelValue',
    'create',
])

const CREATE_VALUE = '__create__'

const handleChange = (event) => {

    const selectedValue = event.target.value

    // Chọn mục "+ Thêm ..." trong danh sách: giữ nguyên giá trị đang chọn và báo cho form mở màn hình tạo mới
    if (props.createInList && selectedValue === CREATE_VALUE) {
        event.target.value = props.modelValue ?? ''
        emit('create')
        return
    }

    // Không chọn gì
    if (selectedValue === '') {
        emit('update:modelValue', null)
        return
    }

    /*
    |--------------------------------------------------------------------------
    | Tìm option thật trong mảng options
    |--------------------------------------------------------------------------
    | <select> luôn trả về string.
    | Nhưng options của chúng ta có thể là:
    |
    | id      => number
    | value   => string
    |
    | Vì vậy phải lấy lại giá trị gốc từ options.
    |--------------------------------------------------------------------------
    */

    const selectedOption = props.options.find(
        item => String(item[props.optionValue]) === selectedValue
    )

    if (selectedOption) {
        emit(
            'update:modelValue',
            selectedOption[props.optionValue]
        )
    } else {
        // fallback
        emit('update:modelValue', selectedValue)
    }
}

</script>

<template>

    <div class="relative w-full" :class="wrapperClass" :style="wrapperStyle">

        <select
            :name="name"
            :id="name"
            ref="input"
            :value="modelValue ?? ''"
            :disabled="disabled"
            @change="handleChange"
            class="
                peer
                w-full
                border
                border-gray-300
                rounded-lg
                bg-white
                text-sm
                focus:border-blue-500
                focus:ring-0
                disabled:cursor-not-allowed
                disabled:bg-gray-100
            "
            :class="[
                inputClass,
                compact && hideLabel
                    ? 'px-2.5 py-1 text-xs leading-4'
                    : compact
                    ? 'px-2.5 pt-3 pb-1 text-xs leading-4'
                    : floatOnValue
                    ? (modelValue !== '' && modelValue !== null && modelValue !== undefined ? 'px-2 pt-2.5 pb-2' : 'px-2 py-2')
                    : 'px-2 pt-2.5 pb-2',
            ]"
        >

            <option v-if="showPlaceholder" value="">{{ placeholderText }}</option>

            <option
                v-for="item in options"
                :key="item[optionValue]"
                :value="item[optionValue]"
                
            >
                {{ item[optionLabel] }}
            </option>

            <!-- Dòng hành động (không phải giá trị): có vạch ngăn, nền xanh, chữ đậm để không lẫn với danh sách giá trị -->
            <option v-if="createInList && createLabel" value="" disabled class="fs-create-divider">────────────</option>
            <option v-if="createInList && createLabel" :value="CREATE_VALUE" class="fs-create-option">＋ {{ createLabel }}…</option>

        </select>

        <p
            v-if="error"
            class="text-red-500 text-sm mt-1"
        >
            {{ error }}
        </p>

        <button
            v-if="createLabel && !createInList"
            type="button"
            class="mt-1 inline-flex items-center gap-1 rounded-md border border-blue-200 bg-blue-50 px-2 py-0.5 text-xs font-bold text-blue-700 transition hover:bg-blue-100"
            @click="emit('create')"
        >
            <span aria-hidden="true">＋</span> {{ createLabel }}
        </button>

        <label
            v-if="!hideLabel"
            class="pointer-events-none absolute left-3 bg-white px-1 text-gray-500 transition-all"
            :class="compact
                ? '-top-2 text-[11px] leading-none'
                : floatOnValue
                ? (modelValue !== '' && modelValue !== null && modelValue !== undefined
                    ? '-top-2 text-xs'
                    : 'top-2.5 text-sm peer-focus:-top-2 peer-focus:text-xs peer-focus:text-blue-600')
                : '-top-2 text-xs'"
        >
            {{ label }}
        </label>

    </div>

</template>

<style scoped>
/* Trình duyệt máy tính cho phép tô màu từng <option>; trên di động hiển thị theo giao diện hệ thống nhưng vẫn có dấu ＋ và vạch ngăn. */
.fs-create-option {
    background-color: #eff6ff;
    color: #1d4ed8;
    font-weight: 700;
}
.fs-create-divider {
    color: #94a3b8;
    font-size: 8px;
}
</style>
