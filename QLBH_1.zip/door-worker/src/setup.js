'use strict'
/**
 * Cài worker bằng một lệnh: ghi địa chỉ máy chủ + khóa vào door-worker/.env.
 * Lệnh có sẵn thông tin được hiện ở Cài đặt → Khách hàng → Camera cửa:
 *   npm run setup -- --url http://192.168.1.10/api --key <khóa>
 * Thông tin camera KHÔNG cần khai báo ở đây: worker tự đọc từ Cài đặt.
 */
const fs = require('fs')
const path = require('path')

function parseArgs(argv) {
    const out = { url: '', key: '', help: false }
    for (let i = 0; i < argv.length; i += 1) {
        const arg = argv[i]
        if (arg === '--help' || arg === '-h') out.help = true
        else if (arg === '--url') out.url = argv[++i] || ''
        else if (arg === '--key') out.key = argv[++i] || ''
        else if (arg.startsWith('--url=')) out.url = arg.slice(6)
        else if (arg.startsWith('--key=')) out.key = arg.slice(6)
    }
    return out
}

/** Chuẩn hóa địa chỉ máy chủ: thêm http:// nếu thiếu, bỏ dấu / cuối, đảm bảo kết thúc bằng /api. */
function normalizeApiUrl(raw) {
    let url = String(raw || '').trim().replace(/^["']|["']$/g, '')
    if (!url) return ''
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(url)) url = 'http://' + url
    url = url.replace(/\/+$/, '')
    if (!/\/api$/i.test(url)) url += '/api'
    return url
}

/** Cập nhật/ghi thêm các dòng KEY=VALUE trong nội dung .env, giữ nguyên phần còn lại. */
function upsertEnv(text, values) {
    const lines = String(text || '').split(/\r?\n/)
    const pending = { ...values }
    const result = lines.map((line) => {
        const match = line.match(/^\s*([A-Za-z0-9_]+)\s*=/)
        if (match && Object.prototype.hasOwnProperty.call(pending, match[1])) {
            const value = pending[match[1]]
            delete pending[match[1]]
            return `${match[1]}=${value}`
        }
        return line
    })
    while (result.length && result[result.length - 1] === '') result.pop()
    for (const [name, value] of Object.entries(pending)) result.push(`${name}=${value}`)
    return result.join('\n') + '\n'
}

async function main() {
    const args = parseArgs(process.argv.slice(2))
    if (args.help || (!args.url && !args.key)) {
        console.log('Cách dùng: npm run setup -- --url <địa chỉ máy chủ> --key <khóa>\nLấy sẵn lệnh ở Cài đặt → Khách hàng → Camera cửa.')
        process.exit(args.help ? 0 : 1)
    }

    const apiUrl = normalizeApiUrl(args.url)
    const key = String(args.key || '').trim()
    if (!apiUrl) { console.error('Thiếu --url (địa chỉ máy chủ QLBH).'); process.exit(1) }
    if (key.length < 16) { console.error('Khóa không hợp lệ (quá ngắn). Hãy chép lại đúng lệnh ở Cài đặt → Khách hàng → Camera cửa.'); process.exit(1) }

    const root = path.resolve(__dirname, '..')
    const envFile = path.join(root, '.env')
    const examples = path.join(root, '.env.example')
    const base = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : (fs.existsSync(examples) ? fs.readFileSync(examples, 'utf8') : '')
    fs.writeFileSync(envFile, upsertEnv(base, { API_URL: apiUrl, DOOR_CAMERA_KEY: key }))
    console.log(`Đã ghi ${envFile}\n  API_URL=${apiUrl}\n  DOOR_CAMERA_KEY=${key.slice(0, 4)}…(đã lưu)`)

    // Thử gọi máy chủ để báo ngay nếu sai địa chỉ/khóa (không bắt buộc phải thành công).
    try {
        const { createApi } = require('./api')
        const remote = await createApi({ apiUrl, cameraKey: key }, { timeoutMs: 6000 }).config()
        const camera = remote?.camera?.snapshot_url
        console.log('Kết nối máy chủ: OK.' + (camera ? ` Camera: ${camera}` : ' Chưa nhập địa chỉ camera ở Cài đặt → Khách hàng → Camera cửa.'))
    } catch (error) {
        console.log('Chưa kết nối được máy chủ: ' + error.message + '\n(Kiểm tra máy chủ đang chạy và địa chỉ truy cập được từ máy này. Có thể chạy lại lệnh sau khi sửa.)')
    }

    console.log('\nBước tiếp theo:  npm run check   (thử camera + dò mặt)   rồi   npm start')
}

module.exports = { parseArgs, normalizeApiUrl, upsertEnv }

if (require.main === module) {
    main().catch((error) => { console.error(error?.message || error); process.exit(1) })
}
