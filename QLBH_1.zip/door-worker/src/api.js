'use strict'

class ApiError extends Error {
    constructor(message, status, data) {
        super(message)
        this.name = 'ApiError'
        this.status = status
        this.data = data
    }
}

/** Gọi API của Laravel bằng khóa X-Camera-Key (không cần đăng nhập). */
function createApi(cfg, { timeoutMs = 8000 } = {}) {
    const call = async (method, path, body) => {
        let response
        try {
            response = await fetch(cfg.apiUrl + path, {
                method,
                headers: { 'X-Camera-Key': cfg.cameraKey, Accept: 'application/json', 'Content-Type': 'application/json' },
                body: body === undefined ? undefined : JSON.stringify(body),
                signal: AbortSignal.timeout(timeoutMs),
                redirect: 'manual',
            })
        } catch (error) {
            throw new ApiError('Không gọi được máy chủ: ' + (error?.cause?.code || error?.message || 'lỗi mạng'), 0, null)
        }

        let data = null
        try { data = await response.json() } catch { /* không phải JSON */ }
        if (response.status >= 300 && response.status < 400) {
            throw new ApiError('Máy chủ chuyển hướng (kiểm tra API_URL, có thể thiếu /api hoặc sai http/https).', response.status, data)
        }
        if (!response.ok) throw new ApiError(data?.message || `Máy chủ trả về lỗi ${response.status}`, response.status, data)
        return data
    }

    return {
        heartbeat: payload => call('POST', '/door-camera/heartbeat', payload),
        /** Thông tin camera nhập ở Cài đặt: { enabled, camera: { snapshot_url, auth, username, password }, config_hash } */
        config: () => call('GET', '/door-camera/config'),
        /** faces: [{ key, descriptors: [vector...] }] -> { results: [{ key, matched, customer?, ambiguous? }] } */
        faceMatch: faces => call('POST', '/door-camera/face-match', { faces }),
        record: payload => call('POST', '/door-camera/visits', payload),
        seen: visitId => call('POST', `/door-camera/visits/${visitId}/seen`),
        link: (visitId, customerId) => call('POST', `/door-camera/visits/${visitId}/link`, { customer_id: customerId, consent: false }),
    }
}

module.exports = { createApi, ApiError }
