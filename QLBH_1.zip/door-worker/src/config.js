'use strict'
const path = require('path')

const root = path.resolve(__dirname, '..')
const num = (name, fallback) => {
    const raw = process.env[name]
    if (raw === undefined || raw === '') return fallback
    const value = Number(raw)
    return Number.isFinite(value) ? value : fallback
}

function load() {
    return {
        root,
        apiUrl: (process.env.API_URL || 'http://127.0.0.1:8000/api').replace(/\/+$/, ''),
        cameraKey: process.env.DOOR_CAMERA_KEY || '',
        snapshotUrl: (process.env.CAMERA_SNAPSHOT_URL || '').trim(),
        auth: (process.env.CAMERA_AUTH || 'none').toLowerCase(),
        user: process.env.CAMERA_USER || '',
        password: process.env.CAMERA_PASSWORD || '',
        modelsDir: path.resolve(root, process.env.MODELS_DIR || '../public/models/face'),
        backend: (process.env.TF_BACKEND || 'tfjs-node').toLowerCase(),
        // Camera RTSP (cần ffmpeg)
        ffmpegPath: process.env.FFMPEG_PATH || 'ffmpeg',
        rtspTransport: (process.env.RTSP_TRANSPORT || 'tcp').toLowerCase(),
        rtspFps: num('RTSP_FPS', 2),

        frameIntervalMs: num('FRAME_INTERVAL_MS', 700),
        idleIntervalMs: num('IDLE_INTERVAL_MS', 1000),
        inputSize: num('FACE_INPUT_SIZE', 512),
        scoreThreshold: num('FACE_SCORE_THRESHOLD', 0.5),
        minFacePx: num('MIN_FACE_PX', 80),
        maxFaces: 6,

        // Theo dõi từng người qua các khung hình
        trackTtlMs: 4000, // mặt biến mất quá thời gian này thì bỏ theo dõi
        trackDistanceFactor: 1.0, // tâm mặt dịch chuyển tối đa = hệ số * cạnh lớn của khung mặt
        maxSamples: 4, // số khung nét nhất giữ lại cho mỗi người
        sendSamples: 3, // số khung gửi lên máy chủ để so khớp
        minSamples: 3, // đủ ngần này khung thì so khớp ngay
        maxWaitMs: 2500, // chờ tối đa rồi vẫn so khớp dù chưa đủ khung
        ambiguousRetryMs: 2500,
        unknownRetries: 4, // khách lạ: thử so khớp lại (phòng khi lần đầu ảnh xấu), nếu khớp thì gán lại
        unknownRetryMs: 5000,
        unknownRetryWindowMs: 60000,
        pingMs: 3000, // nhịp báo "người này vẫn ở cửa"
        heartbeatMs: 10000,
        thumbSize: 80,
    }
}

/** Phần cần có trước khi gọi được máy chủ: khóa + địa chỉ (do lệnh "npm run setup" ghi vào .env). */
function validateBase(cfg) {
    const problems = []
    if (!cfg.cameraKey) problems.push('Chưa có khóa camera. Chạy lệnh cài lấy ở Cài đặt → Khách hàng → Camera cửa (npm run setup -- --url ... --key ...).')
    if (!/^https?:\/\//i.test(cfg.apiUrl || '')) problems.push('API_URL phải là địa chỉ http/https của máy chủ QLBH.')
    if (!['tfjs-node', 'wasm'].includes(cfg.backend)) problems.push('TF_BACKEND chỉ nhận: tfjs-node hoặc wasm.')
    return problems
}

/** Thông tin camera (nhập ở Cài đặt → Khách hàng → Camera cửa, worker tự đọc về). */
function validateCamera(cfg) {
    const problems = []
    if (!/^(https?|rtsps?):\/\//i.test(cfg.snapshotUrl || '')) {
        problems.push('Chưa nhập địa chỉ camera (ảnh chụp http/https hoặc RTSP rtsp://) ở Cài đặt → Khách hàng → Camera cửa.')
        return problems
    }
    // Camera RTSP tự xử lý đăng nhập qua tài khoản/mật khẩu nên không cần kiểu đăng nhập.
    if (/^rtsps?:\/\//i.test(cfg.snapshotUrl)) return problems
    if (!['none', 'basic', 'digest'].includes(cfg.auth)) problems.push('Kiểu đăng nhập camera chỉ nhận: không, basic hoặc digest.')
    if (cfg.auth !== 'none' && !cfg.user) problems.push('Kiểu đăng nhập camera là ' + cfg.auth + ' nhưng chưa nhập tài khoản ở Cài đặt.')
    return problems
}

function validate(cfg) {
    return [...validateBase(cfg), ...validateCamera(cfg)]
}

/**
 * Áp thông tin camera lấy từ máy chủ vào cấu hình. Nếu .env của worker còn đặt tay CAMERA_SNAPSHOT_URL
 * (cách cũ) thì giữ nguyên, không ghi đè. Trả về true khi thông tin camera thật sự thay đổi.
 */
function applyRemote(cfg, remote, env = process.env) {
    if (env.CAMERA_SNAPSHOT_URL) return false

    const camera = remote?.camera || {}
    const next = {
        snapshotUrl: String(camera.snapshot_url || '').trim(),
        auth: String(camera.auth || 'none').toLowerCase(),
        user: String(camera.username || ''),
        password: String(camera.password || ''),
    }
    const changed = Object.keys(next).some(key => cfg[key] !== next[key])
    Object.assign(cfg, next)
    return changed
}

module.exports = { load, validate, validateBase, validateCamera, applyRemote }
