'use strict'
const fs = require('fs')
const path = require('path')
const { rgbaToRgb, cropSquare, sharpness } = require('./image')

const MANIFESTS = [
    'tiny_face_detector_model-weights_manifest.json',
    'face_landmark_68_tiny_model-weights_manifest.json',
    'face_recognition_model-weights_manifest.json',
]

/** Nạp face-api cho Node và mô hình từ đĩa. Dùng đúng bộ mô hình trình duyệt đang dùng nên vector khớp với khách đã đăng ký. */
async function createDetector(cfg, log) {
    const missing = MANIFESTS.filter(name => !fs.existsSync(path.join(cfg.modelsDir, name)))
    if (missing.length) {
        throw new Error(`Không thấy mô hình nhận diện trong ${cfg.modelsDir} (thiếu: ${missing.join(', ')}). Chạy "node scripts/copy-face-models.mjs" ở thư mục gốc dự án hoặc đặt MODELS_DIR đúng.`)
    }

    let faceapi
    if (cfg.backend === 'wasm') {
        const tf = require('@tensorflow/tfjs')
        const wasm = require('@tensorflow/tfjs-backend-wasm')
        faceapi = require('@vladmandic/face-api/dist/face-api.node-wasm.js')
        wasm.setWasmPaths(path.dirname(require.resolve('@tensorflow/tfjs-backend-wasm/package.json')) + '/dist/')
        await tf.setBackend('wasm')
        await tf.ready()
    } else {
        require('@tensorflow/tfjs-node')
        faceapi = require('@vladmandic/face-api')
    }
    const tf = faceapi.tf

    await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromDisk(cfg.modelsDir),
        faceapi.nets.faceLandmark68TinyNet.loadFromDisk(cfg.modelsDir),
        faceapi.nets.faceRecognitionNet.loadFromDisk(cfg.modelsDir),
    ])
    log.info(`Đã nạp mô hình nhận diện (backend: ${tf.getBackend()}).`)

    const options = new faceapi.TinyFaceDetectorOptions({ inputSize: cfg.inputSize, scoreThreshold: cfg.scoreThreshold })

    return {
        /**
         * Tìm khuôn mặt trong 1 khung hình { width, height, rgba }.
         * Trả { faces: [{ box, descriptor, sharpness, thumbRgba }], tooSmall } (mặt lớn nhất đứng đầu).
         */
        async detect(frame) {
            const input = tf.tensor3d(rgbaToRgb(frame.rgba, frame.width, frame.height), [frame.height, frame.width, 3], 'int32')
            let results
            try {
                results = await faceapi.detectAllFaces(input, options).withFaceLandmarks(true).withFaceDescriptors()
            } finally {
                input.dispose()
            }

            const faces = []
            let tooSmall = 0
            for (const result of results) {
                const box = result.detection.box
                if (box.width < cfg.minFacePx) { tooSmall += 1; continue }
                const thumbRgba = cropSquare(frame, box, cfg.thumbSize)
                faces.push({
                    box: { x: box.x, y: box.y, width: box.width, height: box.height },
                    descriptor: Array.from(result.descriptor, value => Math.round(value * 1e5) / 1e5),
                    sharpness: sharpness(thumbRgba, cfg.thumbSize),
                    thumbRgba,
                })
            }
            faces.sort((a, b) => b.box.width * b.box.height - a.box.width * a.box.height)

            return { faces: faces.slice(0, cfg.maxFaces), tooSmall }
        },
    }
}

module.exports = { createDetector }
