'use strict'

const center = box => ({ x: box.x + box.width / 2, y: box.y + box.height / 2 })

/**
 * Theo dõi từng người đứng trước camera qua các khung hình và ghi lượt khách lên máy chủ.
 *
 * Vòng đời một người: collecting (gom vài khung nét nhất) -> so khớp với khách đã đăng ký -> ghi lượt
 * (khách quen có customer_id, khách lạ kèm vector để gộp các lần thấy) -> resolved: gửi nhịp "vẫn ở cửa"
 * định kỳ. Khách lạ được thử so khớp lại vài lần; nếu về sau nhận ra là khách quen thì gán lượt cho khách đó.
 */
class Tracker {
    constructor({ api, cfg, log, encodeThumb }) {
        this.api = api
        this.cfg = cfg
        this.log = log
        this.encodeThumb = encodeThumb
        this.tracks = []
        this.nextId = 1
    }

    get count() {
        return this.tracks.length
    }

    /** Ghép các khuôn mặt của khung hình hiện tại vào các người đang theo dõi (không gọi mạng). */
    update(faces, now) {
        const pairs = []
        for (const track of this.tracks) {
            const a = center(track.box)
            faces.forEach((face, index) => {
                const b = center(face.box)
                const distance = Math.hypot(a.x - b.x, a.y - b.y)
                if (distance < this.cfg.trackDistanceFactor * Math.max(track.box.width, track.box.height)) pairs.push({ track, index, distance })
            })
        }
        pairs.sort((x, y) => x.distance - y.distance)

        const usedTracks = new Set()
        const usedFaces = new Set()
        for (const { track, index } of pairs) {
            if (usedTracks.has(track) || usedFaces.has(index)) continue
            usedTracks.add(track)
            usedFaces.add(index)
            this.addSample(track, faces[index], now)
        }

        faces.forEach((face, index) => {
            if (usedFaces.has(index)) return
            const track = {
                id: this.nextId++, box: face.box, firstSeen: now, lastSeen: now, samples: [],
                state: 'collecting', retryAt: 0, ambiguousTries: 0,
                customerId: null, visitId: null, lastPing: 0, matchRetries: 0, nextMatchAt: 0,
            }
            this.addSample(track, face, now)
            this.tracks.push(track)
        })

        this.tracks = this.tracks.filter((track) => {
            if (now - track.lastSeen <= this.cfg.trackTtlMs) return true
            this.log.info(`Người #${track.id} đã rời khỏi khung hình.`)
            return false
        })
    }

    addSample(track, face, now) {
        track.box = face.box
        track.lastSeen = now
        track.samples.push({ descriptor: face.descriptor, sharpness: face.sharpness, thumbRgba: face.thumbRgba })
        track.samples.sort((a, b) => b.sharpness - a.sharpness)
        track.samples.length = Math.min(track.samples.length, this.cfg.maxSamples)
    }

    /** Gọi mạng: so khớp người mới, ghi lượt, thử lại khách lạ, gửi nhịp. */
    async step(now) {
        await this.resolveNew(now)
        await this.retryUnknown(now)
        await this.pingAll(now)
    }

    probes(track) {
        return { key: track.id, descriptors: track.samples.slice(0, this.cfg.sendSamples).map(sample => sample.descriptor) }
    }

    async resolveNew(now) {
        const ready = this.tracks
            .filter(track => track.state === 'collecting' && now >= track.retryAt
                && (track.samples.length >= this.cfg.minSamples || now - track.firstSeen >= this.cfg.maxWaitMs))
            .slice(0, this.cfg.maxFaces)
        if (!ready.length) return

        ready.forEach((track) => { track.state = 'querying' })
        let results
        try {
            const data = await this.api.faceMatch(ready.map(track => this.probes(track)))
            results = data?.results || []
        } catch (error) {
            this.log.warn('So khớp khuôn mặt lỗi: ' + error.message)
            ready.forEach((track) => { track.state = 'collecting'; track.retryAt = now + 3000 })
            return
        }

        for (const track of ready) {
            const result = results.find(item => String(item.key) === String(track.id))
            if (result?.matched && result.customer?.id) {
                await this.record(track, result.customer.id, now)
            } else if (result?.ambiguous && track.ambiguousTries < 2) {
                track.ambiguousTries += 1
                track.state = 'collecting'
                track.retryAt = now + this.cfg.ambiguousRetryMs
            } else {
                await this.record(track, null, now)
            }
        }
    }

    async record(track, customerId, now) {
        const best = track.samples[0]
        const payload = customerId ? { customer_id: customerId } : { descriptor: best.descriptor }
        try {
            payload.thumb = this.encodeThumb(best.thumbRgba, this.cfg.thumbSize)
        } catch { /* ảnh nhỏ chỉ để minh họa, bỏ qua nếu lỗi */ }

        try {
            const data = await this.api.record(payload)
            if (!data?.recorded) {
                // Chưa bật ghi nhận lượt khách trong Cài đặt: thử lại sau.
                track.state = 'collecting'
                track.retryAt = now + 10000
                return
            }
            track.visitId = data.id
            track.customerId = data.customer_id ?? customerId
            track.state = 'resolved'
            track.lastPing = now
            track.nextMatchAt = now + this.cfg.unknownRetryMs
            this.log.info(track.customerId
                ? `Người #${track.id}: khách quen (khách hàng ${track.customerId}), lượt ${track.visitId}.`
                : `Người #${track.id}: khách lạ, lượt ${track.visitId}.`)
        } catch (error) {
            this.log.warn(`Ghi lượt khách lỗi (người #${track.id}): ${error.message}`)
            track.state = 'collecting'
            track.retryAt = now + 3000
        }
    }

    async retryUnknown(now) {
        const due = this.tracks.filter(track => track.state === 'resolved' && !track.customerId && track.visitId
            && track.matchRetries < this.cfg.unknownRetries && now >= track.nextMatchAt
            && now - track.firstSeen < this.cfg.unknownRetryWindowMs)
        if (!due.length) return

        due.forEach((track) => { track.matchRetries += 1; track.nextMatchAt = now + this.cfg.unknownRetryMs })
        let results
        try {
            results = (await this.api.faceMatch(due.map(track => this.probes(track))))?.results || []
        } catch (error) {
            this.log.warn('So khớp lại khách lạ lỗi: ' + error.message)
            return
        }

        for (const track of due) {
            const result = results.find(item => String(item.key) === String(track.id))
            if (!result?.matched || !result.customer?.id) continue
            try {
                await this.api.link(track.visitId, result.customer.id)
                track.customerId = result.customer.id
                this.log.info(`Người #${track.id}: nhận ra là khách hàng ${track.customerId}, gán lại lượt ${track.visitId}.`)
            } catch (error) {
                this.log.warn('Gán lượt cho khách quen lỗi: ' + error.message)
            }
        }
    }

    async pingAll(now) {
        const due = this.tracks.filter(track => track.state === 'resolved' && track.visitId && now - track.lastPing >= this.cfg.pingMs)
        await Promise.all(due.map(async (track) => {
            track.lastPing = now
            try {
                await this.api.seen(track.visitId)
            } catch (error) {
                if (error.status === 404) {
                    // Lượt đã bị xóa (nhân viên xóa hoặc hết hạn): ghi lại lượt mới.
                    track.visitId = null
                    track.state = 'collecting'
                    track.retryAt = now
                } else {
                    this.log.warn(`Gửi nhịp lỗi (người #${track.id}): ${error.message}`)
                }
            }
        }))
    }
}

module.exports = { Tracker }
