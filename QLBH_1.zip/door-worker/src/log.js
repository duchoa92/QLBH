'use strict'
const stamp = () => new Date().toLocaleString('sv-SE').replace('T', ' ')
const write = (level, args) => console[level === 'error' ? 'error' : 'log'](`[${stamp()}] ${level.toUpperCase()}`, ...args)

module.exports = {
    info: (...args) => write('info', args),
    warn: (...args) => write('warn', args),
    error: (...args) => write('error', args),
}
