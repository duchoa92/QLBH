'use strict'
const fs = require('fs')
const path = require('path')
const { loadEnv } = require('./env')

loadEnv(path.resolve(__dirname, '..', '.env'))

const config = require('./config')
const log = require('./log')
const { createApi } = require('./api')
const { createCamera } = require('./camera')
const { isRtsp, maskUrl } = require('./rtsp')
const { decodeJpeg, encodeThumb } = require('./image')
const { createDetector } = require('./detector')
const { Tracker } = require('./tracker')

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

async function check(cfg, api, camera, detector) {
    log.info('Kiểm tra máy chủ…')
    const beat = await api.heartbeat({ camera_ok: true, faces: 0, message: 'kiểm tra' })
    log.info(`Máy chủ OK. Ghi nhận lượt khách trong Cài đặt: ${beat.enabled ? 'ĐANG BẬT' : 'ĐANG TẮT (bật Nhận diện khuôn mặt + Ghi nhận lượt khách)'}.`)

    log.info('Kiểm tra camera…')
    if (!camera) throw new Error(config.validateCamera(cfg).join(' '))
    log.info(`Địa chỉ camera (lấy từ Cài đặt): ${maskUrl(cfg.snapshotUrl)}${isRtsp(cfg.snapshotUrl) ? ' (RTSP, đọc bằng ffmpeg)' : ''}`)
    const buffer = await camera.snapshot()
    const file = path.join(cfg.root, 'last-snapshot.jpg')
    fs.writeFileSync(file, buffer)
    const frame = decodeJpeg(buffer)
    log.info(`Camera OK: ảnh ${frame.width}x${frame.height}, đã lưu ${file} (mở ra xem góc quay).`)

    const started = Date.now()
    const { faces, tooSmall } = await detector.detect(frame)
    log.info(`Dò mặt mất ${Date.now() - started} ms: thấy ${faces.length} mặt đủ lớn, ${tooSmall} mặt quá nhỏ/xa (dưới ${cfg.minFacePx}px).`)
    faces.forEach((face, i) => log.info(`  Mặt ${i + 1}: rộng ${Math.round(face.box.width)}px, độ nét ${face.sharpness.toFixed(0)}`))
}

async function main() {
    const cfg = config.load()
    const checkOnly = process.argv.includes('--check')

    const problems = config.validateBase(cfg)
    if (problems.length) {
        problems.forEach(problem => log.error(problem))
        process.exit(1)
    }

    const api = createApi(cfg)
    let camera = null
    let configHash = null

    // Địa chỉ/tài khoản camera nhập ở Cài đặt; đổi ở đó thì worker tự nạp lại (không cần cài lại).
    const syncConfig = async () => {
        const remote = await api.config()
        const changed = config.applyRemote(cfg, remote)
        configHash = remote.config_hash || null
        const cameraProblems = config.validateCamera(cfg)
        if (changed || !camera) {
            camera?.close?.()
            camera = cameraProblems.length ? null : createCamera(cfg)
        }
        return cameraProblems
    }

    for (;;) {
        try {
            const cameraProblems = await syncConfig()
            cameraProblems.forEach(problem => log.warn(problem))
            break
        } catch (error) {
            const wrongKey = error.status === 401 || error.status === 503
            log.error(error.message + (wrongKey ? ' → Chạy lại lệnh cài lấy ở Cài đặt → Khách hàng → Camera cửa.' : ''))
            if (checkOnly) process.exit(1)
            await sleep(10000)
        }
    }

    const detector = await createDetector(cfg, log)

    if (checkOnly) {
        try {
            await check(cfg, api, camera, detector)
            log.info('Mọi thứ sẵn sàng.')
            camera?.close?.()
            process.exit(0)
        } catch (error) {
            log.error(error.message)
            camera?.close?.()
            process.exit(1)
        }
    }

    const tracker = new Tracker({ api, cfg, log, encodeThumb })
    let enabled = false
    let cameraOk = true
    let message = null
    let faceCount = 0
    let stopping = false
    let lastCameraError = null

    const beat = async () => {
        try {
            const data = await api.heartbeat({ camera_ok: cameraOk, faces: faceCount, message })
            if (enabled !== !!data.enabled) log.info(data.enabled ? 'Bắt đầu xử lý camera cửa.' : 'Tạm dừng: ghi nhận lượt khách đang tắt trong Cài đặt.')
            enabled = !!data.enabled

            if (data.config_hash && configHash && data.config_hash !== configHash) {
                try {
                    const cameraProblems = await syncConfig()
                    log.info('Đã cập nhật thông tin camera từ Cài đặt.')
                    cameraProblems.forEach(problem => log.warn(problem))
                } catch (error) {
                    log.warn('Nạp lại thông tin camera lỗi: ' + error.message)
                }
            }
        } catch (error) {
            log.warn('Báo nhịp lỗi: ' + error.message)
            if (error.status === 401 || error.status === 503) log.error('Khóa không còn đúng: chạy lại lệnh cài lấy ở Cài đặt → Khách hàng → Camera cửa.')
        }
    }

    const stop = () => { stopping = true }
    process.on('SIGINT', stop)
    process.on('SIGTERM', stop)

    log.info(`Worker camera cửa khởi động. Máy chủ: ${cfg.apiUrl}`)
    await beat()
    const heartbeatTimer = setInterval(beat, cfg.heartbeatMs)

    while (!stopping) {
        const startedAt = Date.now()
        if (!enabled) { await sleep(2000); continue }
        if (!camera) {
            cameraOk = false
            message = 'Chưa nhập địa chỉ camera ở Cài đặt → Khách hàng → Camera cửa.'
            await sleep(3000)
            continue
        }

        let frame
        try {
            frame = decodeJpeg(await camera.snapshot())
            cameraOk = true
            message = null
            if (lastCameraError) { log.info('Camera đã hoạt động lại.'); lastCameraError = null }
        } catch (error) {
            cameraOk = false
            message = String(error.message).slice(0, 190)
            if (lastCameraError !== message) { log.error('Camera: ' + message); lastCameraError = message }
            await sleep(3000)
            continue
        }

        try {
            const { faces } = await detector.detect(frame)
            faceCount = faces.length
            const now = Date.now()
            tracker.update(faces, now)
            await tracker.step(now)
        } catch (error) {
            log.error('Xử lý khung hình lỗi: ' + (error?.stack || error))
            await sleep(1000)
        }

        const interval = tracker.count ? cfg.frameIntervalMs : cfg.idleIntervalMs
        await sleep(Math.max(0, interval - (Date.now() - startedAt)))
    }

    clearInterval(heartbeatTimer)
    camera?.close?.()
    log.info('Worker đã dừng.')
    process.exit(0)
}

main().catch((error) => {
    log.error(error?.message || error)
    process.exit(1)
})
