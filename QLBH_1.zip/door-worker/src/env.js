'use strict'
const fs = require('fs')

/** Đọc file .env đơn giản (KEY=VALUE), không ghi đè biến môi trường đã có. */
function loadEnv(file) {
    if (!fs.existsSync(file)) return
    for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
        const line = raw.trim()
        if (!line || line.startsWith('#')) continue
        const match = line.match(/^([A-Za-z0-9_]+)\s*=\s*(.*)$/)
        if (!match) continue
        let value = match[2]
        if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
            value = value.slice(1, -1)
        } else {
            value = value.replace(/\s+#.*$/, '')
        }
        if (process.env[match[1]] === undefined) process.env[match[1]] = value
    }
}

module.exports = { loadEnv }
