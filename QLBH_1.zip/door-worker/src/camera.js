'use strict'
const crypto = require('crypto')
const { isRtsp, createRtspCamera } = require('./rtsp')

const MAX_BYTES = 16 * 1024 * 1024

/** Tách thử thách Digest từ header WWW-Authenticate (có thể kèm cả Basic). */
function parseDigestChallenge(header) {
    const index = String(header || '').search(/digest\s/i)
    if (index < 0) return null
    const body = header.slice(index).replace(/^digest\s+/i, '')
    const out = {}
    const re = /(\w+)=(?:"([^"]*)"|([^,\s]*))/g
    let match
    while ((match = re.exec(body))) out[match[1].toLowerCase()] = match[2] !== undefined ? match[2] : match[3]
    return out.nonce ? out : null
}

/** Tạo header Authorization kiểu Digest (RFC 2617/7616, MD5 hoặc SHA-256). */
function digestHeader({ method, uri, username, password, challenge, nc, cnonce }) {
    const algorithm = challenge.algorithm || 'MD5'
    const upper = algorithm.toUpperCase()
    const hashName = upper.startsWith('SHA-256') ? 'sha256' : 'md5'
    const H = text => crypto.createHash(hashName).update(text).digest('hex')

    let ha1 = H(`${username}:${challenge.realm}:${password}`)
    if (upper.endsWith('-SESS')) ha1 = H(`${ha1}:${challenge.nonce}:${cnonce}`)
    const ha2 = H(`${method}:${uri}`)
    const qop = String(challenge.qop || '').split(',').map(item => item.trim()).includes('auth') ? 'auth' : ''
    const ncText = nc.toString(16).padStart(8, '0')
    const response = qop
        ? H(`${ha1}:${challenge.nonce}:${ncText}:${cnonce}:${qop}:${ha2}`)
        : H(`${ha1}:${challenge.nonce}:${ha2}`)

    const parts = [
        `username="${username}"`,
        `realm="${challenge.realm}"`,
        `nonce="${challenge.nonce}"`,
        `uri="${uri}"`,
        `algorithm=${algorithm}`,
        `response="${response}"`,
    ]
    if (qop) parts.push(`qop=${qop}`, `nc=${ncText}`, `cnonce="${cnonce}"`)
    if (challenge.opaque) parts.push(`opaque="${challenge.opaque}"`)

    return 'Digest ' + parts.join(', ')
}

function createHttpCamera(cfg, { timeoutMs = 6000 } = {}) {
    const url = new URL(cfg.snapshotUrl)
    const uri = url.pathname + url.search
    let challenge = null
    let nc = 0

    const request = async (authorization) => {
        const headers = { Accept: 'image/jpeg,image/*' }
        if (authorization) headers.Authorization = authorization
        return fetch(cfg.snapshotUrl, { headers, redirect: 'manual', signal: AbortSignal.timeout(timeoutMs) })
    }

    const digestAuthorization = () => {
        nc += 1
        return digestHeader({
            method: 'GET', uri, username: cfg.user, password: cfg.password, challenge, nc,
            cnonce: crypto.randomBytes(8).toString('hex'),
        })
    }

    const fetchResponse = async () => {
        if (cfg.auth === 'basic') {
            return request('Basic ' + Buffer.from(`${cfg.user}:${cfg.password}`).toString('base64'))
        }
        if (cfg.auth !== 'digest') return request(null)

        let response = await request(challenge ? digestAuthorization() : null)
        if (response.status === 401) {
            const fresh = parseDigestChallenge(response.headers.get('www-authenticate'))
            if (!fresh) throw new Error('Camera yêu cầu đăng nhập nhưng không phải kiểu Digest. Thử đổi kiểu đăng nhập sang basic ở Cài đặt → Khách hàng → Camera cửa.')
            challenge = fresh
            nc = 0
            response = await request(digestAuthorization())
        }
        return response
    }

    return {
        /** Lấy 1 ảnh JPEG từ camera. */
        async snapshot() {
            let response
            try {
                response = await fetchResponse()
            } catch (error) {
                if (error?.name === 'TimeoutError' || error?.name === 'AbortError') throw new Error('Camera không phản hồi (quá thời gian chờ).')
                if (error?.message?.includes('Digest') || error?.message?.includes('basic')) throw error
                throw new Error('Không kết nối được camera: ' + (error?.cause?.code || error?.message || 'lỗi mạng'))
            }
            if (response.status === 401 || response.status === 403) throw new Error(`Camera từ chối đăng nhập (${response.status}). Kiểm tra tài khoản, mật khẩu và kiểu đăng nhập camera ở Cài đặt → Khách hàng → Camera cửa.`)
            if (!response.ok) throw new Error(`Camera trả về lỗi ${response.status}. Kiểm tra địa chỉ ảnh chụp camera ở Cài đặt.`)

            const buffer = Buffer.from(await response.arrayBuffer())
            if (buffer.length === 0 || buffer.length > MAX_BYTES) throw new Error('Ảnh camera rỗng hoặc quá lớn.')
            if (buffer[0] !== 0xff || buffer[1] !== 0xd8) {
                throw new Error(`Địa chỉ này không trả về ảnh JPEG (Content-Type: ${response.headers.get('content-type') || 'không rõ'}). Cần địa chỉ ảnh chụp tĩnh.`)
            }
            return buffer
        },
    }
}

/** Địa chỉ http/https: ảnh chụp tĩnh. Địa chỉ rtsp/rtsps: luồng video đọc bằng ffmpeg. */
function createCamera(cfg, options) {
    return isRtsp(cfg.snapshotUrl) ? createRtspCamera(cfg, options) : createHttpCamera(cfg, options)
}

module.exports = { createCamera, parseDigestChallenge, digestHeader }
