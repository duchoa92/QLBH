'use strict'
/**
 * Camera RTSP: dùng ffmpeg đọc luồng và xuất ra các khung JPEG liên tiếp (một kết nối duy nhất, nhẹ hơn
 * mở lại luồng cho mỗi ảnh). Chỉ chạy ffmpeg khi có người cần ảnh và tự dừng khi không dùng nữa.
 */
const { spawn: nodeSpawn } = require('child_process')

const SOI = Buffer.from([0xff, 0xd8])
const EOI = Buffer.from([0xff, 0xd9])

const isRtsp = url => /^rtsps?:\/\//i.test(String(url || '').trim())

/** Ẩn tài khoản:mật khẩu trong địa chỉ để không lọt vào nhật ký/thông báo lỗi. */
function maskUrl(text) {
    return String(text || '').replace(/(\b[a-z][a-z0-9+.-]*:\/\/)[^\s/@]*@/gi, '$1***@')
}

/** Ghép tài khoản/mật khẩu (nhập ở Cài đặt) vào địa chỉ RTSP nếu địa chỉ chưa có. */
function buildRtspUrl(rawUrl, user, password) {
    const url = new URL(String(rawUrl).trim())
    if (user && !url.username) {
        url.username = user
        url.password = password || ''
    }
    return url.toString()
}

/** Tách các ảnh JPEG nối liền nhau trong luồng đầu ra của ffmpeg (có thể bị cắt giữa chừng). */
class JpegSplitter {
    constructor(maxBytes = 16 * 1024 * 1024) {
        this.buffer = Buffer.alloc(0)
        this.maxBytes = maxBytes
    }

    push(chunk) {
        const frames = []
        this.buffer = this.buffer.length ? Buffer.concat([this.buffer, chunk]) : chunk
        for (;;) {
            const start = this.buffer.indexOf(SOI)
            if (start < 0) {
                // Có thể đầu ảnh (FF D8) bị cắt đôi giữa hai đoạn dữ liệu: giữ lại byte FF cuối.
                this.buffer = this.buffer.length && this.buffer[this.buffer.length - 1] === 0xff ? this.buffer.subarray(this.buffer.length - 1) : Buffer.alloc(0)
                break
            }
            if (start > 0) this.buffer = this.buffer.subarray(start)
            const end = this.buffer.indexOf(EOI, 2)
            if (end < 0) {
                if (this.buffer.length > this.maxBytes) this.buffer = Buffer.alloc(0)
                break
            }
            frames.push(Buffer.from(this.buffer.subarray(0, end + 2)))
            this.buffer = this.buffer.subarray(end + 2)
        }
        return frames
    }
}

function ffmpegArgs(cfg, url) {
    const args = ['-hide_banner', '-loglevel', 'error', '-nostdin']
    if (isRtsp(url)) args.push('-rtsp_transport', cfg.rtspTransport === 'udp' ? 'udp' : 'tcp')
    args.push('-i', url, '-an', '-vf', `fps=${Number(cfg.rtspFps) > 0 ? Number(cfg.rtspFps) : 2}`, '-q:v', '3', '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1')
    return args
}

/** Chuyển lỗi của ffmpeg thành thông báo dễ hiểu bằng tiếng Việt. */
function describeFfmpegError(stderr, code) {
    const text = maskUrl(stderr).trim()
    if (/401|unauthorized|authorization failed/i.test(text)) return 'Camera từ chối đăng nhập (RTSP 401). Kiểm tra tài khoản và mật khẩu ở Cài đặt → Khách hàng → Camera cửa.'
    if (/403|forbidden/i.test(text)) return 'Camera từ chối truy cập (RTSP 403). Kiểm tra quyền của tài khoản camera.'
    if (/404|not found/i.test(text)) return 'Camera không có luồng ở đường dẫn này (RTSP 404). Kiểm tra lại địa chỉ RTSP theo hãng camera.'
    if (/connection refused|connection timed out|timed out|no route to host|network is unreachable|could not resolve|name or service not known|failed to resolve/i.test(text)) {
        return 'Không kết nối được camera RTSP. Kiểm tra địa chỉ IP, cổng (thường 554) và mạng giữa máy này với camera.'
    }
    if (/invalid data found|server returned|method describe failed|unsupported/i.test(text)) return 'Camera trả về dữ liệu RTSP không đọc được: ' + text.split(/\r?\n/).pop().slice(0, 160)
    const last = text.split(/\r?\n/).filter(Boolean).pop()
    return last ? 'ffmpeg báo lỗi: ' + last.slice(0, 180) : `ffmpeg dừng bất ngờ (mã ${code ?? '?'}). Kiểm tra địa chỉ RTSP.`
}

function ffmpegMissing(cfg) {
    return new Error(`Chưa cài ffmpeg trên máy chạy worker (cần để đọc camera RTSP). Ubuntu: sudo apt install ffmpeg. Windows: tải ffmpeg, thêm vào PATH hoặc đặt FFMPEG_PATH trong door-worker/.env (đang tìm "${cfg.ffmpegPath || 'ffmpeg'}").`)
}

function createRtspCamera(cfg, { spawn = nodeSpawn, restartDelayMs = 2000, frameTimeoutMs = 8000, idleStopMs = 15000, staleMs = 5000 } = {}) {
    const url = buildRtspUrl(cfg.snapshotUrl, cfg.user, cfg.password)

    let child = null
    let closed = false
    let splitter = new JpegSplitter()
    let latest = null
    let latestSeq = 0
    let latestAt = 0
    let servedSeq = 0
    let lastError = null
    let restartTimer = null
    let idleTimer = null
    const waiters = []

    const flush = (error, frame) => {
        while (waiters.length) {
            const waiter = waiters.shift()
            clearTimeout(waiter.timer)
            if (error) waiter.reject(error)
            else waiter.resolve(frame)
        }
    }

    const stopProcess = () => {
        clearTimeout(restartTimer)
        restartTimer = null
        const proc = child
        child = null
        latest = null
        if (proc) { try { proc.kill('SIGKILL') } catch { /* đã thoát */ } }
    }

    const scheduleRestart = () => {
        if (closed || restartTimer) return
        restartTimer = setTimeout(() => { restartTimer = null; start() }, restartDelayMs)
        restartTimer.unref?.()
    }

    const onFrame = (frame) => {
        latest = frame
        latestSeq += 1
        latestAt = Date.now()
        lastError = null
        if (waiters.length) servedSeq = latestSeq // có người đang đợi thì khung này coi như đã giao
        flush(null, frame)
    }

    function start() {
        if (closed || child) return
        splitter = new JpegSplitter()
        let stderr = ''
        let finished = false
        let proc
        try {
            proc = spawn(cfg.ffmpegPath || 'ffmpeg', ffmpegArgs(cfg, url), { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
        } catch (error) {
            lastError = error?.code === 'ENOENT' ? ffmpegMissing(cfg) : new Error('Không chạy được ffmpeg: ' + maskUrl(error?.message))
            flush(lastError)
            return
        }
        child = proc

        const end = (error) => {
            if (finished) return
            finished = true
            if (child === proc) child = null
            if (closed) return
            lastError = error
            latest = null
            flush(error)
            scheduleRestart()
        }

        proc.stdout.on('data', (chunk) => { for (const frame of splitter.push(chunk)) onFrame(frame) })
        proc.stderr.on('data', (data) => { stderr = (stderr + data).slice(-1500) })
        proc.on('error', error => end(error?.code === 'ENOENT' ? ffmpegMissing(cfg) : new Error('Không chạy được ffmpeg: ' + maskUrl(error?.message))))
        proc.on('close', code => end(new Error(describeFfmpegError(stderr, code))))
    }

    const touch = () => {
        clearTimeout(idleTimer)
        idleTimer = setTimeout(stopProcess, idleStopMs)
        idleTimer.unref?.()
    }

    return {
        /** Trả về khung JPEG mới nhất (đợi khung mới nếu chưa có). */
        async snapshot() {
            if (closed) throw new Error('Camera đã đóng.')
            touch()

            if (latest && servedSeq !== latestSeq && Date.now() - latestAt <= staleMs) {
                servedSeq = latestSeq
                return latest
            }
            // ffmpeg vừa lỗi và đang chờ khởi động lại: báo lỗi ngay để nơi gọi ghi nhận.
            if (!child && lastError && restartTimer) throw lastError

            start()
            if (!child && lastError) throw lastError

            return new Promise((resolve, reject) => {
                const waiter = { resolve, reject, timer: null }
                waiter.timer = setTimeout(() => {
                    const index = waiters.indexOf(waiter)
                    if (index >= 0) waiters.splice(index, 1)
                    reject(lastError || new Error('Camera RTSP không phản hồi (quá thời gian chờ). Kiểm tra địa chỉ, tài khoản và mạng.'))
                }, frameTimeoutMs)
                waiters.push(waiter)
            })
        },

        close() {
            closed = true
            clearTimeout(idleTimer)
            stopProcess()
            flush(new Error('Camera đã đóng.'))
        },
    }
}

module.exports = { isRtsp, maskUrl, buildRtspUrl, JpegSplitter, ffmpegArgs, describeFfmpegError, createRtspCamera }
