'use strict'

/** Giải mã JPEG thành RGBA (jpeg-js: thuần JavaScript, không cần biên dịch). */
function decodeJpeg(buffer) {
    const jpeg = require('jpeg-js')
    const { width, height, data } = jpeg.decode(buffer, { useTArray: true, formatAsRGBA: true, maxMemoryUsageInMB: 1024 })
    return { width, height, rgba: data }
}

function rgbaToRgb(rgba, width, height) {
    const rgb = new Uint8Array(width * height * 3)
    for (let i = 0, j = 0; i < rgb.length; i += 3, j += 4) {
        rgb[i] = rgba[j]
        rgb[i + 1] = rgba[j + 1]
        rgb[i + 2] = rgba[j + 2]
    }
    return rgb
}

/**
 * Cắt vùng quanh khuôn mặt thành ảnh vuông size x size (RGBA), lấy trung bình điểm ảnh khi thu nhỏ.
 * Chừa viền quanh mặt cho dễ nhận ra người; điểm nằm ngoài khung hình lấy theo mép.
 */
function cropSquare(frame, box, size = 80, margin = 0.25) {
    const side = Math.max(box.width, box.height) * (1 + margin * 2)
    const cx = box.x + box.width / 2
    const cy = box.y + box.height / 2
    const x0 = cx - side / 2
    const y0 = cy - side / 2
    const step = side / size
    const out = new Uint8Array(size * size * 4)
    const clampX = value => Math.min(frame.width - 1, Math.max(0, value))
    const clampY = value => Math.min(frame.height - 1, Math.max(0, value))

    for (let oy = 0; oy < size; oy += 1) {
        const sy0 = Math.floor(y0 + oy * step)
        const sy1 = Math.max(sy0, Math.ceil(y0 + (oy + 1) * step) - 1)
        const stepY = Math.max(1, Math.floor((sy1 - sy0 + 1) / 4))
        for (let ox = 0; ox < size; ox += 1) {
            const sx0 = Math.floor(x0 + ox * step)
            const sx1 = Math.max(sx0, Math.ceil(x0 + (ox + 1) * step) - 1)
            const stepX = Math.max(1, Math.floor((sx1 - sx0 + 1) / 4))
            let r = 0
            let g = 0
            let b = 0
            let n = 0
            for (let sy = sy0; sy <= sy1; sy += stepY) {
                const row = clampY(sy) * frame.width
                for (let sx = sx0; sx <= sx1; sx += stepX) {
                    const p = (row + clampX(sx)) * 4
                    r += frame.rgba[p]
                    g += frame.rgba[p + 1]
                    b += frame.rgba[p + 2]
                    n += 1
                }
            }
            const o = (oy * size + ox) * 4
            out[o] = r / n
            out[o + 1] = g / n
            out[o + 2] = b / n
            out[o + 3] = 255
        }
    }
    return out
}

/** Độ nét của ảnh vuông RGBA: phương sai Laplacian trên ảnh xám (ảnh mờ/rung cho giá trị thấp). */
function sharpness(rgba, size) {
    const gray = new Float32Array(size * size)
    for (let i = 0; i < gray.length; i += 1) {
        const p = i * 4
        gray[i] = 0.299 * rgba[p] + 0.587 * rgba[p + 1] + 0.114 * rgba[p + 2]
    }
    let sum = 0
    let sumSquares = 0
    let count = 0
    for (let row = 1; row < size - 1; row += 1) {
        for (let col = 1; col < size - 1; col += 1) {
            const i = row * size + col
            const laplacian = gray[i - 1] + gray[i + 1] + gray[i - size] + gray[i + size] - 4 * gray[i]
            sum += laplacian
            sumSquares += laplacian * laplacian
            count += 1
        }
    }
    const mean = sum / count
    return sumSquares / count - mean * mean
}

/** Mã hóa ảnh vuông RGBA thành data URI JPEG (máy chủ yêu cầu đúng dạng data:image/jpeg;base64,...). */
function encodeThumb(rgba, size, quality = 80) {
    const jpeg = require('jpeg-js')
    const { data } = jpeg.encode({ data: Buffer.from(rgba.buffer, rgba.byteOffset, rgba.byteLength), width: size, height: size }, quality)
    return 'data:image/jpeg;base64,' + Buffer.from(data).toString('base64')
}

module.exports = { decodeJpeg, rgbaToRgb, cropSquare, sharpness, encodeThumb }
