# Worker camera cửa

Chương trình chạy nền: lấy ảnh từ camera IP ở cửa, nhận diện khuôn mặt, ghi lượt khách vào QLBH. **Không cần mở POS hay trình duyệt**; trang "Lượt khách ra vào" vẫn tăng số liệu, còn POS chỉ hiện danh sách khách đang đứng ở cửa.

```
Camera IP ─► worker (Node, chạy nền) ─► Laravel (/api/door-camera/*) ◄─ POS / trang thống kê
```

## 1. Phía Laravel (làm một lần)

1. Chạy `php artisan migrate` (thêm cột "đã phục vụ" cho lượt khách).
2. Build lại giao diện (`npm run build`) vì POS và trang Cài đặt có sửa.
3. Vào **Cài đặt → Khách hàng**: bật *Nhận diện khuôn mặt*, *Ghi nhận lượt khách ra vào*, rồi *Dùng camera cửa*.
   - Điền **địa chỉ ảnh chụp tĩnh** của camera (và tài khoản/mật khẩu nếu có) ngay tại mục camera ở đó.
   - Hệ thống **tự tạo khóa** và hiện sẵn lệnh cài worker (đã điền địa chỉ máy chủ + khóa). **Không cần sửa `.env` của Laravel.**
   - Biến `DOOR_CAMERA_KEY` trong `.env` chỉ còn là tùy chọn nếu bạn muốn tự đặt khóa cố định.

## 2. Cài worker (trên máy chạy nền, cùng mạng với camera)

Cần Node.js (khuyên dùng bản LTS 20; nếu `npm install` báo lỗi `@tensorflow/tfjs-node` thì thử Node 18/20, hoặc dùng `TF_BACKEND=wasm`).

Chép lệnh hiện ở Cài đặt rồi chạy trong thư mục dự án, dạng:

```
cd door-worker
npm install
npm run setup -- --url http://<máy-chủ>/api --key <khóa>
npm run check       # thử máy chủ + camera + dò mặt, lưu last-snapshot.jpg để xem góc quay
npm start
```

- `npm run setup` ghi địa chỉ máy chủ + khóa vào `door-worker/.env` và thử gọi máy chủ để báo ngay nếu sai.
- **Thông tin camera không phải khai báo ở worker.** Worker tự đọc từ Cài đặt, và tự nạp lại trong khoảng 10 giây khi bạn đổi địa chỉ/tài khoản camera ở đó (không cần khởi động lại).
- Worker chạy ở máy khác máy chủ Laravel thì dùng địa chỉ máy chủ mà máy đó truy cập được (ví dụ `http://192.168.1.10/api`).
- Mô hình nhận diện lấy từ `public/models/face` của dự án (đã dùng cho trình duyệt).
- `npm test` chạy test phần logic (không cần camera).

## 3. Chạy nền

- **Windows (máy cá nhân hiện tại):** dùng `npm start` trong một cửa sổ, hoặc `npm i -g pm2` rồi `pm2 start src/index.js --name door-worker` (+ `pm2-windows-startup` nếu muốn tự chạy khi bật máy).
- **Ubuntu (máy riêng):** dùng `door-worker.service` (hướng dẫn ở đầu file đó). Máy khởi động lại là worker tự chạy lại, lỗi thì tự khởi động lại sau 5 giây.

## 4. Camera: RTSP hoặc ảnh chụp http

Ở Cài đặt → Khách hàng → Camera cửa, ô địa chỉ camera nhận **hai kiểu**:

| Kiểu | Ví dụ | Ghi chú |
|---|---|---|
| **RTSP** (luồng video) | Hikvision `rtsp://IP:554/Streaming/Channels/101`, Dahua `rtsp://IP:554/cam/realmonitor?channel=1&subtype=0` | Cần **ffmpeg** trên máy chạy worker. Tài khoản/mật khẩu nhập ở ô bên dưới (hoặc dán nguyên `rtsp://user:pass@IP/...`, hệ thống tự tách và mã hóa mật khẩu). |
| Ảnh chụp tĩnh http | Hikvision `http://IP/ISAPI/Streaming/channels/101/picture`, Dahua `http://IP/cgi-bin/snapshot.cgi` | Không cần ffmpeg. Kiểu đăng nhập: không / basic / digest. Dùng được cả khi đăng ký khuôn mặt từ camera trong trang Khách hàng. |

**Cài ffmpeg:** Ubuntu `sudo apt install ffmpeg`; Windows tải ffmpeg, thêm thư mục `bin` vào PATH (hoặc đặt `FFMPEG_PATH=C:\\ffmpeg\\bin\\ffmpeg.exe` trong `door-worker/.env`). Kiểm tra bằng `ffmpeg -version`.

Với RTSP, worker chạy **một** tiến trình ffmpeg giữ kết nối tới camera và lấy khoảng 2 khung hình/giây (đổi bằng `RTSP_FPS`), tự chạy lại nếu camera rớt mạng, tự dừng khi không dùng. Mặc định dùng TCP cho ổn định (`RTSP_TRANSPORT=udp` nếu camera chỉ hỗ trợ UDP).

Lưu ý khi chọn luồng RTSP:
- **Luồng chính** (ví dụ `/101`, `subtype=0`) rõ hơn nên dò được mặt nhỏ/xa, nhưng giải mã tốn CPU hơn. Luồng phụ (`/102`, `subtype=1`) nhẹ nhưng mặt ở xa có thể bị bỏ qua. Nếu thấy chậm, thử luồng phụ hoặc giảm `FACE_INPUT_SIZE`.
- Dạng nén H.265 vẫn đọc được nếu ffmpeg của bạn hỗ trợ; nếu lỗi, đổi camera sang H.264.

## 5. Gợi ý lắp camera

- Mặt khách cần rộng từ khoảng 80–100px trở lên trong ảnh gốc (đặt `MIN_FACE_PX`). Camera 2MP trở lên, lắp ngang tầm mặt, hướng vào người đi vào, tránh ngược sáng.
- Chạy `npm run check` khi có người đứng ở cửa để xem số mặt thấy được và độ rộng từng mặt.
- Mặt xa không dò được: tăng `FACE_INPUT_SIZE` (512 → 608) hoặc đưa camera lại gần, đổi lại tốn CPU hơn.

## 6. Khi có sự cố

| Dấu hiệu | Cách xử lý |
|---|---|
| Trang Lượt khách / Cài đặt báo "Worker chưa chạy" | Worker không gửi nhịp: xem nhật ký, chạy lại lệnh cài ở Cài đặt (đúng địa chỉ máy chủ + khóa) |
| `Khóa camera không hợp lệ` / `Chưa có khóa camera` | Khóa cũ hết hiệu lực (có thể do bấm *Tạo khóa mới*): chép lại lệnh cài mới ở Cài đặt và chạy lại |
| `Camera từ chối đăng nhập` | Sai tài khoản/mật khẩu hoặc kiểu đăng nhập ở Cài đặt (thử digest ↔ basic) |
| `không trả về ảnh JPEG` | Địa chỉ http không phải ảnh chụp tĩnh; xem địa chỉ snapshot của hãng camera (hoặc dùng địa chỉ RTSP) |
| `Chưa cài ffmpeg` | Camera RTSP cần ffmpeg trên máy chạy worker (xem mục 4) |
| `Không kết nối được camera RTSP` / `RTSP 404` | Sai IP, cổng 554, hoặc đường dẫn luồng; thử mở cùng link bằng VLC để kiểm tra |
| Worker chạy nhưng không có lượt mới | Cài đặt chưa bật *Nhận diện khuôn mặt* + *Ghi nhận lượt khách*; hoặc mặt quá nhỏ/xa |

Worker lấy khoảng 1–2 khung hình/giây (từ ảnh chụp http hoặc luồng RTSP) là đủ cho một cửa.
