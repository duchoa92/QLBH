<?php

namespace App\Http\Requests\Category;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $category = $this->route('category');
        // route('category') là Model (route model binding) nên phải lấy khóa chính, không ép (int) trực tiếp.
        $categoryId = $category instanceof \Illuminate\Database\Eloquent\Model ? $category->getKey() : $category;

        return [
            // Không được chọn chính nó làm cha
            'parent_id' => [
                'nullable',
                'integer',
                'exists:categories,id',
                function ($attribute, $value, $fail) use ($categoryId) {
                    if ($value && (int) $value === (int) $categoryId) {
                        $fail('Danh mục cha không được là chính nó');
                    }
                },
            ],
            'name' => [
                'required',
                'string',
                'max:255',
            ],
            'sort_order' => [
                'nullable',
                'integer',
                'min:0',
            ],
            'is_active' => [
                'boolean',
            ],
            
            'attributes' => [
                'nullable',
                'array',
            ],

            'attributes.*.name' => [
                'required',
                'string',
            ],

            'attributes.*.options' => [
                'nullable',
                'array',
            ],

            'attributes.*.options.*' => [
                'nullable',
                'string',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required'    => 'Vui lòng nhập tên danh mục',
            'parent_id.exists' => 'Danh mục cha không hợp lệ',
        ];
    }
}
