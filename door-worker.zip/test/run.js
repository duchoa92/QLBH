'use strict'
const assert = require('assert')
const http = require('http')
const { digestHeader, parseDigestChallenge, createCamera } = require('../src/camera')
const { cropSquare, sharpness, encodePreview } = require('../src/image')
const { Tracker } = require('../src/tracker')
const { createApi } = require('../src/api')
const config = require('../src/config')

const tests = []
const test = (name, fn) => tests.push({ name, fn })
const quiet = { info() {}, warn() {}, error() {} }

/* ---------------- Digest ---------------- */
test('Digest khớp ví dụ chuẩn RFC 2617', () => {
    const header = digestHeader({
        method: 'GET', uri: '/dir/index.html', username: 'Mufasa', password: 'Circle Of Life',
        challenge: { realm: 'testrealm@host.com', nonce: 'dcd98b7102dd2f0e8b11d0f600bfb0c093', qop: 'auth', opaque: '5ccc069c403ebaf9f0171e9517f40e41', algorithm: 'MD5' },
        nc: 1, cnonce: '0a4f113b',
    })
    assert.ok(header.includes('response="6629fae49393a05397450978507c4ef1"'), header)
})

test('Tách thử thách Digest khi header có cả Basic', () => {
    const ch = parseDigestChallenge('Basic realm="x", Digest realm="cam", nonce="abc123", qop="auth", algorithm=MD5')
    assert.strictEqual(ch.realm, 'cam')
    assert.strictEqual(ch.nonce, 'abc123')
    assert.strictEqual(ch.qop, 'auth')
})

/* ---------------- Ảnh ---------------- */
test('cropSquare ra đúng kích thước và sharpness phân biệt ảnh phẳng/ảnh nét', () => {
    const w = 200, h = 200
    const rgba = new Uint8Array(w * h * 4)
    for (let y = 0; y < h; y += 1) for (let x = 0; x < w; x += 1) {
        const p = (y * w + x) * 4
        const v = ((x >> 1) + (y >> 1)) % 2 ? 255 : 0 // bàn cờ 2px
        rgba[p] = rgba[p + 1] = rgba[p + 2] = v
        rgba[p + 3] = 255
    }
    const sharp = cropSquare({ width: w, height: h, rgba }, { x: 60, y: 60, width: 40, height: 40 }, 64, 0)
    assert.strictEqual(sharp.length, 64 * 64 * 4)
    const flat = new Uint8Array(64 * 64 * 4).fill(128)
    assert.ok(sharpness(sharp, 64) > sharpness(flat, 64) + 1)
    assert.strictEqual(sharpness(flat, 64), 0)
    // mặt sát mép khung hình không làm hỏng (lấy theo mép)
    const edge = cropSquare({ width: w, height: h, rgba }, { x: 190, y: 190, width: 40, height: 40 }, 32)
    assert.strictEqual(edge.length, 32 * 32 * 4)
})

test('encodePreview thu nhỏ khung hình và ra JPEG hợp lệ nhỏ gọn', () => {
    const w = 1280, h = 720
    const rgba = new Uint8Array(w * h * 4).fill(120)
    const jpeg = encodePreview({ width: w, height: h, rgba }, 480)
    assert.strictEqual(jpeg[0], 0xff)
    assert.strictEqual(jpeg[1], 0xd8)
    const out = require('jpeg-js').decode(jpeg)
    assert.strictEqual(out.width, 480)
    assert.strictEqual(out.height, 270)
    assert.ok(jpeg.length < 400 * 1024)
    const small = require('jpeg-js').decode(encodePreview({ width: 100, height: 50, rgba: new Uint8Array(100 * 50 * 4) }, 480))
    assert.strictEqual(small.width, 100) // không phóng to
})

test('DETECT_ROI: đọc đúng, bỏ giá trị sai; ffmpeg có bước crop và ảnh xem trước thu nhỏ', () => {
    process.env.DETECT_ROI = '0.2,0.1,0.6,0.8'
    assert.deepStrictEqual(config.load().detectRoi, { x: 0.2, y: 0.1, w: 0.6, h: 0.8 })
    for (const bad of ['1,1,1,1', 'a,b,c,d', '0.5,0.5', '0,0,0.01,0.5']) {
        process.env.DETECT_ROI = bad
        assert.strictEqual(config.load().detectRoi, null, bad)
    }
    delete process.env.DETECT_ROI
    const rtsp = require('../src/rtsp')
    const withRoi = rtsp.ffmpegArgs({ rtspTransport: 'tcp', rtspFps: 4, detectRoi: { x: 0.2, y: 0.1, w: 0.6, h: 0.8 } }, 'rtsp://h/x')
    assert.ok(withRoi[withRoi.indexOf('-vf') + 1].startsWith('crop='))
    const noRoi = rtsp.ffmpegArgs({ rtspTransport: 'tcp', rtspFps: 4, detectRoi: null }, 'rtsp://h/x')
    assert.strictEqual(noRoi[noRoi.indexOf('-vf') + 1], 'fps=4')
    const { previewArgs } = require('../src/preview')
    const args = previewArgs({ previewFps: 5, previewWidth: 480, rtspTransport: 'tcp' }, 'rtsp://h/x')
    assert.strictEqual(args[args.indexOf('-vf') + 1], 'fps=5,scale=480:-2')
})

test('applyRemote: thông số tinh chỉnh từ Cài đặt ưu tiên hơn .env, đổi thì báo thay đổi', () => {
    const cfg = { snapshotUrl: 'rtsp://h/x', auth: 'none', user: '', password: '', minFacePx: 80, rtspFps: 2, frameIntervalMs: 700, previewFps: 5, previewWidth: 480, detectRoi: null }
    const remote = { camera: { snapshot_url: 'rtsp://h/x' }, tuning: { min_face_px: 50, detect_fps: 6, detect_interval_ms: 250, preview_fps: 8, preview_width: 640, detect_roi: { x: 0.1, y: 0.2, w: 0.5, h: 0.6 } } }
    assert.strictEqual(config.applyRemote(cfg, remote, {}), true)
    assert.strictEqual(cfg.minFacePx, 50)
    assert.strictEqual(cfg.rtspFps, 6)
    assert.strictEqual(cfg.frameIntervalMs, 250)
    assert.deepStrictEqual(cfg.detectRoi, { x: 0.1, y: 0.2, w: 0.5, h: 0.6 })
    assert.strictEqual(config.applyRemote(cfg, remote, {}), false) // không đổi gì thì không báo
    remote.tuning.detect_roi = null
    assert.strictEqual(config.applyRemote(cfg, remote, {}), true)
    assert.strictEqual(cfg.detectRoi, null)
    const old = { snapshotUrl: 'rtsp://h/x', auth: 'none', user: '', password: '', minFacePx: 80 }
    assert.strictEqual(config.applyRemote(old, { camera: { snapshot_url: 'rtsp://h/x' } }, {}), false) // máy chủ cũ không gửi tuning: giữ nguyên
    assert.strictEqual(old.minFacePx, 80)
})

/* ---------------- Bộ dò mặt ---------------- */
test('config: backend mặc định là auto, chấp nhận auto/tfjs-node/wasm và từ chối giá trị lạ', () => {
    delete process.env.TF_BACKEND
    assert.strictEqual(config.load().backend, 'auto')
    for (const backend of ['auto', 'tfjs-node', 'wasm']) {
        assert.deepStrictEqual(config.validateBase({ cameraKey: 'k', apiUrl: 'http://x/api', backend }), [])
    }
    assert.strictEqual(config.validateBase({ cameraKey: 'k', apiUrl: 'http://x/api', backend: 'cuda' }).length, 1)
})

test('createDetector báo rõ khi thiếu mô hình (trước khi nạp TensorFlow)', async () => {
    const { createDetector } = require('../src/detector')
    await assert.rejects(
        () => createDetector({ ...config.load(), modelsDir: '/khong/ton/tai' }, quiet),
        /Không thấy mô hình nhận diện.*copy-face-models/
    )
})

/* ---------------- Tracker ---------------- */
const cfg = { ...config.load(), minSamples: 3, maxWaitMs: 2500, pingMs: 3000, unknownRetryMs: 5000 }
const face = (x = 100, sharp = 50, tag = 'a') => ({
    box: { x, y: 100, width: 100, height: 100 },
    descriptor: Array(1024).fill(0).map((_, i) => (i === 0 ? sharp / 100 : 0)),
    sharpness: sharp, thumbRgba: new Uint8Array(4), tag,
})

function fakeApi(overrides = {}) {
    const calls = { faceMatch: [], record: [], seen: [], link: [] }
    return {
        calls,
        faceMatch: async (faces) => { calls.faceMatch.push(faces); return overrides.faceMatch ? overrides.faceMatch(faces, calls) : { results: faces.map(f => ({ key: f.key, matched: false })) } },
        record: async (payload) => { calls.record.push(payload); return overrides.record ? overrides.record(payload, calls) : { recorded: true, id: 100 + calls.record.length, customer_id: payload.customer_id ?? null } },
        seen: async (id) => { calls.seen.push(id); if (overrides.seen) return overrides.seen(id, calls); return { ok: true } },
        link: async (id, customerId) => { calls.link.push([id, customerId]); return { linked: 1 } },
    }
}
const makeTracker = api => new Tracker({ api, cfg, log: quiet, encodeThumb: () => 'data:image/jpeg;base64,AAAA' })

test('Khách quen: gom đủ khung rồi so khớp, ghi lượt có customer_id và thumb', async () => {
    const api = fakeApi({ faceMatch: faces => ({ results: faces.map(f => ({ key: f.key, matched: true, customer: { id: 7 } })) }) })
    const t = makeTracker(api)
    t.update([face(100, 10)], 1000); await t.step(1000)
    assert.strictEqual(api.calls.faceMatch.length, 0, 'chưa đủ khung thì chưa gọi')
    t.update([face(105, 30)], 1700); await t.step(1700)
    t.update([face(110, 20)], 2400); await t.step(2400)
    assert.strictEqual(api.calls.faceMatch.length, 1)
    assert.strictEqual(api.calls.faceMatch[0][0].descriptors.length, 3)
    assert.strictEqual(api.calls.faceMatch[0][0].descriptors[0][0], 0.3, 'khung nét nhất đứng đầu')
    assert.deepStrictEqual(Object.keys(api.calls.record[0]).sort(), ['customer_id', 'thumb'])
    assert.strictEqual(api.calls.record[0].customer_id, 7)
    assert.strictEqual(t.tracks[0].state, 'resolved')
})

test('Chờ quá maxWaitMs thì so khớp dù mới có 1 khung', async () => {
    const api = fakeApi()
    const t = makeTracker(api)
    t.update([face()], 1000); await t.step(1000)
    assert.strictEqual(api.calls.faceMatch.length, 0)
    t.update([face()], 3600); await t.step(3600)
    assert.strictEqual(api.calls.faceMatch.length, 1)
})

test('Khách lạ: ghi lượt kèm vector; sau đó nhận ra khách quen thì gán lại', async () => {
    let round = 0
    const api = fakeApi({ faceMatch: (faces) => { round += 1; return { results: faces.map(f => (round >= 2 ? { key: f.key, matched: true, customer: { id: 9 } } : { key: f.key, matched: false })) } } })
    const t = makeTracker(api)
    t.update([face(100, 40)], 1000); t.update([face(100, 41)], 1100); t.update([face(100, 42)], 1200)
    await t.step(1200)
    assert.strictEqual(api.calls.record[0].descriptor.length, 1024)
    assert.strictEqual(api.calls.record[0].customer_id, undefined)
    assert.strictEqual(t.tracks[0].customerId, null)
    t.update([face(100, 43)], 6300); await t.step(6300)
    assert.deepStrictEqual(api.calls.link[0], [101, 9])
    assert.strictEqual(t.tracks[0].customerId, 9)
})

test('Chưa chắc chắn (ambiguous): thử lại tối đa 2 lần rồi coi là khách lạ', async () => {
    const api = fakeApi({ faceMatch: faces => ({ results: faces.map(f => ({ key: f.key, matched: false, ambiguous: true })) }) })
    const t = makeTracker(api)
    let now = 1000
    for (let i = 0; i < 12 && !api.calls.record.length; i += 1) { t.update([face()], now); await t.step(now); now += 3000 }
    assert.strictEqual(api.calls.faceMatch.length, 3)
    assert.ok(api.calls.record[0].descriptor, 'cuối cùng ghi như khách lạ')
})

test('Gửi nhịp theo chu kỳ; lượt bị xóa (404) thì ghi lại lượt mới', async () => {
    let missing = false
    const api = fakeApi({ seen: () => { if (missing) { const e = new Error('x'); e.status = 404; throw e } return { ok: true } } })
    const t = makeTracker(api)
    t.update([face(), face(400)], 1000)
    t.update([face(), face(400)], 1100); t.update([face(), face(400)], 1200)
    await t.step(1200)
    assert.strictEqual(api.calls.record.length, 2, 'hai người = hai lượt')
    await t.step(2000); assert.strictEqual(api.calls.seen.length, 0, 'chưa tới nhịp')
    t.update([face(), face(400)], 4300); await t.step(4300)
    assert.strictEqual(api.calls.seen.length, 2)
    missing = true
    t.update([face(), face(400)], 7400); await t.step(7400)
    assert.ok(t.tracks.every(track => track.state === 'collecting' && track.visitId === null))
})

test('Mất mặt quá thời hạn thì bỏ theo dõi; lỗi mạng khi so khớp không làm mất người', async () => {
    const api = fakeApi({ faceMatch: () => { throw new Error('mạng lỗi') } })
    const t = makeTracker(api)
    t.update([face()], 1000); t.update([face()], 1100); t.update([face()], 1200)
    await t.step(1200)
    assert.strictEqual(t.tracks[0].state, 'collecting')
    t.update([], 1200 + cfg.trackTtlMs + 1)
    assert.strictEqual(t.count, 0)
})

test('Ghi nhận lượt đang tắt (recorded=false) thì thử lại sau, không báo nhịp', async () => {
    const api = fakeApi({ record: () => ({ recorded: false }) })
    const t = makeTracker(api)
    t.update([face()], 1000); t.update([face()], 1100); t.update([face()], 1200)
    await t.step(1200)
    assert.strictEqual(t.tracks[0].state, 'collecting')
    assert.strictEqual(api.calls.seen.length, 0)
})

/* ---------------- Camera + API qua máy chủ giả ---------------- */
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve(server.address().port)))
const jpegBytes = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 4])

test('Camera Digest: 401 -> tự đăng nhập lại; Basic; sai định dạng báo lỗi rõ', async () => {
    const seen = []
    const server = http.createServer((req, res) => {
        const auth = req.headers.authorization || ''
        seen.push(auth.split(' ')[0])
        if (req.url === '/notjpeg') { res.setHeader('Content-Type', 'text/html'); return res.end('<html>') }
        if (req.url === '/digest') {
            if (!auth.startsWith('Digest ')) {
                res.writeHead(401, { 'WWW-Authenticate': 'Digest realm="cam", nonce="n0nce", qop="auth", algorithm=MD5' })
                return res.end()
            }
            return res.end(jpegBytes)
        }
        if (req.url === '/basic') {
            if (auth !== 'Basic ' + Buffer.from('u:p').toString('base64')) { res.writeHead(401); return res.end() }
            return res.end(jpegBytes)
        }
        res.writeHead(404); res.end()
    })
    const port = await listen(server)
    try {
        const base = `http://127.0.0.1:${port}`
        const digest = createCamera({ snapshotUrl: base + '/digest', auth: 'digest', user: 'u', password: 'p' })
        assert.strictEqual((await digest.snapshot()).length, jpegBytes.length)
        assert.strictEqual((await digest.snapshot()).length, jpegBytes.length) // lần 2 dùng lại thử thách
        const basic = createCamera({ snapshotUrl: base + '/basic', auth: 'basic', user: 'u', password: 'p' })
        assert.strictEqual((await basic.snapshot()).length, jpegBytes.length)
        const wrong = createCamera({ snapshotUrl: base + '/basic', auth: 'basic', user: 'u', password: 'sai' })
        await assert.rejects(() => wrong.snapshot(), /từ chối đăng nhập/)
        const html = createCamera({ snapshotUrl: base + '/notjpeg', auth: 'none' })
        await assert.rejects(() => html.snapshot(), /không trả về ảnh JPEG/)
        const missing = createCamera({ snapshotUrl: base + '/none', auth: 'none' })
        await assert.rejects(() => missing.snapshot(), /lỗi 404/)
    } finally { server.close() }
})

test('API client: gửi X-Camera-Key + JSON, đọc lỗi từ máy chủ', async () => {
    const got = []
    const server = http.createServer((req, res) => {
        let body = ''
        req.on('data', chunk => { body += chunk })
        req.on('end', () => {
            got.push({ url: req.url, key: req.headers['x-camera-key'], body: body ? JSON.parse(body) : null })
            res.setHeader('Content-Type', 'application/json')
            if (req.url.includes('/401/')) { res.statusCode = 401; return res.end(JSON.stringify({ message: 'Khóa camera không hợp lệ.' })) }
            res.end(JSON.stringify({ ok: true, enabled: true, recorded: true, id: 5 }))
        })
    })
    const port = await listen(server)
    try {
        const api = createApi({ apiUrl: `http://127.0.0.1:${port}/api`, cameraKey: 'abc' })
        assert.strictEqual((await api.heartbeat({ camera_ok: true })).enabled, true)
        await api.record({ customer_id: 3 })
        await api.link(5, 3)
        assert.strictEqual(got[0].url, '/api/door-camera/heartbeat')
        assert.strictEqual(got[0].key, 'abc')
        assert.deepStrictEqual(got[2].body, { customer_id: 3, consent: false })
        const bad = createApi({ apiUrl: `http://127.0.0.1:${port}/api/401`, cameraKey: 'x' })
        await assert.rejects(() => bad.heartbeat({}), (e) => e.status === 401 && /Khóa camera/.test(e.message))
        const down = createApi({ apiUrl: 'http://127.0.0.1:1/api', cameraKey: 'x' })
        await assert.rejects(() => down.heartbeat({}), /Không gọi được máy chủ/)
    } finally { server.close() }
})

test('validate cấu hình báo thiếu khóa/địa chỉ camera', () => {
    const problems = config.validate({ cameraKey: '', apiUrl: 'http://x/api', snapshotUrl: 'x', auth: 'digest', user: '', backend: 'auto' })
    assert.strictEqual(problems.length, 2) // thiếu khóa + địa chỉ camera không hợp lệ
    const more = config.validate({ cameraKey: '', apiUrl: 'http://x/api', snapshotUrl: 'http://cam/a.jpg', auth: 'digest', user: '', backend: 'auto' })
    assert.strictEqual(more.length, 2) // thiếu khóa + kiểu digest nhưng chưa có tài khoản
})

test('validateBase / validateCamera tách riêng khóa-máy chủ và thông tin camera', () => {
    assert.deepStrictEqual(config.validateBase({ cameraKey: 'k', apiUrl: 'http://x/api', backend: 'auto' }), [])
    assert.strictEqual(config.validateBase({ cameraKey: '', apiUrl: 'x', backend: 'auto' }).length, 2)
    assert.strictEqual(config.validateCamera({ snapshotUrl: '', auth: 'none' }).length, 1)
    assert.strictEqual(config.validateCamera({ snapshotUrl: 'http://cam/p.jpg', auth: 'digest', user: '' }).length, 1)
    assert.deepStrictEqual(config.validateCamera({ snapshotUrl: 'http://cam/p.jpg', auth: 'basic', user: 'u' }), [])
})

test('applyRemote: nạp camera từ máy chủ, báo có thay đổi, .env đặt tay thì được ưu tiên', () => {
    const cfg = { snapshotUrl: '', auth: 'none', user: '', password: '' }
    const remote = { camera: { snapshot_url: ' http://cam/snap.jpg ', auth: 'DIGEST', username: 'admin', password: 'p@ss' } }
    assert.strictEqual(config.applyRemote(cfg, remote, {}), true)
    assert.deepStrictEqual(cfg, { snapshotUrl: 'http://cam/snap.jpg', auth: 'digest', user: 'admin', password: 'p@ss' })
    assert.strictEqual(config.applyRemote(cfg, remote, {}), false) // không đổi thì không báo thay đổi
    remote.camera.password = 'moi'
    assert.strictEqual(config.applyRemote(cfg, remote, {}), true)
    assert.strictEqual(cfg.password, 'moi')
    const manual = { snapshotUrl: 'http://tay/x.jpg', auth: 'none', user: '', password: '' }
    assert.strictEqual(config.applyRemote(manual, remote, { CAMERA_SNAPSHOT_URL: 'http://tay/x.jpg' }), false)
    assert.strictEqual(manual.snapshotUrl, 'http://tay/x.jpg')
})

test('setup: chuẩn hóa địa chỉ máy chủ và cập nhật .env mà không mất cấu hình khác', () => {
    const { normalizeApiUrl, upsertEnv, parseArgs } = require('../src/setup')
    assert.strictEqual(normalizeApiUrl('192.168.1.10'), 'http://192.168.1.10/api')
    assert.strictEqual(normalizeApiUrl('https://shop.vn/'), 'https://shop.vn/api')
    assert.strictEqual(normalizeApiUrl('http://127.0.0.1:8000/api/'), 'http://127.0.0.1:8000/api')
    assert.strictEqual(normalizeApiUrl('  '), '')
    const out = upsertEnv('# ghi chú\nAPI_URL=http://cu/api\nFRAME_INTERVAL_MS=900\nDOOR_CAMERA_KEY=\n', { API_URL: 'http://moi/api', DOOR_CAMERA_KEY: 'abc', EXTRA: '1' })
    assert.strictEqual(out, '# ghi chú\nAPI_URL=http://moi/api\nFRAME_INTERVAL_MS=900\nDOOR_CAMERA_KEY=abc\nEXTRA=1\n')
    assert.deepStrictEqual(parseArgs(['--url', 'x', '--key=k']), { url: 'x', key: 'k', trust: false, help: false })
    assert.strictEqual(parseArgs(['--url', 'x', '--key', 'k', '--trust-cert']).trust, true)
})

test('API client: config() gọi GET /door-camera/config kèm khóa', async () => {
    const got = []
    const server = http.createServer((req, res) => {
        got.push({ method: req.method, url: req.url, key: req.headers['x-camera-key'] })
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ enabled: true, camera: { snapshot_url: 'http://cam/a.jpg', auth: 'none', username: '', password: '' }, config_hash: 'h1' }))
    })
    const port = await listen(server)
    try {
        const data = await createApi({ apiUrl: `http://127.0.0.1:${port}/api`, cameraKey: 'k1' }).config()
        assert.deepStrictEqual(got[0], { method: 'GET', url: '/api/door-camera/config', key: 'k1' })
        assert.strictEqual(data.config_hash, 'h1')
    } finally { server.close() }
})

/* ---------------- Ghim chứng chỉ HTTPS tự ký ---------------- */
const fs = require('fs')
const path = require('path')
const https = require('https')
const { X509Certificate } = require('crypto')
const tlsPin = require('../src/tls')

const fixture = name => fs.readFileSync(path.join(__dirname, 'fixtures', name))
const fixtureFingerprint = () => tlsPin.normalizeFingerprint(new X509Certificate(fixture('selfsigned.crt')).fingerprint256)

test('normalizeFingerprint nhận nhiều dạng vân tay SHA-256, sai định dạng thì trả rỗng', () => {
    const hex = 'ab6a38bb3e6212243f2e3cdf2bdc42f2940be2dbfbb863c995e9bb0b5274c0e4'
    const colon = hex.toUpperCase().match(/.{2}/g).join(':')
    assert.strictEqual(tlsPin.normalizeFingerprint(hex), hex)
    assert.strictEqual(tlsPin.normalizeFingerprint(colon), hex)
    assert.strictEqual(tlsPin.normalizeFingerprint('sha256 Fingerprint=' + colon), hex)
    assert.strictEqual(tlsPin.normalizeFingerprint('SHA256:' + colon), hex)
    assert.strictEqual(tlsPin.normalizeFingerprint('abc'), '')
    assert.strictEqual(tlsPin.normalizeFingerprint(''), '')
    assert.strictEqual(tlsPin.formatFingerprint(hex), colon)
})

test('config: API_CERT_SHA256 được chuẩn hóa, giá trị sai bị báo lỗi', () => {
    const hex = fixtureFingerprint()
    const keep = process.env.API_CERT_SHA256
    try {
        process.env.API_CERT_SHA256 = hex.toUpperCase().match(/.{2}/g).join(':')
        const ok = config.load()
        assert.strictEqual(ok.certSha256, hex)
        assert.deepStrictEqual(config.validateBase({ ...ok, cameraKey: 'k', apiUrl: 'https://x/api' }), [])
        process.env.API_CERT_SHA256 = 'khong-phai-van-tay'
        const bad = config.load()
        assert.strictEqual(bad.certSha256, '')
        assert.strictEqual(config.validateBase({ ...bad, cameraKey: 'k', apiUrl: 'https://x/api' }).length, 1)
    } finally {
        if (keep === undefined) delete process.env.API_CERT_SHA256; else process.env.API_CERT_SHA256 = keep
    }
})

test('HTTPS tự ký: không ghim thì lỗi kèm gợi ý, ghim đúng thì gọi được, ghim sai thì bị chặn trước khi gửi khóa', async () => {
    const got = []
    const server = https.createServer({ key: fixture('selfsigned.key'), cert: fixture('selfsigned.crt') }, (req, res) => {
        got.push({ method: req.method, url: req.url, key: req.headers['x-camera-key'] })
        let body = ''
        req.on('data', chunk => { body += chunk })
        req.on('end', () => {
            res.setHeader('Content-Type', 'application/json')
            if (req.url.includes('/401/')) { res.statusCode = 401; return res.end(JSON.stringify({ message: 'Khóa camera không hợp lệ.' })) }
            res.end(JSON.stringify({ ok: true, echo: body ? JSON.parse(body) : null }))
        })
    })
    const port = await listen(server)
    const apiUrl = `https://127.0.0.1:${port}/api`
    const pin = fixtureFingerprint()
    try {
        // 1) Không ghim: Node từ chối chứng chỉ tự ký và lời nhắn chỉ cách sửa
        await assert.rejects(() => createApi({ apiUrl, cameraKey: 'k' }).config(), /DEPTH_ZERO_SELF_SIGNED_CERT.*pin-cert/s)
        assert.strictEqual(got.length, 0)

        // 2) Ghim đúng vân tay (dù tên máy 127.0.0.1 không nằm trong chứng chỉ): GET + POST đều chạy
        const api = createApi({ apiUrl, cameraKey: 'k-ghim', certSha256: pin })
        assert.strictEqual((await api.config()).ok, true)
        assert.deepStrictEqual((await api.record({ customer_id: 7 })).echo, { customer_id: 7 })
        assert.deepStrictEqual(got.map(g => [g.method, g.url, g.key]), [['GET', '/api/door-camera/config', 'k-ghim'], ['POST', '/api/door-camera/visits', 'k-ghim']])

        // 3) Mã lỗi HTTP vẫn được chuyển đúng khi đã ghim
        const bad = createApi({ apiUrl: apiUrl + '/401', cameraKey: 'x', certSha256: pin })
        await assert.rejects(() => bad.heartbeat({}), (e) => e.status === 401 && /Khóa camera/.test(e.message))

        // 4) Ghim sai vân tay: chặn ngay khi bắt tay TLS, máy chủ không nhận được khóa
        const before = got.length
        const wrong = createApi({ apiUrl, cameraKey: 'bi-lo', certSha256: '00'.repeat(32) })
        await assert.rejects(() => wrong.config(), /KHÁC với chứng chỉ đã ghim/)
        assert.strictEqual(got.length, before)

        // 5) fetchServerCert trả đúng vân tay để lệnh pin-cert ghi vào .env
        const info = await tlsPin.fetchServerCert(apiUrl)
        assert.strictEqual(info.fingerprint, pin)
        assert.strictEqual(info.trusted, false)
        assert.strictEqual(info.subject, 'door-worker-test')
    } finally { server.close() }
})

test('pin-cert: đọc tham số dòng lệnh', () => {
    const { parseArgs } = require('../src/pin-cert')
    assert.deepStrictEqual(parseArgs(['--yes', '--url=https://a/api', '--fingerprint', 'ab']), { url: 'https://a/api', fingerprint: 'ab', yes: true, forget: false, help: false })
    assert.strictEqual(parseArgs(['--forget']).forget, true)
})

const rtsp = require('../src/rtsp')
const { EventEmitter } = require('events')
const { PassThrough } = require('stream')

function fakeSpawn() {
    const calls = []
    const spawn = (cmd, args) => {
        const proc = new EventEmitter()
        proc.stdout = new PassThrough()
        proc.stderr = new PassThrough()
        proc.killed = false
        proc.kill = () => { proc.killed = true; setImmediate(() => proc.emit('close', null)) }
        calls.push({ cmd, args, proc })
        return proc
    }
    return { spawn, calls }
}
const tick = () => new Promise(resolve => setTimeout(resolve, 10))
const frameA = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 0xff, 0x00, 4, 0xff, 0xd9])
const frameB = Buffer.from([0xff, 0xd8, 9, 8, 7, 0xff, 0xd9])

test('RTSP: nhận diện địa chỉ, ghép tài khoản, che mật khẩu trong thông báo', () => {
    assert.strictEqual(rtsp.isRtsp('rtsp://1.2.3.4/x'), true)
    assert.strictEqual(rtsp.isRtsp('RTSPS://1.2.3.4/x'), true)
    assert.strictEqual(rtsp.isRtsp('http://1.2.3.4/x.jpg'), false)
    assert.strictEqual(rtsp.buildRtspUrl('rtsp://192.168.1.5:554/live', 'admin', 'p@ss:1'), 'rtsp://admin:p%40ss%3A1@192.168.1.5:554/live')
    assert.strictEqual(rtsp.buildRtspUrl('rtsp://192.168.1.5/live', '', ''), 'rtsp://192.168.1.5/live')
    assert.strictEqual(rtsp.buildRtspUrl('rtsp://u:p@192.168.1.5/live', 'khac', 'khac'), 'rtsp://u:p@192.168.1.5/live')
    assert.strictEqual(rtsp.maskUrl('lỗi rtsp://admin:secret@10.0.0.2:554/s tại'), 'lỗi rtsp://***@10.0.0.2:554/s tại')
    const args = rtsp.ffmpegArgs({ rtspTransport: 'tcp', rtspFps: 2 }, 'rtsp://h/x')
    assert.deepStrictEqual(args.slice(args.indexOf('-rtsp_transport'), args.indexOf('-rtsp_transport') + 4), ['-rtsp_transport', 'tcp', '-i', 'rtsp://h/x'])
    assert.ok(args.includes('image2pipe') && args.includes('fps=2'))
})

test('RTSP: tách các ảnh JPEG liền nhau kể cả bị cắt giữa chừng (kể cả giữa FF và D8)', () => {
    const stream = Buffer.concat([Buffer.from([1, 2, 3]), frameA, frameB, frameA])
    for (const size of [1, 2, 3, 5, 7, 1000]) {
        const splitter = new rtsp.JpegSplitter()
        const frames = []
        for (let i = 0; i < stream.length; i += size) frames.push(...splitter.push(stream.subarray(i, i + size)))
        assert.strictEqual(frames.length, 3, 'chunk ' + size)
        assert.ok(frames[0].equals(frameA) && frames[1].equals(frameB) && frames[2].equals(frameA), 'chunk ' + size)
    }
})

test('RTSP: dịch lỗi ffmpeg sang tiếng Việt và không lộ mật khẩu', () => {
    assert.match(rtsp.describeFfmpegError('rtsp://a:b@1.1.1.1/x: Server returned 401 Unauthorized (authorization failed)', 1), /từ chối đăng nhập/)
    assert.match(rtsp.describeFfmpegError('Server returned 404 Not Found', 1), /404/)
    assert.match(rtsp.describeFfmpegError('Connection refused', 1), /Không kết nối được camera RTSP/)
    const other = rtsp.describeFfmpegError('rtsp://admin:secret@1.1.1.1/x: Something weird happened', 1)
    assert.ok(!other.includes('secret'))
})

test('RTSP camera: lấy khung mới nhất qua ffmpeg, lỗi 401 báo rõ, đóng thì dừng tiến trình', async () => {
    const { spawn, calls } = fakeSpawn()
    const cfg = { snapshotUrl: 'rtsp://192.168.1.5:554/live', user: 'admin', password: 'p@ss', ffmpegPath: 'ffmpeg-x', rtspTransport: 'tcp', rtspFps: 2 }
    const camera = rtsp.createRtspCamera(cfg, { spawn, restartDelayMs: 5, frameTimeoutMs: 300 })

    const first = camera.snapshot()
    await tick()
    assert.strictEqual(calls.length, 1)
    assert.strictEqual(calls[0].cmd, 'ffmpeg-x')
    assert.ok(calls[0].args.includes('rtsp://admin:p%40ss@192.168.1.5:554/live'))
    calls[0].proc.stdout.write(Buffer.concat([frameA, frameB.subarray(0, 3)]))
    assert.ok((await first).equals(frameA))

    // Khung chưa đủ thì đợi; đủ rồi thì trả khung mới
    const second = camera.snapshot()
    calls[0].proc.stdout.write(frameB.subarray(3))
    assert.ok((await second).equals(frameB))

    // ffmpeg thoát vì sai mật khẩu -> báo lỗi dễ hiểu, sau đó tự chạy lại
    calls[0].proc.stderr.write('Server returned 401 Unauthorized')
    calls[0].proc.emit('close', 1)
    await assert.rejects(() => camera.snapshot(), /từ chối đăng nhập/)
    await new Promise(resolve => setTimeout(resolve, 40))
    assert.strictEqual(calls.length, 2)
    const again = camera.snapshot()
    calls[1].proc.stdout.write(frameA)
    assert.ok((await again).equals(frameA))

    camera.close()
    await tick()
    assert.strictEqual(calls[1].proc.killed, true)
    await assert.rejects(() => camera.snapshot(), /đã đóng/)
})

test('RTSP camera: thiếu ffmpeg báo hướng dẫn cài; không có khung thì báo hết thời gian chờ', async () => {
    const missing = fakeSpawn()
    const cam1 = rtsp.createRtspCamera({ snapshotUrl: 'rtsp://h/x', ffmpegPath: 'ffmpeg' }, { spawn: missing.spawn, restartDelayMs: 1000, frameTimeoutMs: 300 })
    const pending = cam1.snapshot()
    await tick()
    missing.calls[0].proc.emit('error', Object.assign(new Error('spawn ffmpeg ENOENT'), { code: 'ENOENT' }))
    await assert.rejects(() => pending, /Chưa cài ffmpeg/)
    cam1.close()

    const silent = fakeSpawn()
    const cam2 = rtsp.createRtspCamera({ snapshotUrl: 'rtsp://h/x', ffmpegPath: 'ffmpeg' }, { spawn: silent.spawn, frameTimeoutMs: 40 })
    await assert.rejects(() => cam2.snapshot(), /không phản hồi/)
    cam2.close()
})

test('createCamera chọn đúng loại theo địa chỉ; validateCamera chấp nhận RTSP không cần kiểu đăng nhập', () => {
    const cam = createCamera({ snapshotUrl: 'rtsp://127.0.0.1:1/x', ffmpegPath: 'ffmpeg-khong-ton-tai' })
    assert.strictEqual(typeof cam.close, 'function') // camera RTSP có close(), camera http thì không
    cam.close()
    assert.strictEqual(typeof createCamera({ snapshotUrl: 'http://127.0.0.1:1/a.jpg', auth: 'none' }).close, 'undefined')
    assert.deepStrictEqual(config.validateCamera({ snapshotUrl: 'rtsp://192.168.1.5/live', auth: 'none', user: '' }), [])
    assert.deepStrictEqual(config.validateCamera({ snapshotUrl: 'rtsps://192.168.1.5/live', auth: 'digest', user: '' }), [])
    assert.strictEqual(config.validateCamera({ snapshotUrl: 'ftp://x', auth: 'none' }).length, 1)
})

test('ffmpeg thật (bỏ qua nếu máy chưa cài): luồng giả lập ra ảnh JPEG hợp lệ; camera RTSP không tồn tại báo lỗi tiếng Việt', async () => {
    const { spawn: realSpawn, spawnSync } = require('child_process')
    if (spawnSync('ffmpeg', ['-version']).status !== 0) { console.log('      (bỏ qua: chưa cài ffmpeg)'); return }

    const real = rtsp.ffmpegArgs({ rtspTransport: 'tcp', rtspFps: 2 }, 'rtsp://x/y')
    const tail = real.slice(real.indexOf('-an'))
    const inject = () => realSpawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-nostdin', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=10', ...tail], { stdio: ['ignore', 'pipe', 'pipe'] })
    const camera = rtsp.createRtspCamera({ snapshotUrl: 'rtsp://x/y', ffmpegPath: 'ffmpeg' }, { spawn: inject, frameTimeoutMs: 8000 })
    try {
        const frames = []
        for (let i = 0; i < 3; i += 1) frames.push(await camera.snapshot())
        for (const frame of frames) {
            assert.ok(frame[0] === 0xff && frame[1] === 0xd8 && frame[frame.length - 2] === 0xff && frame[frame.length - 1] === 0xd9)
        }
        assert.ok(!frames[0].equals(frames[1]) || !frames[1].equals(frames[2]))
    } finally { camera.close() }

    const bad = rtsp.createRtspCamera({ snapshotUrl: 'rtsp://127.0.0.1:1/live', user: 'admin', password: 'matkhau-bi-mat', ffmpegPath: 'ffmpeg', rtspTransport: 'tcp', rtspFps: 2 }, { frameTimeoutMs: 8000 })
    try {
        await assert.rejects(() => bad.snapshot(), (error) => /Không kết nối được camera RTSP/.test(error.message) && !error.message.includes('matkhau-bi-mat'))
    } finally { bad.close() }
})

;(async () => {
    let failed = 0
    for (const { name, fn } of tests) {
        try { await fn(); console.log('  ok  ', name) } catch (error) { failed += 1; console.log('  FAIL', name, '\n      ', error.message) }
    }
    console.log(failed ? `\n${failed}/${tests.length} test lỗi` : `\nTất cả ${tests.length} test đạt`)
    process.exit(failed ? 1 : 0)
})()
