'use strict'
/**
 * Ghim chứng chỉ HTTPS tự ký của máy chủ QLBH (ví dụ Laragon) vào door-worker/.env, làm một lần:
 *   npm run pin-cert                         dùng API_URL trong .env, hiện vân tay rồi hỏi xác nhận
 *   npm run pin-cert -- --yes                tin chứng chỉ đang nhận, không hỏi (chỉ dùng trong LAN tin cậy)
 *   npm run pin-cert -- --fingerprint <hex>  chỉ ghim nếu máy chủ trình đúng vân tay này (an toàn nhất)
 *   npm run pin-cert -- --url https://...    chỉ định địa chỉ khác (đồng thời ghi lại API_URL)
 *   npm run pin-cert -- --forget             bỏ ghim
 */
const fs = require('fs')
const path = require('path')
const readline = require('readline')
const { loadEnv } = require('./env')
const { upsertEnv, normalizeApiUrl } = require('./setup')
const { fetchServerCert, formatFingerprint, normalizeFingerprint } = require('./tls')

const root = path.resolve(__dirname, '..')
const envFile = path.join(root, '.env')

function parseArgs(argv) {
    const out = { url: '', fingerprint: '', yes: false, forget: false, help: false }
    for (let i = 0; i < argv.length; i += 1) {
        const arg = argv[i]
        if (arg === '--help' || arg === '-h') out.help = true
        else if (arg === '--yes' || arg === '-y') out.yes = true
        else if (arg === '--forget') out.forget = true
        else if (arg === '--url') out.url = argv[++i] || ''
        else if (arg === '--fingerprint') out.fingerprint = argv[++i] || ''
        else if (arg.startsWith('--url=')) out.url = arg.slice(6)
        else if (arg.startsWith('--fingerprint=')) out.fingerprint = arg.slice(14)
    }
    return out
}

function ask(question) {
    return new Promise((resolve) => {
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
        let answered = false
        rl.on('close', () => { if (!answered) resolve('') })
        rl.question(question, (answer) => { answered = true; rl.close(); resolve(answer.trim()) })
    })
}

function writeEnv(values) {
    const base = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : ''
    fs.writeFileSync(envFile, upsertEnv(base, values))
}

async function main() {
    const args = parseArgs(process.argv.slice(2))
    if (args.help) {
        console.log('Cách dùng: npm run pin-cert [-- --url <địa chỉ>] [--fingerprint <SHA-256>] [--yes] [--forget]')
        return
    }

    if (args.forget) {
        writeEnv({ API_CERT_SHA256: '' })
        console.log(`Đã bỏ ghim chứng chỉ trong ${envFile}`)
        return
    }

    loadEnv(envFile)
    const apiUrl = args.url ? normalizeApiUrl(args.url) : (process.env.API_URL || '')
    if (!/^https:\/\//i.test(apiUrl)) {
        console.error('API_URL phải là địa chỉ https:// (hiện là: ' + (apiUrl || 'trống') + '). Chạy "npm run setup -- --url https://... --key ..." trước.')
        process.exit(1)
    }

    let info
    try {
        info = await fetchServerCert(apiUrl)
    } catch (error) {
        console.error(`Không kết nối được ${apiUrl}: ${error?.code || error?.message}`)
        console.error('Kiểm tra máy chủ đang chạy và địa chỉ truy cập được từ máy này.')
        process.exit(1)
    }

    console.log(`Máy chủ: ${apiUrl}`)
    console.log(`  Cấp cho : ${info.subject || '(không có)'}`)
    console.log(`  Cấp bởi : ${info.issuer || '(không có)'}`)
    console.log(`  Hiệu lực: ${info.validFrom} → ${info.validTo}${info.expired ? '  (ĐÃ HẾT HẠN)' : ''}`)
    if (info.altNames) console.log(`  Tên/IP  : ${info.altNames}`)
    console.log(`  SHA-256 : ${formatFingerprint(info.fingerprint)}`)

    if (info.trusted) {
        console.log('\nChứng chỉ này đã được máy tin cậy sẵn nên KHÔNG cần ghim (ghim còn gây lỗi khi chứng chỉ được gia hạn).')
        return
    }

    if (args.fingerprint) {
        const expected = normalizeFingerprint(args.fingerprint)
        if (!expected) { console.error('\n--fingerprint không đúng định dạng SHA-256 (64 ký tự hex, có thể có dấu :).'); process.exit(1) }
        if (expected !== info.fingerprint) {
            console.error('\nKHÔNG KHỚP: vân tay máy chủ trình ra khác với --fingerprint. Không ghim. Có thể đang trỏ nhầm máy hoặc bị chen vào đường truyền.')
            process.exit(1)
        }
        console.log('\nVân tay khớp với --fingerprint.')
    } else if (!args.yes) {
        console.log('\nChỉ ghim nếu đây đúng là máy chủ QLBH của bạn. Sau khi ghim, worker chỉ nói chuyện với đúng chứng chỉ này.')
        const answer = await ask('Ghim chứng chỉ này? (y/N): ')
        if (!/^(y|yes|c|co|có)$/i.test(answer)) { console.log('Đã hủy, chưa thay đổi gì.'); process.exit(1) }
    }

    const values = { API_CERT_SHA256: info.fingerprint }
    if (args.url) values.API_URL = apiUrl
    writeEnv(values)
    console.log(`\nĐã ghi API_CERT_SHA256 vào ${envFile}`)
    if (info.expired) console.log('Cảnh báo: chứng chỉ đã hết hạn. Vẫn dùng được vì đã ghim, nhưng nên cấp chứng chỉ mới rồi chạy lại lệnh này.')

    // Thử gọi thật bằng chứng chỉ vừa ghim (không bắt buộc thành công).
    if (process.env.DOOR_CAMERA_KEY) {
        try {
            const { createApi } = require('./api')
            await createApi({ apiUrl, cameraKey: process.env.DOOR_CAMERA_KEY, certSha256: info.fingerprint }, { timeoutMs: 6000 }).config()
            console.log('Kết nối máy chủ: OK.')
        } catch (error) {
            console.log('Đã ghim, nhưng gọi thử máy chủ chưa được: ' + error.message)
        }
    }
    console.log('\nBước tiếp theo:  npm run check   rồi   npm start')
}

module.exports = { parseArgs }

if (require.main === module) {
    main().catch((error) => { console.error(error?.message || error); process.exit(1) })
}
