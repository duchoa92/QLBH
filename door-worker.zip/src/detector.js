'use strict'
const fs = require('fs')
const path = require('path')
const { rgbaToRgb, cropSquare, sharpness } = require('./image')

/** Mô hình Human cần có trong thư mục mô hình (file .json; file .bin đi kèm). */
const REQUIRED_MODELS = ['blazeface', 'facemesh', 'faceres']

/**
 * fetch có sẵn của Node (undici) không đọc được địa chỉ file://, mà Human dùng fetch để nạp mô hình từ đĩa
 * khi chạy backend wasm. Bổ sung đọc file:// bằng fs; địa chỉ khác vẫn đi qua fetch gốc.
 */
function enableFileFetch() {
    if (globalThis.fetch && globalThis.fetch.supportsFileUrl) return
    const nativeFetch = globalThis.fetch
    const patched = async (input, init) => {
        const url = typeof input === 'string' ? input : (input && (input.url || input.href)) || String(input)
        if (!/^file:\/\//i.test(url)) return nativeFetch(input, init)
        let file = decodeURIComponent(url.replace(/^file:\/\//i, ''))
        if (/^\/[A-Za-z]:/.test(file)) file = file.slice(1) // file:///C:/... -> C:/...
        try {
            const buffer = await fs.promises.readFile(file)
            return new Response(buffer, { status: 200, headers: { 'content-type': file.endsWith('.json') ? 'application/json' : 'application/octet-stream' } })
        } catch {
            return new Response(null, { status: 404, statusText: 'Not Found: ' + file })
        }
    }
    patched.supportsFileUrl = true
    globalThis.fetch = patched
}

/** Nạp bản build của Human theo đường dẫn tuyệt đối (không phụ thuộc cách package khai báo "exports"). */
function requireHuman(file) {
    const dist = path.dirname(require.resolve('@vladmandic/human'))
    const mod = require(path.join(dist, file))
    return mod.Human || mod.default || mod
}

/**
 * Node 23+ đã xóa các hàm util.isXxx cũ mà @tensorflow/tfjs-node 4.x vẫn gọi (lỗi "util_1.isNullOrUndefined is not a function").
 * Bù lại các hàm còn thiếu trước khi nạp tfjs-node; Node cũ đã có sẵn thì không đụng tới.
 */
function polyfillRemovedUtil() {
    const util = require('util')
    const shims = {
        isNullOrUndefined: v => v === null || v === undefined,
        isNull: v => v === null,
        isUndefined: v => v === undefined,
        isArray: Array.isArray,
        isBoolean: v => typeof v === 'boolean',
        isNumber: v => typeof v === 'number',
        isString: v => typeof v === 'string',
        isSymbol: v => typeof v === 'symbol',
        isFunction: v => typeof v === 'function',
        isObject: v => v !== null && typeof v === 'object',
        isPrimitive: v => v === null || (typeof v !== 'object' && typeof v !== 'function'),
        isRegExp: v => v instanceof RegExp,
        isDate: v => v instanceof Date,
        isError: v => v instanceof Error,
    }
    for (const [name, fn] of Object.entries(shims)) {
        if (typeof util[name] !== 'function') util[name] = fn
    }
}

/**
 * Chọn backend TensorFlow. Mặc định "auto": thử tfjs-node (nhanh nhất); nếu máy không có (ví dụ Windows không cài
 * được bản dựng sẵn) thì tự dùng wasm. Cùng một cấu hình chạy được trên Windows lẫn Ubuntu, không phải sửa gì.
 */
function selectBackend(cfg, log) {
    if (cfg.backend !== 'wasm') {
        try {
            polyfillRemovedUtil()
            const tf = require('@tensorflow/tfjs-node')
            // Thử một phép tính nhỏ ngay: tfjs-node có thể nạp được nhưng vẫn lỗi khi chạy (Node mới, thiếu DLL...).
            tf.dispose(tf.cast(tf.tensor1d([1, 2, 3]), 'int32'))
            return { name: 'tfjs-node', tf, Human: requireHuman('human.node.js'), humanConfig: { backend: 'tensorflow' } }
        } catch (error) {
            if (cfg.backend === 'tfjs-node') {
                throw new Error('TF_BACKEND=tfjs-node nhưng không nạp được @tensorflow/tfjs-node: ' + (error?.message || error))
            }
            log.warn('Không dùng được tfjs-node trên máy này, chuyển sang wasm (chậm hơn một chút).')
        }
    }

    const tf = require('@tensorflow/tfjs')
    const wasm = require('@tensorflow/tfjs-backend-wasm')
    const wasmDir = path.dirname(require.resolve('@tensorflow/tfjs-backend-wasm')) + path.sep
    wasm.setWasmPaths(wasmDir)
    return { name: 'wasm', tf, Human: requireHuman('human.node-wasm.js'), humanConfig: { backend: 'wasm', wasmPath: wasmDir } }
}

/** Nạp Human cho Node và mô hình từ đĩa. Trình duyệt dùng cùng bộ mô hình nên vector khớp với khách đã đăng ký. */
async function createDetector(cfg, log) {
    const missing = REQUIRED_MODELS.filter(name => !fs.existsSync(path.join(cfg.modelsDir, name + '.json')))
    if (missing.length) {
        throw new Error(`Không thấy mô hình nhận diện trong ${cfg.modelsDir} (thiếu: ${missing.join(', ')}). Chạy "node scripts/copy-face-models.mjs" ở thư mục gốc dự án hoặc đặt MODELS_DIR đúng.`)
    }

    enableFileFetch()
    const backend = selectBackend(cfg, log)
    const human = new backend.Human({
        ...backend.humanConfig,
        modelBasePath: 'file://' + cfg.modelsDir.replace(/\\/g, '/').replace(/\/?$/, '/'),
        debug: false,
        async: true,
        warmup: 'none',
        // Mỗi khung hình đều tính mới: không dùng bộ nhớ đệm giữa các khung (worker đã tự chọn khung nét nhất).
        cacheSensitivity: 0,
        filter: { enabled: false },
        face: {
            enabled: true,
            detector: { modelPath: cfg.detectorModel, rotation: false, maxDetected: cfg.maxFaces, minConfidence: cfg.scoreThreshold, skipFrames: 0, skipTime: 0 },
            mesh: { enabled: true },
            iris: { enabled: false },
            description: { enabled: true, minConfidence: 0.1, skipFrames: 0, skipTime: 0 },
            emotion: { enabled: false },
            antispoof: { enabled: false },
            liveness: { enabled: false },
        },
        body: { enabled: false },
        hand: { enabled: false },
        object: { enabled: false },
        gesture: { enabled: false },
        segmentation: { enabled: false },
    })
    await human.load()
    const tf = human.tf || backend.tf

    // Human chỉ ghi log khi nạp mô hình lỗi chứ không báo lỗi: chạy thử một khung trống để phát hiện sớm.
    const probe = tf.zeros([64, 64, 3], 'int32')
    try {
        await human.detect(probe)
    } catch (error) {
        throw new Error('Không nạp được mô hình nhận diện (kiểm tra MODELS_DIR và các file .json/.bin trong ' + cfg.modelsDir + '): ' + (error?.message || error))
    } finally {
        probe.dispose()
    }
    log.info(`Đã nạp mô hình nhận diện (Human, backend: ${backend.name}).`)

    return {
        backend: backend.name,
        /**
         * Tìm khuôn mặt trong 1 khung hình { width, height, rgba }.
         * Trả { faces: [{ box, descriptor, sharpness, thumbRgba }], tooSmall } (mặt lớn nhất đứng đầu).
         */
        async detect(frame) {
            const input = tf.tensor3d(rgbaToRgb(frame.rgba, frame.width, frame.height), [frame.height, frame.width, 3], 'int32')
            let result
            try {
                result = await human.detect(input)
            } finally {
                input.dispose()
            }

            const faces = []
            let tooSmall = 0
            for (const found of result.face || []) {
                const [x, y, width, height] = found.box
                if (width < cfg.minFacePx) { tooSmall += 1; continue }
                if (!found.embedding || !found.embedding.length) continue
                const thumbRgba = cropSquare(frame, { x, y, width, height }, cfg.thumbSize)
                faces.push({
                    box: { x, y, width, height },
                    descriptor: Array.from(found.embedding, value => Math.round(value * 1e5) / 1e5),
                    sharpness: sharpness(thumbRgba, cfg.thumbSize),
                    thumbRgba,
                })
            }
            faces.sort((a, b) => b.box.width * b.box.height - a.box.width * a.box.height)

            return { faces: faces.slice(0, cfg.maxFaces), tooSmall }
        },
    }
}

module.exports = { createDetector }
