'use strict'
/**
 * Ghim chứng chỉ HTTPS (certificate pinning) cho máy chủ dùng chứng chỉ tự ký, ví dụ Laragon trong mạng LAN.
 *
 * Cách làm: kết nối TLS, KHÔNG xác thực theo chuỗi CA/tên máy, mà chỉ chấp nhận đúng chứng chỉ có vân tay
 * SHA-256 đã lưu (API_CERT_SHA256 trong .env). Chứng chỉ khác (kể cả chứng chỉ hợp lệ của kẻ khác) đều bị từ chối,
 * nên an toàn hơn nhiều so với NODE_TLS_REJECT_UNAUTHORIZED=0. Chỉ ảnh hưởng các lệnh gọi tới máy chủ QLBH.
 *
 * Lưu ý: fetch có sẵn của Node không cho đổi cách xác thực chứng chỉ, nên lúc ghim ta dùng https.request.
 */
const net = require('net')
const tls = require('tls')
const https = require('https')

class CertPinError extends Error {
    constructor(message, code = 'CERT_PIN_MISMATCH') {
        super(message)
        this.name = 'CertPinError'
        this.code = code
    }
}

/** Nhận vân tay ở nhiều dạng (AA:BB:.., aabb.., "SHA256:..", "sha256 Fingerprint=AA:..") -> 64 ký tự hex thường, hoặc ''. */
function normalizeFingerprint(raw) {
    const text = String(raw || '').trim().replace(/^.*fingerprint\s*=\s*/i, '').replace(/^sha-?256[:\s]*/i, '')
    const hex = text.replace(/[\s:]/g, '').toLowerCase()
    return /^[0-9a-f]{64}$/.test(hex) ? hex : ''
}

function formatFingerprint(hex) {
    return (String(hex).toUpperCase().match(/.{2}/g) || []).join(':')
}

function parseTarget(rawUrl) {
    const url = new URL(rawUrl)
    return {
        url,
        host: url.hostname.replace(/^\[|\]$/g, ''),
        port: Number(url.port) || 443,
        isHttps: url.protocol === 'https:',
    }
}

/** Mở kết nối TLS tới máy chủ, bỏ qua bước xác thực chuỗi chứng chỉ (người gọi tự kiểm tra vân tay). */
function openTlsSocket({ host, port }, timeoutMs) {
    return new Promise((resolve, reject) => {
        const socket = tls.connect({
            host,
            port,
            servername: net.isIP(host) ? undefined : host,
            rejectUnauthorized: false,
        })
        const fail = (error) => {
            clearTimeout(timer)
            socket.destroy()
            reject(error)
        }
        const timer = setTimeout(() => fail(Object.assign(new Error('hết thời gian chờ'), { code: 'ETIMEDOUT' })), timeoutMs)
        socket.once('error', fail)
        socket.once('secureConnect', () => {
            clearTimeout(timer)
            socket.removeListener('error', fail)
            resolve(socket)
        })
    })
}

/** Lấy thông tin chứng chỉ mà máy chủ đang trình ra (dùng cho lệnh ghim). */
async function fetchServerCert(apiUrl, timeoutMs = 6000) {
    const target = parseTarget(apiUrl)
    if (!target.isHttps) throw new Error('API_URL phải bắt đầu bằng https:// thì mới ghim được chứng chỉ.')
    const socket = await openTlsSocket(target, timeoutMs)
    try {
        const cert = socket.getPeerCertificate()
        return {
            fingerprint: normalizeFingerprint(cert.fingerprint256),
            subject: cert.subject?.CN || '',
            issuer: cert.issuer?.CN || '',
            validFrom: cert.valid_from || '',
            validTo: cert.valid_to || '',
            altNames: cert.subjectaltname || '',
            expired: cert.valid_to ? new Date(cert.valid_to).getTime() < Date.now() : false,
            // true nếu hệ điều hành/Node đã tin chứng chỉ này (khi đó không cần ghim)
            trusted: socket.authorized === true,
            trustError: socket.authorizationError ? String(socket.authorizationError) : '',
        }
    } finally {
        socket.destroy()
    }
}

/**
 * Gọi HTTPS tới máy chủ, chỉ chấp nhận chứng chỉ có vân tay `pin` (hex). Kiểm tra xong mới gửi dữ liệu.
 * Trả về { status, ok, json() } giống phần fetch API cần dùng.
 */
async function pinnedRequest(fullUrl, { method = 'GET', headers = {}, body, timeoutMs = 8000, pin }) {
    const target = parseTarget(fullUrl)
    if (!target.isHttps) throw new Error('Ghim chứng chỉ chỉ dùng được với địa chỉ https://')
    const started = Date.now()
    const socket = await openTlsSocket(target, timeoutMs)

    const actual = normalizeFingerprint(socket.getPeerCertificate().fingerprint256)
    if (actual !== pin) {
        socket.destroy()
        throw new CertPinError(
            'Chứng chỉ HTTPS của máy chủ KHÁC với chứng chỉ đã ghim (đang gặp ' + formatFingerprint(actual).slice(0, 14) + '…). '
            + 'Nếu bạn vừa đổi/cấp lại chứng chỉ trên máy chủ thì chạy lại "npm run pin-cert"; nếu không, đừng tiếp tục vì có thể có người chen vào đường truyền.',
        )
    }

    return new Promise((resolve, reject) => {
        const agent = new https.Agent({ keepAlive: false })
        agent.createConnection = () => socket // dùng lại đúng socket đã kiểm tra vân tay
        const remaining = Math.max(1000, timeoutMs - (Date.now() - started))
        let req
        const timer = setTimeout(() => req.destroy(Object.assign(new Error('hết thời gian chờ'), { code: 'ETIMEDOUT' })), remaining)

        req = https.request({
            agent,
            host: target.host,
            port: target.port,
            path: target.url.pathname + target.url.search,
            method,
            headers,
        }, (res) => {
            const chunks = []
            res.on('data', chunk => chunks.push(chunk))
            res.on('error', (error) => { clearTimeout(timer); reject(error) })
            res.on('end', () => {
                clearTimeout(timer)
                const text = Buffer.concat(chunks).toString('utf8')
                resolve({
                    status: res.statusCode,
                    ok: res.statusCode >= 200 && res.statusCode < 300,
                    json: async () => JSON.parse(text),
                })
            })
        })
        req.on('error', (error) => { clearTimeout(timer); socket.destroy(); reject(error) })
        req.end(body)
    })
}

module.exports = { CertPinError, normalizeFingerprint, formatFingerprint, fetchServerCert, pinnedRequest }
