'use strict'
const path = require('path')
const { normalizeFingerprint } = require('./tls')

const root = path.resolve(__dirname, '..')
const num = (name, fallback) => {
    const raw = process.env[name]
    if (raw === undefined || raw === '') return fallback
    const value = Number(raw)
    return Number.isFinite(value) ? value : fallback
}

/** "x,y,w,h" (0-1) -> { x, y, w, h } hoặc null nếu không đặt/không hợp lệ. */
function parseRoi(text) {
    const parts = String(text || '').split(',').map(item => Number(item.trim()))
    if (parts.length !== 4 || parts.some(value => !Number.isFinite(value))) return null
    const [x, y, w, h] = parts
    if (x < 0 || y < 0 || w <= 0.05 || h <= 0.05 || x + w > 1.0001 || y + h > 1.0001) return null
    return { x, y, w, h }
}

function load() {
    return {
        root,
        apiUrl: (process.env.API_URL || 'http://127.0.0.1:8000/api').replace(/\/+$/, ''),
        cameraKey: process.env.DOOR_CAMERA_KEY || '',
        // Vân tay SHA-256 của chứng chỉ HTTPS tự ký đã ghim (lệnh: npm run pin-cert). Trống = xác thực HTTPS như bình thường.
        certSha256: normalizeFingerprint(process.env.API_CERT_SHA256),
        certPinInvalid: Boolean((process.env.API_CERT_SHA256 || '').trim()) && !normalizeFingerprint(process.env.API_CERT_SHA256),
        snapshotUrl: (process.env.CAMERA_SNAPSHOT_URL || '').trim(),
        auth: (process.env.CAMERA_AUTH || 'none').toLowerCase(),
        user: process.env.CAMERA_USER || '',
        password: process.env.CAMERA_PASSWORD || '',
        modelsDir: path.resolve(root, process.env.MODELS_DIR || '../public/models/human'),
        // auto: thử tfjs-node, không được thì wasm | tfjs-node | wasm
        backend: (process.env.TF_BACKEND || 'auto').toLowerCase(),
        // Camera RTSP (cần ffmpeg)
        ffmpegPath: process.env.FFMPEG_PATH || 'ffmpeg',
        rtspTransport: (process.env.RTSP_TRANSPORT || 'tcp').toLowerCase(),
        rtspFps: num('RTSP_FPS', 4),
        // Chỉ dò mặt trong vùng cửa (tỉ lệ 0-1: x,y,rộng,cao so với khung hình), ví dụ 0.2,0.1,0.6,0.8. Vùng nhỏ => mặt to hơn trong mô hình, dò xa hơn và nhanh hơn.
        detectRoi: parseRoi(process.env.DETECT_ROI),

        frameIntervalMs: num('FRAME_INTERVAL_MS', 300),
        previewIntervalMs: num('PREVIEW_INTERVAL_MS', 1000), // camera http: gửi ảnh xem trước tối đa 1 ảnh/giây, chỉ khi có người đang xem
        previewFps: num('PREVIEW_FPS', 5), // camera RTSP: số khung/giây của ảnh xem trước
        previewWidth: num('PREVIEW_WIDTH', 480),
        idleIntervalMs: num('IDLE_INTERVAL_MS', 1000),
        detectorModel: process.env.FACE_DETECTOR_MODEL || 'blazeface.json',
        scoreThreshold: num('FACE_SCORE_THRESHOLD', 0.5),
        minFacePx: num('MIN_FACE_PX', 60),
        maxFaces: 6,

        // Theo dõi từng người qua các khung hình
        trackTtlMs: 4000, // mặt biến mất quá thời gian này thì bỏ theo dõi
        trackDistanceFactor: 1.0, // tâm mặt dịch chuyển tối đa = hệ số * cạnh lớn của khung mặt
        maxSamples: 4, // số khung nét nhất giữ lại cho mỗi người
        sendSamples: 3, // số khung gửi lên máy chủ để so khớp
        minSamples: 3, // đủ ngần này khung thì so khớp ngay
        maxWaitMs: 2500, // chờ tối đa rồi vẫn so khớp dù chưa đủ khung
        ambiguousRetryMs: 2500,
        unknownRetries: 4, // khách lạ: thử so khớp lại (phòng khi lần đầu ảnh xấu), nếu khớp thì gán lại
        unknownRetryMs: 5000,
        unknownRetryWindowMs: 60000,
        pingMs: 3000, // nhịp báo "người này vẫn ở cửa"
        heartbeatMs: 5000,
        thumbSize: 80,
    }
}

/** Phần cần có trước khi gọi được máy chủ: khóa + địa chỉ (do lệnh "npm run setup" ghi vào .env). */
function validateBase(cfg) {
    const problems = []
    if (!cfg.cameraKey) problems.push('Chưa có khóa camera. Chạy lệnh cài lấy ở Cài đặt → Khách hàng → Camera cửa (npm run setup -- --url ... --key ...).')
    if (!/^https?:\/\//i.test(cfg.apiUrl || '')) problems.push('API_URL phải là địa chỉ http/https của máy chủ QLBH.')
    if (cfg.certPinInvalid) problems.push('API_CERT_SHA256 không đúng định dạng (cần vân tay SHA-256 gồm 64 ký tự hex). Chạy lại: npm run pin-cert')
    if (!['auto', 'tfjs-node', 'wasm'].includes(cfg.backend)) problems.push('TF_BACKEND chỉ nhận: auto, tfjs-node hoặc wasm.')
    return problems
}

/** Thông tin camera (nhập ở Cài đặt → Khách hàng → Camera cửa, worker tự đọc về). */
function validateCamera(cfg) {
    const problems = []
    if (!/^(https?|rtsps?):\/\//i.test(cfg.snapshotUrl || '')) {
        problems.push('Chưa nhập địa chỉ camera (ảnh chụp http/https hoặc RTSP rtsp://) ở Cài đặt → Khách hàng → Camera cửa.')
        return problems
    }
    // Camera RTSP tự xử lý đăng nhập qua tài khoản/mật khẩu nên không cần kiểu đăng nhập.
    if (/^rtsps?:\/\//i.test(cfg.snapshotUrl)) return problems
    if (!['none', 'basic', 'digest'].includes(cfg.auth)) problems.push('Kiểu đăng nhập camera chỉ nhận: không, basic hoặc digest.')
    if (cfg.auth !== 'none' && !cfg.user) problems.push('Kiểu đăng nhập camera là ' + cfg.auth + ' nhưng chưa nhập tài khoản ở Cài đặt.')
    return problems
}

function validate(cfg) {
    return [...validateBase(cfg), ...validateCamera(cfg)]
}

/**
 * Áp thông tin camera lấy từ máy chủ vào cấu hình. Nếu .env của worker còn đặt tay CAMERA_SNAPSHOT_URL
 * (cách cũ) thì giữ nguyên, không ghi đè. Trả về true khi thông tin camera thật sự thay đổi.
 */
function applyRemote(cfg, remote, env = process.env) {
    let changed = false

    if (!env.CAMERA_SNAPSHOT_URL) {
        const camera = remote?.camera || {}
        const next = {
            snapshotUrl: String(camera.snapshot_url || '').trim(),
            auth: String(camera.auth || 'none').toLowerCase(),
            user: String(camera.username || ''),
            password: String(camera.password || ''),
        }
        if (Object.keys(next).some(key => cfg[key] !== next[key])) changed = true
        Object.assign(cfg, next)
    }

    // Thông số tinh chỉnh chỉnh ở Cài đặt → Khách hàng: luôn ưu tiên hơn giá trị trong .env (máy chủ cũ không gửi thì giữ nguyên).
    const tuning = remote?.tuning
    if (tuning && typeof tuning === 'object') {
        const pick = (value, fallback) => (Number.isFinite(Number(value)) && Number(value) > 0 ? Number(value) : fallback)
        const roi = tuning.detect_roi
        const next = {
            minFacePx: pick(tuning.min_face_px, cfg.minFacePx),
            rtspFps: pick(tuning.detect_fps, cfg.rtspFps),
            frameIntervalMs: pick(tuning.detect_interval_ms, cfg.frameIntervalMs),
            previewFps: pick(tuning.preview_fps, cfg.previewFps),
            previewWidth: pick(tuning.preview_width, cfg.previewWidth),
            detectRoi: roi && [roi.x, roi.y, roi.w, roi.h].every(value => Number.isFinite(Number(value)))
                ? { x: Number(roi.x), y: Number(roi.y), w: Number(roi.w), h: Number(roi.h) }
                : null,
        }
        for (const key of Object.keys(next)) {
            if (JSON.stringify(cfg[key]) !== JSON.stringify(next[key])) changed = true
        }
        Object.assign(cfg, next)
    }

    return changed
}

module.exports = { load, validate, validateBase, validateCamera, applyRemote }
