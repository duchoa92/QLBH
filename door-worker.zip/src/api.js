'use strict'
const { CertPinError, pinnedRequest } = require('./tls')

// Lỗi chứng chỉ HTTPS mà việc ghim chứng chỉ (npm run pin-cert) giải quyết được.
const CERT_ERRORS = new Set([
    'DEPTH_ZERO_SELF_SIGNED_CERT', 'SELF_SIGNED_CERT_IN_CHAIN', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
    'UNABLE_TO_GET_ISSUER_CERT_LOCALLY', 'CERT_HAS_EXPIRED', 'ERR_TLS_CERT_ALTNAME_INVALID',
])

function describeNetworkError(error) {
    if (error instanceof CertPinError) return error.message
    const code = error?.cause?.code || error?.code
    const text = code || error?.message || 'lỗi mạng'
    if (CERT_ERRORS.has(code)) {
        return `${text}. Máy chủ dùng chứng chỉ HTTPS tự ký: chạy "npm run pin-cert" để ghim chứng chỉ đó (làm một lần, không cần đặt biến môi trường).`
    }
    return text
}

class ApiError extends Error {
    constructor(message, status, data) {
        super(message)
        this.name = 'ApiError'
        this.status = status
        this.data = data
    }
}

/** Gọi API của Laravel bằng khóa X-Camera-Key (không cần đăng nhập). */
function createApi(cfg, { timeoutMs = 8000 } = {}) {
    const call = async (method, path, body, contentType = 'application/json') => {
        let response
        const url = cfg.apiUrl + path
        const headers = { 'X-Camera-Key': cfg.cameraKey, Accept: 'application/json', 'Content-Type': contentType }
        const payload = body === undefined ? undefined : (Buffer.isBuffer(body) ? body : JSON.stringify(body))
        if (Buffer.isBuffer(payload)) headers['Content-Length'] = String(payload.length)
        try {
            // Có ghim chứng chỉ (API_CERT_SHA256) và địa chỉ https -> chỉ chấp nhận đúng chứng chỉ đó.
            if (cfg.certSha256 && /^https:/i.test(url)) {
                response = await pinnedRequest(url, { method, headers, body: payload, timeoutMs, pin: cfg.certSha256 })
            } else {
                response = await fetch(url, { method, headers, body: payload, signal: AbortSignal.timeout(timeoutMs), redirect: 'manual' })
            }
        } catch (error) {
            throw new ApiError('Không gọi được máy chủ: ' + describeNetworkError(error), 0, null)
        }

        let data = null
        try { data = await response.json() } catch { /* không phải JSON */ }
        if (response.status >= 300 && response.status < 400) {
            throw new ApiError('Máy chủ chuyển hướng (kiểm tra API_URL, có thể thiếu /api hoặc sai http/https).', response.status, data)
        }
        if (!response.ok) throw new ApiError(data?.message || `Máy chủ trả về lỗi ${response.status}`, response.status, data)
        return data
    }

    return {
        heartbeat: payload => call('POST', '/door-camera/heartbeat', payload),
        /** Thông tin camera nhập ở Cài đặt: { enabled, camera: { snapshot_url, auth, username, password }, config_hash } */
        config: () => call('GET', '/door-camera/config'),
        /** faces: [{ key, descriptors: [vector...] }] -> { results: [{ key, matched, customer?, ambiguous? }] } */
        faceMatch: faces => call('POST', '/door-camera/face-match', { faces }),
        /** Gửi ảnh JPEG nhỏ (xem trước camera cửa trên POS / trang Lượt khách). */
        sendFrame: jpeg => call('POST', '/door-camera/frame', jpeg, 'image/jpeg'),
        /** Ảnh nguyên bản (độ phân giải gốc) để đăng ký khuôn mặt từ camera cửa. */
        sendSnapshot: jpeg => call('POST', '/door-camera/snapshot', jpeg, 'image/jpeg'),
        record: payload => call('POST', '/door-camera/visits', payload),
        seen: visitId => call('POST', `/door-camera/visits/${visitId}/seen`),
        link: (visitId, customerId) => call('POST', `/door-camera/visits/${visitId}/link`, { customer_id: customerId, consent: false }),
    }
}

module.exports = { createApi, ApiError }
