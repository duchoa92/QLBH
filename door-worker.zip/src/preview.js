'use strict'
/**
 * Ảnh xem trước camera RTSP mượt (vài khung/giây): một tiến trình ffmpeg RIÊNG, đã thu nhỏ sẵn và mã hóa JPEG nên không phải
 * giải mã trong Node, không ảnh hưởng tốc độ nhận diện. Chỉ chạy khi máy chủ báo có người đang xem, tự dừng khi không còn ai xem.
 * Camera http (ảnh chụp tĩnh) không dùng bộ này: máy chủ tự lấy ảnh hoặc vòng nhận diện gửi ảnh.
 */
const { spawn: nodeSpawn } = require('child_process')
const { isRtsp, buildRtspUrl, JpegSplitter } = require('./rtsp')

function previewArgs(cfg, url) {
    const fps = Number(cfg.previewFps) > 0 ? Number(cfg.previewFps) : 5
    const width = Number(cfg.previewWidth) > 0 ? Math.round(Number(cfg.previewWidth) / 2) * 2 : 480
    return [
        '-hide_banner', '-loglevel', 'error', '-nostdin',
        '-fflags', 'nobuffer', '-flags', 'low_delay',
        '-rtsp_transport', cfg.rtspTransport === 'udp' ? 'udp' : 'tcp',
        '-i', url, '-an',
        '-vf', `fps=${fps},scale=${width}:-2`,
        '-q:v', '7', '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1',
    ]
}

function createPreview({ cfg, api, log, spawn = nodeSpawn, restartDelayMs = 3000 }) {
    let url = null
    let lastSignature = null
    let wanted = false
    let child = null
    let busy = false
    let pending = null // khung mới nhất đang chờ gửi (khung cũ bị bỏ để không bị trễ)
    let restartTimer = null
    let state = null // 'ok' hoặc nội dung lỗi gần nhất: chỉ ghi log khi đổi

    const report = (next, text) => {
        if (state === next) return
        state = next
        if (next === 'ok') log.info('Đang gửi ảnh xem trước camera cửa lên máy chủ.')
        else log.warn(text)
    }

    const send = async (jpeg) => {
        if (busy) { pending = jpeg; return }
        busy = true
        try {
            await api.sendFrame(jpeg)
            report('ok')
        } catch (error) {
            const text = 'Gửi ảnh xem trước lỗi: ' + String(error?.message || error)
            report(text, text)
        } finally {
            busy = false
            if (pending) { const next = pending; pending = null; send(next) }
        }
    }

    const stopProcess = () => {
        clearTimeout(restartTimer)
        restartTimer = null
        const proc = child
        child = null
        pending = null
        if (proc) { try { proc.kill('SIGKILL') } catch { /* đã thoát */ } }
    }

    const start = () => {
        if (child || !wanted || !url) return
        const splitter = new JpegSplitter()
        let stderr = ''
        let proc
        try {
            proc = spawn(cfg.ffmpegPath || 'ffmpeg', previewArgs(cfg, url), { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
        } catch (error) {
            report('spawn:' + error?.code, 'Không chạy được ffmpeg cho ảnh xem trước: ' + (error?.message || error))
            return
        }
        child = proc
        const ended = (text) => {
            if (child !== proc) return
            child = null
            if (text) report('exit:' + text, 'Ảnh xem trước dừng: ' + text)
            if (wanted && !restartTimer) {
                restartTimer = setTimeout(() => { restartTimer = null; start() }, restartDelayMs)
                restartTimer.unref?.()
            }
        }
        proc.stdout.on('data', (chunk) => {
            const frames = splitter.push(chunk)
            if (frames.length) send(frames[frames.length - 1])
        })
        proc.stderr.on('data', (data) => { stderr = (stderr + data).slice(-400) })
        proc.on('error', error => ended(error?.code === 'ENOENT' ? 'chưa cài ffmpeg' : String(error?.message)))
        proc.on('close', code => ended(`ffmpeg thoát (mã ${code ?? '?'}) ${stderr.trim().split(/\r?\n/).pop() || ''}`.trim()))
    }

    return {
        /** Camera đổi (hoặc nạp lại từ Cài đặt): chỉ camera RTSP dùng ffmpeg riêng. */
        setCamera(camera) {
            const next = camera && isRtsp(camera.snapshotUrl) ? buildRtspUrl(camera.snapshotUrl, camera.user, camera.password) : null
            // Đổi địa chỉ hoặc thông số ảnh xem trước (Cài đặt) thì chạy lại ffmpeg với thông số mới.
            const signature = next ? `${next}|${camera.previewFps}|${camera.previewWidth}|${camera.rtspTransport}` : null
            if (signature === lastSignature) return
            lastSignature = signature
            stopProcess()
            url = next
            start()
        },
        /** true khi máy chủ báo đang có người xem. */
        setWanted(value) {
            if (wanted === !!value) return
            wanted = !!value
            if (wanted) start()
            else stopProcess()
        },
        /** Bộ này có đang phụ trách ảnh xem trước (camera RTSP) không. */
        get handles() { return url !== null },
        close() { wanted = false; stopProcess() },
    }
}

module.exports = { createPreview, previewArgs }
