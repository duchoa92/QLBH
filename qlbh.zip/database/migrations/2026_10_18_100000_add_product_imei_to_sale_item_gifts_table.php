<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sale_item_gifts', function (Blueprint $table) {
            $table->foreignId('product_imei_id')
                ->nullable()
                ->after('product_id')
                ->constrained('product_imeis')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('sale_item_gifts', function (Blueprint $table) {
            $table->dropForeign(['product_imei_id']);
            $table->dropColumn('product_imei_id');
        });
    }
};
