<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stock_import_items', function (Blueprint $table) {
            $table->id();

            $table->foreignId('stock_import_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->constrained();
            $table->foreignId('variant_id')->nullable()->constrained('product_variants');
            $table->foreignId('unit_id')
                ->nullable()
                ->constrained()
                ->nullOnDelete();
            $table->string('unit_name')
                ->nullable();

            $table->integer('quantity')->default(0);
            $table->decimal('cost_price', 12, 2)->default(0);

            $table->timestamps();


        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stock_import_items');
    }
};
