<?php

use App\Http\Controllers\BrandController;
use App\Http\Controllers\Setup\InstallerController;
use App\Http\Controllers\BackupController;
use App\Http\Controllers\BackupCloudOAuthController;
use App\Http\Controllers\CategoryAttributeController;
use App\Http\Controllers\CategoryAttributeValueController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DebtPaymentController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\TaxDeclarationController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\WorkShiftController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductImageController;
use App\Http\Controllers\ProductImeiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RepairController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\RecordDetailController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\SaleReceiptController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SystemCleanupController;
use App\Http\Controllers\StockImportController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleManagementController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Trang gốc: điều hướng thẳng, không dùng trang Welcome mặc định của Laravel
|--------------------------------------------------------------------------
*/
Route::get('/setup', [InstallerController::class, 'index'])->name('setup.index');
Route::post('/setup/test', [InstallerController::class, 'test'])->name('setup.test');
Route::post('/setup/install', [InstallerController::class, 'install'])->name('setup.install');

Route::get('/', function () {
    return auth()->check()
        ? redirect(auth()->user()->landingPath())
        : redirect()->route('login');
});

Route::get('/product-images/{filename}', [ProductImageController::class, 'show'])
    ->where('filename', '[A-Za-z0-9._-]+')
    ->name('product-images.show');

/*
|--------------------------------------------------------------------------
| Authenticated Routes (Yêu cầu đăng nhập)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {

    Route::get('/records/{type}/{id}', [RecordDetailController::class, 'show'])
        ->where('type', 'product|imei|customer|supplier|sale|stock-import|repair|category|brand|unit|user')
        ->whereNumber('id')->name('records.show');

    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::patch('/notifications/read-all', [NotificationController::class, 'markAllRead'])->name('notifications.read-all');
    Route::patch('/notifications/{notification}/read', [NotificationController::class, 'markRead'])->name('notifications.read');
    Route::delete('/notifications/{notification}', [NotificationController::class, 'destroy'])->name('notifications.destroy');

    // Dashboard
    Route::get(
        '/dashboard',
        [DashboardController::class, 'index']
    )->middleware(['verified', 'permission:dashboard.view'])->name('dashboard');

    // Settings
    Route::get('/settings', [SettingController::class, 'index'])->middleware('permission:settings.view')->name('settings.index');
    Route::post('/settings', [SettingController::class, 'update'])->middleware('permission:settings.edit|payment_accounts.manage|units.manage')->name('settings.update');
    Route::get('/settings/system-cleanup/scan', [SystemCleanupController::class, 'scan'])->middleware('permission:settings.edit')->name('settings.cleanup.scan');
    Route::delete('/settings/system-cleanup', [SystemCleanupController::class, 'destroy'])->middleware('permission:settings.edit')->name('settings.cleanup.destroy');
    Route::get('/backups', [BackupController::class, 'index'])->middleware('permission:backups.manage')->name('backups.index');
    Route::post('/backups', [BackupController::class, 'store'])->middleware('permission:backups.manage')->name('backups.store');
    Route::post('/backups/clear-data', [BackupController::class, 'clearData'])->middleware('permission:backups.manage')->name('backups.clear-data');
    Route::get('/backups/cloud/oauth/{provider}/start', [BackupCloudOAuthController::class, 'start'])->middleware('permission:backups.manage')->name('backups.cloud.oauth.start');
    Route::get('/backups/cloud/oauth/{provider}/callback', [BackupCloudOAuthController::class, 'callback'])->middleware('permission:backups.manage')->name('backups.cloud.oauth.callback');
    Route::delete('/backups/cloud-connections/{connection}', [BackupController::class, 'destroyCloudConnection'])->middleware('permission:backups.manage')->name('backups.cloud-connections.destroy');
    Route::patch('/backups/cloud-connections/{connection}/toggle', [BackupController::class, 'toggleCloudConnection'])->middleware('permission:backups.manage')->name('backups.cloud-connections.toggle');
    Route::post('/backups/cloud/{connection}/inspect', [BackupController::class, 'inspectCloudBackup'])->middleware('permission:backups.manage')->name('backups.cloud.inspect');
    Route::delete('/backups/cloud/{connection}', [BackupController::class, 'destroyCloudBackup'])->middleware('permission:backups.manage')->name('backups.cloud.destroy');
    Route::post('/backups/import', [BackupController::class, 'import'])->middleware('permission:backups.manage')->name('backups.import');
    Route::get('/backups/progress/{operation}', [BackupController::class, 'progress'])->middleware('permission:backups.manage')->name('backups.progress');
    Route::post('/backups/{backup}/inspect', [BackupController::class, 'inspect'])->middleware('permission:backups.manage')->name('backups.inspect');
    Route::post('/backups/{backup}/restore', [BackupController::class, 'restore'])->middleware('permission:backups.manage')->name('backups.restore');
    Route::get('/backups/{backup}/download', [BackupController::class, 'download'])->middleware('permission:backups.manage')->name('backups.download');
    Route::delete('/backups/bulk', [BackupController::class, 'destroyMany'])->middleware('permission:backups.manage')->name('backups.bulk-destroy');
    Route::delete('/backups/{backup}', [BackupController::class, 'destroy'])->middleware('permission:backups.manage')->name('backups.destroy');
    Route::put('/backups/schedule', [BackupController::class, 'updateSchedule'])->middleware('permission:backups.manage')->name('backups.schedule');
    Route::post('/units', [UnitController::class, 'store'])->middleware('permission:units.manage')->name('units.store');
    Route::put('/units/{unit}', [UnitController::class, 'update'])->middleware('permission:units.manage')->name('units.update');
    Route::patch('/units/{unit}/toggle-status', [UnitController::class, 'toggleStatus'])->middleware('permission:units.manage')->name('units.toggleStatus');
    Route::delete('/units/{unit}', [UnitController::class, 'destroy'])->middleware('permission:units.manage')->name('units.destroy');

    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    /*
    |--------------------------------------------------------------------------
    | Products & Inventory
    |--------------------------------------------------------------------------
    */
    Route::prefix('products')->name('products.')->group(function () {

        /* Static Routes (Đặt lên trước Dynamic Parameters) */
        Route::get('/template', [ProductController::class, 'template'])->middleware('permission:products.import')->name('template');
        Route::post('/import', [ProductController::class, 'import'])->middleware('permission:products.import')->name('import');
        Route::post('/validate', [ProductController::class, 'previewImport'])->middleware('permission:products.import')->name('validate');
        Route::post('/import-images', [ProductController::class, 'uploadImportImages'])->middleware('permission:products.import')->name('import.images');
        Route::get('/list-import', [ProductController::class, 'listForImport'])->middleware('permission:products.view|stock_imports.view|stock_imports.create')->name('listImport');

        // Export
        Route::post('/export-start', [ProductController::class, 'startExport'])->middleware('permission:products.export')->name('export.start');
        Route::get('/export-check/{id}', [ProductController::class, 'checkExport'])->middleware('permission:products.export')->name('export.check');
        Route::get('/export-download/{id}', [ProductController::class, 'downloadExport'])->middleware('permission:products.export')->name('export.download');
        Route::post('/export-errors', [ProductController::class, 'exportErrors'])->middleware('permission:products.export')->name('export.errors');

        // Trash & Bulk
        Route::get('/trash', [ProductController::class, 'trash'])->middleware('permission:products.view')->name('trash');
        Route::post('/bulk-delete', [ProductController::class, 'bulkDelete'])->middleware('permission:products.delete')->name('bulkDelete');
        Route::patch('/bulk-price', [ProductController::class, 'bulkUpdatePrice'])->middleware('permission:products.edit')->name('bulk-price');
        Route::post('/bulk-restore', [ProductController::class, 'bulkRestore'])->middleware('permission:products.edit')->name('bulkRestore');
        Route::post('/bulk-force-delete', [ProductController::class, 'bulkForceDelete'])->middleware('permission:products.delete')->name('bulkForceDelete');

        // Preview SKU
        Route::get('/preview-sku', [ProductController::class, 'previewSku'])->middleware('permission:products.create|stock_imports.create')->name('previewSku');

        // Standard CRUD
        Route::get('/', [ProductController::class, 'index'])->middleware('permission:products.view')->name('index');
        Route::get('/create', [ProductController::class, 'create'])->middleware('permission:products.create')->name('create');
        Route::post('/', [ProductController::class, 'store'])->middleware('permission:products.create|stock_imports.create')->name('store');

        /* Dynamic Routes (Các route có tham số ID/{product} đặt ở cuối) */
        Route::get('/{product}', [ProductController::class, 'show'])->whereNumber('product')->middleware('permission:products.view')->name('show');
        Route::get('/{product}/edit', [ProductController::class, 'edit'])->middleware('permission:products.edit')->name('edit');
        Route::put('/{product}', [ProductController::class, 'update'])->middleware('permission:products.edit')->name('update');
        Route::delete('/{product}', [ProductController::class, 'destroy'])->middleware('permission:products.delete')->name('destroy');

        Route::post('/{id}/restore', [ProductController::class, 'restore'])->middleware('permission:products.edit')->name('restore');
        Route::delete('/{id}/force', [ProductController::class, 'forceDelete'])->middleware('permission:products.delete')->name('forceDelete');
        Route::patch('/{product}/toggle-status', [ProductController::class, 'toggleStatus'])->middleware('permission:products.edit')->name('toggleStatus');
    });

    // Attributes & Variants
    Route::prefix('category-attributes')->group(function () {
        Route::post('/', [CategoryAttributeController::class, 'store'])->middleware('permission:categories.edit')->name('attributes.store');
        Route::put('/{attribute}', [CategoryAttributeController::class, 'update'])->middleware('permission:categories.edit')->name('attributes.update');
        Route::delete('/{attribute}', [CategoryAttributeController::class, 'destroy'])->middleware('permission:categories.edit')->name('attributes.destroy');
    });

    Route::prefix('category-attribute-values')->group(function () {
        Route::get('/{attributeId}', [CategoryAttributeValueController::class, 'index'])->middleware('permission:categories.view');
        Route::post('/', [CategoryAttributeValueController::class, 'store'])->middleware('permission:categories.edit');
        Route::put('/{id}', [CategoryAttributeValueController::class, 'update'])->middleware('permission:categories.edit');
        Route::delete('/{id}', [CategoryAttributeValueController::class, 'destroy'])->middleware('permission:categories.edit');
    });

    // Stock Import (Nhập hàng)
    Route::get(
        '/stock-import',
        [StockImportController::class, 'index']
    )->middleware('permission:stock_imports.view')->name('stock.index');

    Route::get(
        '/stock-import/replenishment-products',
        [StockImportController::class, 'replenishmentProducts']
    )->middleware('permission:stock_imports.view')->name('stock.replenishment-products');

    Route::get(
        '/stock-import/suppliers/{supplier}/outstanding-orders',
        [StockImportController::class, 'supplierOutstandingOrders']
    )->middleware('permission:stock_imports.create')->name('stock.import.suppliers.outstanding-orders');

    Route::post(
        '/stock-import',
        [StockImportController::class, 'store']
    )->middleware('permission:stock_imports.create')->name('stock.import');

    Route::get(
        '/stock-import/customers/search',
        [StockImportController::class, 'searchCustomers']
    )->middleware('permission:stock_imports.create')->name('stock.import.customers.search');

    Route::get(
        '/stock-import/{stockImport}/contract',
        [StockImportController::class, 'contract']
    )->middleware('permission:stock_imports.view')->name('stock.import.contract');

    Route::post(
        '/stock-import/{stockImport}/cancel',
        [StockImportController::class, 'cancel']
    )->middleware('permission:stock_imports.create')->name('stock.import.cancel');

    Route::put(
        '/stock-import/{stockImport}',
        [StockImportController::class, 'update']
    )->middleware('permission:stock_imports.create')->name('stock.import.update');

    Route::get(
        '/stock-import/{stockImport}',
        [StockImportController::class, 'show']
    )->middleware('permission:stock_imports.view')->name('stock.show');

    /*
    |--------------------------------------------------------------------------
    | Users, Categories & Brands
    |--------------------------------------------------------------------------
    */
    // Users
    Route::get('/users', [UserController::class, 'index'])->middleware('permission:users.view')->name('users.index');
    Route::get('/users/create', [UserController::class, 'create'])->middleware('permission:users.create')->name('users.create');
    Route::post('/users', [UserController::class, 'store'])->middleware('permission:users.create')->name('users.store');
    Route::get('/users/{user}/edit', [UserController::class, 'edit'])->middleware('permission:users.edit')->name('users.edit');
    Route::put('/users/{user}', [UserController::class, 'update'])->middleware('permission:users.edit')->name('users.update');
    Route::delete('/users/{user}', [UserController::class, 'destroy'])->middleware('permission:users.delete')->name('users.destroy');
    Route::get('/roles/options', [RoleManagementController::class, 'options'])->middleware('permission:roles.manage')->name('roles.options');
    Route::post('/roles', [RoleManagementController::class, 'store'])->middleware('permission:roles.manage')->name('roles.store');
    Route::put('/roles/{role}', [RoleManagementController::class, 'update'])->middleware('permission:roles.manage')->name('roles.update');
    Route::delete('/roles/{role}', [RoleManagementController::class, 'destroy'])->middleware('permission:roles.manage')->name('roles.destroy');

    // Categories
    Route::get('/categories/trash', [CategoryController::class, 'trash'])->middleware('permission:categories.view')->name('categories.trash');
    Route::post('/categories/{id}/restore', [CategoryController::class, 'restore'])->middleware('permission:categories.edit')->name('categories.restore');
    Route::delete('/categories/{id}/force', [CategoryController::class, 'forceDelete'])->middleware('permission:categories.delete')->name('categories.forceDelete');
    Route::patch('/categories/{id}/toggle-status', [CategoryController::class, 'toggleStatus'])->middleware('permission:categories.edit')->name('categories.toggleStatus');
    Route::resource('categories', CategoryController::class)
        ->middlewareFor(['index', 'show'], 'permission:categories.view')
        ->middlewareFor(['create', 'store'], 'permission:categories.create')
        ->middlewareFor(['edit', 'update'], 'permission:categories.edit')
        ->middlewareFor('destroy', 'permission:categories.delete');

    // Brands
    Route::get('/brands/trash', [BrandController::class, 'trash'])->middleware('permission:brands.view')->name('brands.trash');
    Route::post('/brands/{id}/restore', [BrandController::class, 'restore'])->middleware('permission:brands.edit')->name('brands.restore');
    Route::delete('/brands/{id}/force', [BrandController::class, 'forceDelete'])->middleware('permission:brands.delete')->name('brands.forceDelete');
    Route::patch('/brands/{id}/toggle-status', [BrandController::class, 'toggleStatus'])->middleware('permission:brands.edit')->name('brands.toggleStatus');
    Route::resource('brands', BrandController::class)
        ->middlewareFor(['index', 'show'], 'permission:brands.view')
        ->middlewareFor(['create', 'store'], 'permission:brands.create')
        ->middlewareFor(['edit', 'update'], 'permission:brands.edit')
        ->middlewareFor('destroy', 'permission:brands.delete');

    /*
    |--------------------------------------------------------------------------
    | POS, Sales & Repairs
    |--------------------------------------------------------------------------
    */
    // POS
    Route::get('/work-shifts', [WorkShiftController::class, 'index'])->middleware('permission:pos.access')->name('work-shifts.index');
    Route::prefix('pos/shifts')->name('pos.shifts.')->controller(WorkShiftController::class)->middleware('permission:pos.access')->group(function () {
        Route::get('/current', 'current')->name('current');
        Route::post('/dismiss-prompt', 'dismissPrompt')->name('dismiss-prompt');
        Route::get('/history', 'history')->name('history');
        Route::post('/', 'open')->name('open');
        Route::post('/close', 'close')->name('close');
    });
    Route::prefix('pos')->name('pos.')->controller(PosController::class)->group(function () {
        Route::get('/', 'index')->middleware('permission:pos.access')->name('index');
        Route::get('/payment-settings', 'paymentSettings')->middleware('permission:pos.access')->name('payment-settings');
        Route::post('/checkout', 'checkout')->middleware('permission:pos.access')->name('checkout');
        Route::post('/bank-payments', 'startBankPayment')->middleware('permission:pos.access')->name('bank-payments.start');
        Route::get('/bank-payments/{intent}', 'bankPaymentStatus')->middleware('permission:pos.access')->name('bank-payments.status');
        Route::delete('/bank-payments/{intent}', 'cancelBankPayment')->middleware('permission:pos.access')->name('bank-payments.cancel');
    });

    // Sales Management
    Route::prefix('sales')->name('sales.')->controller(SaleController::class)->group(function () {
        Route::get('/', 'index')->middleware('permission:sales.view')->name('index');
        Route::get('/products/search', 'searchProducts')->middleware('permission:sales.edit')->name('products.search');
        Route::get('/products/{product}/imeis', 'searchAvailableImeis')->middleware('permission:sales.edit')->name('products.imeis');
        Route::get('/customers/search', 'searchCustomers')->middleware('permission:sales.edit')->name('customers.search');
        Route::get('/{sale}/edit', 'edit')->middleware('permission:sales.edit')->name('edit');
        Route::put('/{sale}', 'update')->middleware('permission:sales.edit')->name('update');
        Route::get('/{sale}', 'show')->middleware('permission:sales.view')->name('show');
        // Hủy hóa đơn
        Route::post('/{sale}/cancel', 'cancel')->middleware('permission:sales.cancel')->name('cancel');
    });
    Route::get('/sales/{sale}/receipt', [SaleReceiptController::class, 'show'])->middleware('permission:sales.view')->name('sales.receipt');

    // Repairs (Đã đưa các Route tĩnh lên TRƯỚC Resource)
    Route::get('/repairs/suggestions', [RepairController::class, 'suggestions'])->middleware('permission:repairs.view')->name('repairs.suggestions');
    Route::get('/repairs/customers/{customer}/devices', [RepairController::class, 'customerDevices'])->middleware('permission:repairs.view')->name('repairs.customer-devices');
    Route::get('/repairs/customer-by-phone', [RepairController::class, 'customerByPhone'])->middleware('permission:repairs.create|repairs.edit')->name('repairs.customer-by-phone');
    Route::get('/repairs/{repair}/images/{image}', [RepairController::class, 'image'])->whereNumber('repair')->whereNumber('image')->middleware('permission:repairs.view|repairs.create|repairs.edit|repairs.complete')->name('repairs.images.show');
    Route::delete('/repairs/{repair}/images/{image}', [RepairController::class, 'destroyImage'])->whereNumber('repair')->whereNumber('image')->middleware('permission:repairs.edit|repairs.create')->name('repairs.images.destroy');
    Route::get('/repairs/{repair}/credentials', [RepairController::class, 'credentials'])->middleware('permission:repairs.create|repairs.edit|repairs.complete')->name('repairs.credentials');
    Route::patch('/repairs/{repair}/status', [RepairController::class, 'updateStatus'])->middleware('permission:repairs.edit')->name('repairs.update-status');
    Route::patch('/repairs/{repair}/warranty/decline', [RepairController::class, 'declineWarranty'])->middleware('permission:repairs.edit')->name('repairs.warranty-decline');
    Route::post('/repairs/{repair}/complete', [RepairController::class, 'complete'])->middleware('permission:repairs.complete')->name('repairs.complete');
    Route::post('/repairs/{repair}/return', [RepairController::class, 'returnToCustomer'])->middleware('permission:repairs.return')->name('repairs.return');
    Route::get('/repairs/{repair}/print', [RepairController::class, 'print'])->middleware('permission:repairs.view')->name('repairs.print');
    Route::get('/repairs', [RepairController::class, 'index'])->middleware('permission:repairs.view')->name('repairs.index');
    Route::post('/repairs', [RepairController::class, 'store'])->middleware('permission:repairs.create')->name('repairs.store');
    Route::match(['put', 'patch'], '/repairs/{repair}', [RepairController::class, 'update'])->middleware('permission:repairs.edit')->name('repairs.update');
    Route::delete('/repairs/{repair}', [RepairController::class, 'destroy'])->name('repairs.destroy');
    // IMEIs, Customers, Suppliers
    Route::get('/api/imeis/lookup', [ProductImeiController::class, 'lookup'])->middleware('permission:products.view')->name('api.imeis.lookup');
    Route::patch('/product-imeis/imei/{imei}/price', [ProductImeiController::class, 'updatePrice'])->middleware('permission:products.edit')->name('product-imeis.update-price');

    Route::prefix('product-imeis')->name('product-imeis.')->controller(ProductImeiController::class)->group(function () {
        Route::get('/{product}', 'index')->middleware('permission:products.view')->name('index');
        Route::post('/{product}', 'store')->middleware('permission:products.edit')->name('store');
    });
    Route::get('/lookup', [ProductImeiController::class, 'lookupPage'])->middleware('permission:products.view')->name('product-imeis.lookup');
    // Link cũ của trang Tra cứu — phải đặt trước /imeis/{imei} để không bị hiểu là một IMEI.
    Route::redirect('/imeis/lookup', '/lookup');
    Route::get('/imeis/{imei}', [ProductImeiController::class, 'show'])->middleware('permission:products.view')->name('product-imeis.show');

    Route::resource('customers', CustomerController::class)
        ->middlewareFor(['index', 'show'], 'permission:customers.view')
        ->middlewareFor(['create', 'store'], 'permission:customers.create')
        ->middlewareFor(['edit', 'update'], 'permission:customers.edit')
        ->middlewareFor('destroy', 'permission:customers.delete');
    Route::delete('/customers/{customer}', [CustomerController::class, 'destroy'])->name('customers.destroy');
    Route::patch('/customers/{customer}/block', [CustomerController::class, 'toggleBlock'])->name('customers.block');

    Route::get('/debts/customers', [DebtPaymentController::class, 'customers'])->middleware('permission:customer_debts.view')->name('debts.customers');
    Route::get('/debts/customers/orders/{sale}', [DebtPaymentController::class, 'customerOrderDetail'])->middleware('permission:customer_debts.view')->name('debts.customers.orders.show');
    Route::post('/debts/customers/{customer}/payments', [DebtPaymentController::class, 'receiveCustomerPayment'])->middleware('permission:customer_debts.pay')->name('debts.customers.payments');
    Route::get('/debts/suppliers', [DebtPaymentController::class, 'suppliers'])->middleware('permission:supplier_debts.view')->name('debts.suppliers');
    Route::get('/debts/suppliers/orders/{stockImport}', [DebtPaymentController::class, 'supplierOrderDetail'])->middleware('permission:supplier_debts.view')->name('debts.suppliers.orders.show');
    Route::post('/debts/suppliers/{supplier}/payments', [DebtPaymentController::class, 'paySupplier'])->middleware('permission:supplier_debts.pay')->name('debts.suppliers.payments');
    Route::get('/expenses', [ExpenseController::class, 'index'])->middleware('permission:expenses.view')->name('expenses.index');
    Route::post('/expenses', [ExpenseController::class, 'store'])->middleware('permission:expenses.manage')->name('expenses.store');
    Route::put('/expenses/{expense}', [ExpenseController::class, 'update'])->middleware('permission:expenses.manage')->name('expenses.update');
    Route::delete('/expenses/{expense}', [ExpenseController::class, 'destroy'])->middleware('permission:expenses.manage')->name('expenses.destroy');
    Route::post('/expenses/recurring', [ExpenseController::class, 'storeRecurring'])->middleware('permission:expenses.manage')->name('expenses.recurring.store');
    Route::put('/expenses/recurring/{recurringExpense}', [ExpenseController::class, 'updateRecurring'])->middleware('permission:expenses.manage')->name('expenses.recurring.update');
    Route::delete('/expenses/recurring/{recurringExpense}', [ExpenseController::class, 'destroyRecurring'])->middleware('permission:expenses.manage')->name('expenses.recurring.destroy');
    Route::post('/expenses/recurring/{recurringExpense}/paid', [ExpenseController::class, 'markRecurringPaid'])->middleware('permission:expenses.manage')->name('expenses.recurring.paid');
    Route::get('/tax-declaration', [TaxDeclarationController::class, 'index'])->middleware('permission:reports.view')->name('tax-declaration.index');
    Route::get('/api/suppliers/search', [SupplierController::class, 'search'])->middleware('permission:suppliers.view|stock_imports.view|stock_imports.create')->name('api.suppliers.search');
    Route::resource('suppliers', SupplierController::class)
        ->middlewareFor(['index', 'show'], 'permission:suppliers.view')
        ->middlewareFor(['create', 'store'], 'permission:suppliers.create')
        ->middlewareFor(['edit', 'update'], 'permission:suppliers.edit')
        ->middlewareFor('destroy', 'permission:suppliers.delete');

    /*
    |--------------------------------------------------------------------------
    | Reports (Báo cáo & Thống kê)
    |--------------------------------------------------------------------------
    */
    Route::prefix('reports')->name('reports.')->controller(ReportController::class)->group(function () {
        Route::get('/', 'index')->middleware('permission:reports.view')->name('index');
        Route::get('/revenue', 'revenue')->middleware('permission:reports.view')->name('revenue');
        Route::get('/best-sellers', 'bestSellers')->middleware('permission:reports.view')->name('bestSellers');
        Route::get('/inventory', 'inventory')->middleware('permission:reports.view')->name('inventory');
        Route::get('/debts', 'debts')->middleware('permission:reports.view')->name('debts');
        Route::get('/profit', 'profit')->middleware('permission:reports.view')->name('profit');
    });
});

require __DIR__ . '/auth.php';
