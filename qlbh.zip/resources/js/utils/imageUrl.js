import { withAppBasePath } from '@/utils/appPaths'

export const imageUrl = (value) => {
    if (!value) return null

    const path = typeof value === 'object'
        ? (value.url ?? value.path ?? value.image_url ?? null)
        : value

    if (!path) return null

    const normalized = String(path)

    if (/^(https?:|data:|blob:)/i.test(normalized)) {
        return normalized
    }

    if (normalized.startsWith('/')) {
        return withAppBasePath(normalized)
    }

    return withAppBasePath(`/storage/${normalized.replace(/^\/?(?:storage\/)?/, '')}`)
}
