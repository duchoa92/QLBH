// In tem IMEI/Serial ngay trong trang hiện tại bằng iframe ẩn (không mở tab/điều hướng).
// Dùng chung cho danh sách sản phẩm và cửa sổ chi tiết sản phẩm.
import JsBarcode from 'jsbarcode'

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
})[c])

const normalizeStatus = (status) => ({ 0: 'in_stock', 1: 'sold', 2: 'repairing', 3: 'returned' }[status] ?? status)

const labelCode = (item) => String(item?.imei || item?.serial || '').trim()

const isInStock = (item) => String(normalizeStatus(item?.status) || '').toLowerCase() === 'in_stock'

const variantText = (product, variantId) => {
    const variant = (product?.variants || []).find(v => Number(v.id) === Number(variantId))
    if (!variant) return ''
    const values = Object.values(variant.attributes || {})
        .map(value => typeof value === 'object' ? (value?.value || value?.label || value?.name || '') : value)
        .filter(Boolean)
    return values.join(' / ') || variant.sku || ''
}

/** Các IMEI/Serial còn trong kho và có mã để in của một sản phẩm. */
export const printableCodes = (product) =>
    (product?.imeis || []).filter(item => isInStock(item) && labelCode(item))

export const canPrintLabels = (product) => printableCodes(product).length > 0

/** Danh sách tem có thể in (mỗi IMEI/Serial một tem) để người dùng chọn. */
export const labelRowsFor = (products) => products.filter(Boolean).flatMap(product =>
    printableCodes(product).map(item => ({
        key: `${product.id}-${item.id ?? labelCode(item)}`,
        productId: product.id,
        productName: product.name,
        variant: variantText(product, item.variant_id),
        code: labelCode(item),
        kind: item.imei ? 'IMEI' : 'SN',
        price: item.sell_price ?? product.sell_price,
    })))

const money = (value) => `${new Intl.NumberFormat('vi-VN').format(Number(value) || 0)} ₫`

const barcodeSvg = (code) => {
    try {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
        JsBarcode(svg, code, { format: 'CODE128', width: 1.2, height: 30, displayValue: false, margin: 0 })
        return svg.outerHTML
    } catch {
        return '' // Mã chứa ký tự CODE128 không hỗ trợ: vẫn in chữ, bỏ vạch.
    }
}

const buildHtml = (rows) => {
    const labels = rows.map(row => `<div class="label"><div class="name">${escapeHtml(row.productName)}${row.variant ? ` - ${escapeHtml(row.variant)}` : ''}</div><div class="code">${row.kind}: ${escapeHtml(row.code)}</div><div class="price">${money(row.price)}</div>${barcodeSvg(row.code)}</div>`)

    return `<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>In tem</title><style>
@page{margin:6mm}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;color:#000}
.wrap{display:flex;flex-wrap:wrap;gap:8px}
.label{width:180px;height:100px;border:1px dashed #000;padding:6px;font-size:11px;overflow:hidden;page-break-inside:avoid;break-inside:avoid}
.name{font-weight:bold;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.code{margin-top:2px}.price{font-weight:bold;margin-top:2px}svg{display:block;margin-top:4px;max-width:100%}
</style></head><body><div class="wrap">${labels.join('')}</div></body></html>`
}

/**
 * In đúng các tem đã chọn bằng iframe ẩn trong trang hiện tại.
 * Iframe phải có kích thước thật (đặt ngoài màn hình) vì iframe 0x0 thường in ra trang trống.
 */
export function printLabelRows(rows) {
    if (!rows.length) return 0

    const frame = document.createElement('iframe')
    frame.setAttribute('aria-hidden', 'true')
    frame.style.cssText = 'position:fixed;left:-10000px;top:0;width:900px;height:700px;border:0'

    let cleaned = false
    const cleanup = () => {
        if (cleaned) return
        cleaned = true
        frame.remove()
    }

    frame.onload = () => {
        const frameWindow = frame.contentWindow
        if (!frameWindow) return cleanup()
        frameWindow.addEventListener('afterprint', cleanup, { once: true })
        window.setTimeout(() => {
            frameWindow.focus()
            frameWindow.print()
            window.setTimeout(cleanup, 60000)
        }, 250)
    }
    frame.srcdoc = buildHtml(rows)
    document.body.appendChild(frame)

    return rows.length
}
