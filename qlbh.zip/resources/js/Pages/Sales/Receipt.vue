<script setup>
import { usePage } from '@inertiajs/vue3'
import { formatCurrency, formatNumber, formatDateTime } from '@/utils/format'

defineOptions({
    // BẮT BUỘC: Báo cho Inertia biết trang này KHÔNG sử dụng bất kỳ Layout nào (Kể cả AdminLayout mặc định)
    layout: null,
})

const props = defineProps({
    sale: Object,
})
const page = usePage()

const formatMoney = formatCurrency
const itemDiscount = (item) => {
    const saved = Number(item.discount_amount)
    if (Number.isFinite(saved) && saved > 0) return saved

    const line = Number(item.unit_price || 0) * Number(item.quantity || 0)
    const value = Number(item.discount_value || 0)
    if (item.discount_type === 'percent') return line * value / 100
    if (item.discount_type === 'amount') return value
    return 0
}

const paper = () => page.props.settings?.print_paper_size || 'a4'
const previewReceiptWidth = () => {
    const orientation = page.props.settings?.print_orientation === 'landscape'
    return ({
        '58mm': '54mm',
        '80mm': '76mm',
        a4: orientation ? '277mm' : '190mm',
        a5: orientation ? '190mm' : '128mm',
    })[paper()] || '190mm'
}

const saleQuantityText = (item) => {
    const qty = Number(item.quantity ?? 0)
    const unit = item.unit_name || 'Cái'
    return `${Number.isInteger(qty) ? qty : formatNumber(qty)} ${unit}`
}

const baseQuantityText = (item) => {
    if (Number(item.conversion_factor || 1) <= 1) return ''

    const unit = item.product?.unit?.short_name
        || item.product?.unit?.name
        || 'đơn vị gốc'

    return ` = ${item.base_quantity} ${unit}`
}

const variantLabel = (variant) => {
    const attributes = variant?.attributes
    if (Array.isArray(attributes)) return attributes.map(value => typeof value === 'object' ? value?.value || value?.label || value?.name : value).filter(Boolean).join(' / ')
    if (attributes && typeof attributes === 'object') {
        return Object.values(attributes).map(value => typeof value === 'object' ? value?.value || value?.label || value?.name : value).filter(Boolean).join(' / ')
    }
    return String(variant?.name || variant?.sku || '')
}

const balanceLabel = () => {
    const total = Number(saleTotal())
    const paid = Number(props.sale?.paid_amount || 0)
    const change = Math.max(0, Number(props.sale?.change_amount || 0))
    if (paid < total) return { label: 'Nợ lại:', amount: total - paid }
    if (change > 0) return { label: 'Tiền thừa:', amount: change }
    return { label: 'Đã thanh toán đủ:', amount: 0 }
}

const saleTotal = () => props.sale?.grand_total ?? props.sale?.total_amount ?? props.sale?.subtotal ?? 0

const customerPaymentLabel = (method) => ({
    cash: 'Khách đưa',
    bank: 'Khách chuyển',
    mixed: 'Khách đưa / khách chuyển',
    card: 'Khách thanh toán thẻ',
}[String(method || '').toLowerCase()] || 'Khách đưa')

const customerPaymentRows = () => {
    const cash = Math.max(0, Number(props.sale?.cash_received_amount || 0))
    const bank = Math.max(0, Number(props.sale?.bank_received_amount || 0))
    if (cash > 0 || bank > 0) return [
        ...(cash > 0 ? [{ label: 'Khách đưa', amount: cash }] : []),
        ...(bank > 0 ? [{ label: 'Khách chuyển', amount: bank }] : []),
    ]
    return [{ label: customerPaymentLabel(props.sale?.payment_method), amount: Math.max(0, Number(props.sale?.paid_amount || 0)) }]
}

// Trang được nhúng trong modal xem trước; chỉ in khi người dùng bấm nút In ở modal.
</script>

<!-- Receipt.vue -->
<template>
    <div class="receipt-wrapper">
        <div class="receipt-container relative" :class="{ 'receipt-compact': page.props.settings?.print_template === 'compact' }" :style="{ '--configured-receipt-width': previewReceiptWidth() }">
            
            <!-- 🔴 DẤU CON DẤU "ĐÃ HỦY" ĐÓNG MỜ NỔI BẬT -->
            <div 
                v-if="sale.status === 'cancelled'" 
                class="absolute transform -translate-x-1/2 -translate-y-1/2 border-4 border-red-600 top-1/2 left-1/2 text-red-600 font-extrabold text-3xl uppercase tracking-widest px-4 py-1 rotate-[-25deg] opacity-35 select-none pointer-events-none z-10"
            >
                ĐÃ HỦY
            </div>

            <!-- Nút bấm thủ công (Tự động ẩn khi in) -->
            <div class="no-print print-bar"><span>Xem trước hóa đơn</span></div>

            <!-- Header Cửa hàng -->
            <div class="header">
                <h2>{{ page.props.settings?.shop_name || 'Cửa hàng' }}</h2>
                <div v-if="page.props.settings?.print_shop_subtitle" class="sub">{{ page.props.settings.print_shop_subtitle }}</div>
                <div v-if="page.props.settings?.print_shop_address">{{ page.props.settings.print_shop_address }}</div>
                <div v-if="page.props.settings?.print_shop_phone" class="phone">{{ page.props.settings.print_shop_phone }}</div>
            </div>

            <div class="divider"></div>

            <!-- Thông tin đơn hàng -->
            <div class="info">
                <div class="row"><span>Mã HD:</span> <strong>#{{ sale.code }}</strong></div>
                <div class="row"><span>Ngày:</span> <span>{{ formatDateTime(sale.created_at) }}</span></div>
                <div class="row" v-if="sale.user"><span>Thu ngân:</span> <span>{{ sale.user?.name }}</span></div>
                <div class="row" v-if="sale.customer">
                    <span>Khách hàng:</span>
                    <strong>{{ sale.customer.full_name || sale.customer.name }}</strong>
                </div>
            </div>

            <div class="divider"></div>

            <!-- Danh sách sản phẩm -->
            <div class="items">
                <div v-for="item in sale.items" :key="item.id" class="item">
                    <div class="item-name">
                        {{ item.product?.name || 'Sản phẩm' }}
                        <span v-if="item.has_vat" class="vat-badge">Có VAT</span>
                        <span v-if="item.vat_applied" class="vat-badge">VAT tính</span>
                        <span v-if="variantLabel(item.variant)" class="item-variant">
                            ({{ variantLabel(item.variant) }})
                        </span>
                    </div>

                    <div v-if="item.product_imei?.imei" class="item-imei">
                        IMEI: {{ item.product_imei.imei }}<span v-if="item.product_imei.is_used"> (Cũ)</span>
                    </div>

                    <div class="item-calc">
                        <span>{{ saleQuantityText(item) }}{{ baseQuantityText(item) }} x {{ formatMoney(item.unit_price) }}</span>
                        <strong>{{ formatMoney(Number(item.unit_price || 0) * Number(item.quantity || 0)) }}</strong>
                    </div>
                    <div v-if="itemDiscount(item) > 0" class="item-discount">
                        <span>Giảm giá{{ item.discount_type === 'percent' ? ` (${item.discount_value}%)` : '' }}</span>
                        <span>-{{ formatMoney(itemDiscount(item)) }}</span>
                    </div>
                    <div v-if="itemDiscount(item) > 0" class="item-net">
                        <span>Thành tiền</span>
                        <strong>{{ formatMoney(item.subtotal) }}</strong>
                    </div>
                    <div v-for="gift in item.gifts || []" :key="gift.id" class="item-gift">
                        <span>🎁 {{ gift.product?.name || 'Quà tặng' }} × {{ gift.quantity || 1 }}</span>
                        <span>Miễn phí</span>
                    </div>
                </div>
            </div>

            <div class="divider"></div>

            <!-- Tổng tiền -->
            <div class="totals">
                <div class="row" v-if="sale.subtotal">
                    <span>Tạm tính:</span>
                    <span>{{ formatMoney(sale.subtotal) }}</span>
                </div>
                <div class="row" v-if="Number(sale.discount || 0) > 0">
                    <span>Chiết khấu sản phẩm:</span>
                    <span>-{{ formatMoney(sale.discount) }}</span>
                </div>
                <div class="row" v-if="Number(sale.invoice_discount || 0) > 0"><span>Chiết khấu đơn:</span><span>-{{ formatMoney(sale.invoice_discount) }}</span></div>
                <div class="row" v-if="Number(sale.tax || 0) > 0"><span>VAT:</span><span>{{ formatMoney(sale.tax) }}</span></div>
                <div class="row" v-else-if="sale.items?.some(item => item.has_vat)"><span>Nhãn VAT hàng nhập:</span><span>Chỉ để nhận biết</span></div>
                <div class="row" v-if="Number(sale.extra_fee || 0) > 0"><span>Phí phụ thu:</span><span>{{ formatMoney(sale.extra_fee) }}</span></div>
                <div class="row total-grand">
                    <span>TỔNG CỘNG:</span>
                    <span>{{ formatMoney(sale.grand_total || sale.total_amount || sale.subtotal) }}</span>
                </div>
                <div v-for="payment in customerPaymentRows()" :key="payment.label" class="row">
                    <span>{{ payment.label }}:</span>
                    <span>{{ formatMoney(payment.amount) }}</span>
                </div>
                <div v-if="Number(sale.old_debt_paid || 0) > 0" class="row">
                    <span>Trích trả nợ cũ:</span>
                    <span>{{ formatMoney(sale.old_debt_paid) }}</span>
                </div>
                <div class="row">
                    <span>{{ balanceLabel().label }}</span>
                    <span>{{ formatMoney(balanceLabel().amount) }}</span>
                </div>
            </div>

            <div class="divider"></div>

            <!-- 🔴 THÔNG TIN LÝ DO HỦY TRÊN HOÁ ĐƠN IN -->
            <div 
                v-if="sale.status === 'cancelled'" 
                class="pt-2 mb-2 text-xs text-red-600 border-t-2 border-dashed border-red-400"
            >
                <p class="font-bold uppercase">HÓA ĐƠN NÀY ĐÃ BỊ HỦY</p>
                <p>Lý do: {{ sale.cancel_reason || sale.reason || 'Chưa ghi nhận' }}</p>
                <p v-if="sale.cancelled_at">Thời gian: {{ sale.cancelled_at }}</p>
            </div>

            <!-- Footer -->
            <div class="footer">
                <div class="thanks">CẢM ƠN QUÝ KHÁCH HÀNG!</div>
                <div class="sub">Hẹn gặp lại quý khách lần sau!</div>
            </div>
        </div>
    </div>
</template>

<style scoped>
/* CSS Reset cho trang in */
.receipt-wrapper {
    background-color: #f1f5f9;
    min-height: 100vh;
    padding: 20px 0;
    display: flex;
    justify-content: center;
}

.receipt-container {
    width: var(--configured-receipt-width, 80mm);
    background: #fff;
    padding: 12px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 11px;
    color: #000;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.print-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #e2e8f0;
    padding: 6px 10px;
    margin-bottom: 12px;
    border-radius: 6px;
}

.btn-print {
    background: #2563eb;
    color: white;
    font-weight: bold;
    padding: 4px 8px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
}

.header { text-align: center; }
.header h2 { font-size: 16px; font-weight: 900; margin: 0; }
.header .sub { font-style: italic; font-size: 10px; }
.header .phone { font-weight: bold; }

.divider {
    border-bottom: 1px dashed #64748b;
    margin: 8px 0;
}

.row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 2px;
}

.item { margin-bottom: 6px; }
.item-name { font-weight: bold; }
.vat-badge { display: inline-block; margin-left: 3px; padding: 1px 4px; border-radius: 3px; background: #ecfdf5; color: #047857; font-size: 8px; font-weight: 700; }
.item-variant { font-weight: normal; color: #475569; }
.item-imei { font-family: monospace; font-size: 10px; color: #475569; }
.item-calc { display: flex; justify-content: space-between; margin-top: 2px; }
.item-discount, .item-gift { display: flex; justify-content: space-between; gap: 8px; margin-top: 2px; font-size: 10px; }
.item-discount { color: #b45309; }
.item-gift { color: #047857; }
.item-net { display: flex; justify-content: space-between; margin-top: 2px; font-size: 10px; }

.total-grand {
    font-size: 13px;
    font-weight: 900;
    margin-top: 4px;
}

.footer { text-align: center; margin-top: 8px; }
.footer .thanks { font-weight: bold; }
.footer .sub { font-size: 10px; font-style: italic; color: #64748b; }

.receipt-compact .info .row:nth-child(3),
.receipt-compact .footer .sub { display: none; }

/* 🔴 BẮT BUỘC: KHI NẤM NÚT IN HOẶC TRÌNH DUYỆT TỰ IN -> ẨN SẠCH ADMIN LAYOUT */
@media print {
    /* Ẩn toàn bộ DOM ngoại trừ khung hóa đơn */
    body * {
        visibility: hidden !important;
    }

    .receipt-container,
    .receipt-container * {
        visibility: visible !important;
    }

    .receipt-wrapper {
        padding: 0 !important;
        min-height: 0 !important;
        background: transparent !important;
        display: block !important;
    }

    .receipt-container {
        position: relative !important;
        left: auto !important;
        top: auto !important;
        width: var(--configured-receipt-width, 190mm) !important;
        max-width: none !important;
        margin: 0 !important;
        box-shadow: none !important;
        padding: 0 !important;
    }

    .no-print {
        display: none !important;
    }

}
</style>
