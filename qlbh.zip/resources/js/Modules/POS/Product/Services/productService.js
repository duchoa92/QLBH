import api from '@/Services/api'
import { findProductByScannedCode } from './productBarcodeLookup'

export const productService = {

    // Tìm kiếm sản phẩm theo từ khóa và danh mục
    async search(
        keyword = '',
        categoryId = '',
        sort = ''
    ) {

        const response =
            await api.get(
                '/api/products',
                {
                    params: {

                        keyword,

                        category_id:
                            categoryId,

                        sort,

                        // Không dùng lại phản hồi API đã được cache bởi trình duyệt/PWA
                        // sau khi một lô vừa được xuất hết.
                        _catalog_version: Date.now(),
                    },
                }
            )

        return response.data
    },

    // Tìm kiếm sản phẩm theo mã vạch
    async findByBarcode(
        barcode
    ) {

        const response =
            await api.get(
                '/api/products/barcode',
                {
                    params: {
                        barcode,
                    },
                }
            )

        return response.data
    },

    // Quét barcode hoặc IMEI
    async scan(code) {

        let match = null
        try {
            match = await findProductByScannedCode(code)
        } catch {
            // Keep the legacy IMEI/product scan endpoint available if catalog search fails.
        }

        if (match) {
            return {
                type: match.variant ? 'variant' : 'barcode',
                data: {
                    ...match.product,
                    scanned_variant: match.variant,
                },
            }
        }

        const response =
            await api.post(
                '/api/pos/scan',
                {
                    code,
                }
            )

        return response.data
    },

    // Lấy danh sách IMEI còn trong kho của 1 sản phẩm (lọc theo biến thể nếu có)
    async imeis(productId, variantId = null) {

        const response =
            await api.get(
                `/api/products/${productId}/imeis`,
                {
                    params: variantId
                        ? { variant_id: variantId }
                        : {},
                }
            )

        return response.data
    },
}
