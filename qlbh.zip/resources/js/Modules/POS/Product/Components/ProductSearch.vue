<script setup>
import { computed, ref, onBeforeUnmount } from 'vue'
import { usePage } from '@inertiajs/vue3'
import { useProductSearch } from '@/Modules/POS/Product/Composables/useProductSearch'
import { toast } from 'vue-sonner'
import { productService } from '@/Modules/POS/Product/Services/productService'
import FloatingInput from '@/Components/UI/FloatingInput.vue'
import BarcodeCameraButton from '@/Components/BarcodeCameraButton.vue'
import { RotateCw, Search, PackageX, Loader2 } from 'lucide-vue-next'
import { formatCurrency } from '@/utils/format'



// Nhận giỏ hàng từ POS truyền vào
const props = defineProps({
    cart: {
        type: Array,
        default: () => [],
    },
})

const emit = defineEmits([
    'selected',
    'product-scanned',
])
const page = usePage()
const allowsNegativeStock = computed(() => [true, 1, '1', 'true', 'on'].includes(page.props.settings?.allow_negative_stock))
const costPriceSuggestionEnabled = computed(() => page.props.settings?.pos_cost_price_suggestion_enabled !== false
    && page.props.settings?.pos_cost_price_suggestion_enabled !== 0
    && page.props.settings?.pos_cost_price_suggestion_enabled !== '0')

const {
    keyword,
    categoryId,
    products,
    categories,
    loading,
    loadProducts,
} = useProductSearch()

const selectProduct = (product, event = null) => {
    // Kiểm tra tồn kho khả dụng trước khi chọn
    const currentStock = getDisplayStock(product)
    if (currentStock <= 0 && !canSellWithoutStock(product)) {
        toast.error('Sản phẩm/Biến thể này đã hết hàng hoặc đã được chọn hết vào giỏ!')
        return
    }
    emit('selected', product, event?.currentTarget?.getBoundingClientRect?.() ?? null)
}

const scanImei = async () => {
    const value = keyword.value.trim()
    if (!value) return

    try {
        const result = await productService.scan(value)

        if (result.type !== 'imei') {
            emit('selected', result.data)
            keyword.value = ''
            return
        }
        
        // Kiểm tra xem mã IMEI / Serial này đã có trong giỏ hàng chưa
        const isImeiInCart = props.cart.some(item => 
            (item.imei && item.imei === result.data.imei) || 
            (item.serial && item.serial === result.data.serial) ||
            (item.imei_id && item.imei_id === result.data.imei_id)
        )

        if (isImeiInCart) {
            toast.error(`Mã IMEI/Serial (${value}) đã có trong giỏ hàng!`)
            return
        }

        const product = {
            id: result.data.id,
            product_id: result.data.product_id || result.data.id,
            name: result.data.name,
            sell_price: result.data.sell_price ?? result.data.price,
            image_url: result.data.image_url,
            warranty_days: result.data.warranty_days ?? 0,
            product_type: 'imei',
            variant_id: result.data.variant_id || result.data.variant?.id,
            variant: result.data.variant ?? null,
            imei_id: result.data.imei_id,
            imei: result.data.imei,
            serial: result.data.serial ?? null,
            color: result.data.color ?? null,
            storage: result.data.storage ?? null,
        }

        emit('selected', product)
        keyword.value = ''
    } catch (error) {
        console.error(error)
        const message = error.response?.data?.message ?? 'Không tìm thấy sản phẩm hoặc IMEI không hợp lệ'
        toast.error(message)
    }
}

const onCameraScan = async (code) => {
    keyword.value = code
    await scanImei()
}

const formatPrice = formatCurrency
const showingCostPriceFor = ref(null)
let costPriceHoldTimer = null
let costPriceHoldTriggered = false
let suppressImageClick = false

const isShowingCostPrice = (product) => costPriceSuggestionEnabled.value && showingCostPriceFor.value === (product.variant_id ?? product.id)
const startShowingCostPrice = (product, event) => {
    if (!costPriceSuggestionEnabled.value) return
    clearTimeout(costPriceHoldTimer)
    costPriceHoldTriggered = false
    suppressImageClick = false
    const target = event.currentTarget
    const pointerId = event.pointerId
    const key = product.variant_id ?? product.id
    costPriceHoldTimer = setTimeout(() => {
        showingCostPriceFor.value = key
        costPriceHoldTriggered = true
        target?.setPointerCapture?.(pointerId)
    }, 450)
}
const stopShowingCostPrice = (event) => {
    clearTimeout(costPriceHoldTimer)
    if (event?.type === 'pointerup' && costPriceHoldTriggered) {
        suppressImageClick = true
        showingCostPriceFor.value = null
        return
    }
    if (event?.type === 'pointercancel') {
        suppressImageClick = false
        showingCostPriceFor.value = null
    }
}
const handleCostImageClick = event => {
    if (!suppressImageClick) return
    event.preventDefault()
    event.stopPropagation()
    suppressImageClick = false
}
onBeforeUnmount(() => clearTimeout(costPriceHoldTimer))
const displayedPriceLabel = (product) => isShowingCostPrice(product)
    ? costPriceLabel(product)
    : priceLabel(product)

const costPriceLabel = (product) => {
    const min = Number(product.cost_price_min || 0)
    const max = Number(product.cost_price_max || 0)
    if (min > 0 && max > 0 && min !== max) {
        return `${formatPrice(min)} - ${formatPrice(max)}`
    }

    return formatPrice(min || max || product.cost_price || product.import_price || 0)
}

const canSellWithoutStock = (product) => allowsNegativeStock.value
    && product.product_type !== 'imei'
    && !product.manage_stock_by_serial
    && !product.has_imei

// Giá trên catalog phải phản ánh đúng phần hàng còn có thể thêm. Mỗi lô được
// trừ riêng theo batch_id của các dòng đang nằm trong giỏ, nên khi dùng hết lô
// giá thấp, khoảng giá chuyển ngay sang lô tiếp theo.
const availableBatches = (product) => {
    const productId = Number(product.product_id ?? product.id)
    const selectedVariantId = product.variant_id ? Number(product.variant_id) : null
    const batches = (product.stock_batches || [])
        .filter(batch => selectedVariantId === null || Number(batch.variant_id || 0) === selectedVariantId)
        .slice()
        .sort((left, right) => Number(left.id) - Number(right.id))

    const legacyClaims = new Map()
    props.cart
        .filter(item => Number(item.product_id ?? item.id) === productId && !item.batch_id)
        .forEach(item => {
            const scope = Number(item.variant_id || 0)
            legacyClaims.set(scope, (legacyClaims.get(scope) || 0) + Number(item.quantity || 0))
        })

    return batches.reduce((available, batch) => {
        const variantId = Number(batch.variant_id || 0)
        const explicitClaim = props.cart
            .filter(item => Number(item.product_id ?? item.id) === productId && Number(item.batch_id) === Number(batch.id))
            .reduce((total, item) => total + Number(item.quantity || 0), 0)
        const legacyClaim = Math.min(legacyClaims.get(variantId) || 0, Number(batch.remaining_quantity || 0))
        legacyClaims.set(variantId, Math.max(0, (legacyClaims.get(variantId) || 0) - legacyClaim))
        const remainingQuantity = Number(batch.remaining_quantity || 0) - explicitClaim - legacyClaim

        if (remainingQuantity > 0) available.push({ ...batch, remaining_quantity: remainingQuantity })
        return available
    }, [])
}

const priceLabel = (product) => {
    const batchPrices = availableBatches(product)
        .map(batch => Number(batch.sell_price || 0))
        .filter(price => price > 0)

    if (batchPrices.length) {
        const min = Math.min(...batchPrices)
        const max = Math.max(...batchPrices)
        return min === max ? formatPrice(min) : `${formatPrice(min)} - ${formatPrice(max)}`
    }

    if (
        Number(product.price_min || 0) > 0
        && Number(product.price_max || 0) > 0
        && Number(product.price_min) !== Number(product.price_max)
    ) {
        return `${formatPrice(product.price_min)} - ${formatPrice(product.price_max)}`
    }

    return formatPrice(product.price)
}

/**
 * TÍNH TỒN KHO KHẢ DỤNG CHUẨN 100% CHO MỌI LOẠI SẢN PHẨM
 */
const getDisplayStock = (product) => {
    const productId = Number(product.product_id ?? product.id)
    const variantId = product.variant_id ? Number(product.variant_id) : null
    const sellableQuantity = (baseQuantity) => Math.max(0, Number(baseQuantity || 0))
    const cartBaseQuantity = (item) =>
        Number(item.quantity ?? 1)

    // Danh sách IMEI nếu backend có trả về mảng chi tiết
    const imeiList = product.imeis || product.serials || product.product_imeis || []
    
    // Kiểm tra xem sản phẩm này có phải loại quản lý theo IMEI/Serial không
    const isImeiProduct = product.product_type === 'imei' || 
                          product.manage_stock_by_serial || 
                          product.has_imei || 
                          imeiList.length > 0

    // =========================================================================
    // TRƯỜNG HỢP 1: SẢN PHẨM QUẢN LÝ THEO IMEI (DÙ CÓ BIẾN THỂ HAY KHÔNG)
    // =========================================================================
    if (isImeiProduct) {
        let rawStock = 0

        // 1a. Nếu Backend có trả về mảng IMEI chi tiết -> Lọc theo status & giỏ hàng
        if (Array.isArray(imeiList) && imeiList.length > 0) {
            const availableImeis = imeiList.filter(item => {
                const isAvailable = item.status === 'available' || 
                                    item.status === 1 || 
                                    item.status === 'in_stock' || 
                                    item.is_sold === 0 || 
                                    item.is_sold === false || 
                                    !item.status

                const isInCart = props.cart.some(cartItem => 
                    (cartItem.imei && cartItem.imei === item.imei) ||
                    (cartItem.imei_id && Number(cartItem.imei_id) === Number(item.id))
                )

                return isAvailable && !isInCart
            })

            return availableImeis.length
        }

        // 1b. Nếu Backend KHÔNG trả về mảng IMEI (chỉ trả product.stock do Server đếm sẵn)
        rawStock = Number(product.stock ?? product.stock_quantity ?? 0)

        // Trừ đi số lượng món IMEI của sản phẩm này đã cho vào giỏ hàng
        const inCartQty = props.cart.reduce((sum, item) => {
            const itemProductId = Number(item.product_id ?? item.id)
            if (itemProductId === productId) {
                return sum + cartBaseQuantity(item)
            }
            return sum
        }, 0)

        return sellableQuantity(rawStock - inCartQty)
    }

    // Khi sản phẩm đang được quản lý theo lô, tổng tồn của sản phẩm/biến thể
    // có thể vẫn lớn hơn 0 dù các lô đó đã được giữ trong giỏ. Luôn ưu tiên
    // số còn lại theo từng lô để trạng thái hết hàng và giá hiển thị cùng
    // phản ánh một nguồn dữ liệu.
    const trackedBatches = availableBatches(product)
    if (Array.isArray(product.stock_batches) && product.stock_batches.length > 0) {
        if (variantId) {
            return trackedBatches
                .filter(batch => Number(batch.variant_id || 0) === variantId)
                .reduce((total, batch) => total + sellableQuantity(batch.remaining_quantity), 0)
        }

        return trackedBatches
            .reduce((total, batch) => total + sellableQuantity(batch.remaining_quantity), 0)
    }

    // =========================================================================
    // TRƯỜNG HỢP 2: ĐANG CHỌN MỘT BIẾN THỂ CỤ THỂ
    // =========================================================================
    if (variantId) {
        const variant = product.variants?.find(v => Number(v.id) === variantId)
        const rawStock = Number(variant?.stock_quantity ?? variant?.stock ?? variant?.quantity ?? 0)
        
        const inCartQty = props.cart.reduce((sum, item) => {
            const itemProductId = Number(item.product_id ?? item.id)
            const itemVariantId = item.variant_id ? Number(item.variant_id) : null
            if (itemProductId === productId && itemVariantId === variantId) {
                return sum + cartBaseQuantity(item)
            }
            return sum
        }, 0)

        return sellableQuantity(rawStock - inCartQty)
    }

    // =========================================================================
    // TRƯỜNG HỢP 3: SẢN PHẨM CHỈ CÓ BIẾN THỂ (KHÔNG PHẢI IMEI)
    // =========================================================================
    if (Array.isArray(product.variants) && product.variants.length > 0) {
        const totalAvailable = product.variants.reduce((total, variant) => {
            const vStock = Number(variant.stock_quantity ?? variant.stock ?? variant.quantity ?? 0)
            
            const inCartQty = props.cart.reduce((sum, cartItem) => {
                const itemProductId = Number(cartItem.product_id ?? cartItem.id)
                const itemVariantId = cartItem.variant_id ? Number(cartItem.variant_id) : null
                
                if (itemProductId === productId && itemVariantId === Number(variant.id)) {
                    return sum + cartBaseQuantity(cartItem)
                }
                return sum
            }, 0)

            return total + sellableQuantity(vStock - inCartQty)
        }, 0)

        return totalAvailable
    }

    // =========================================================================
    // TRƯỜNG HỢP 4: SẢN PHẨM THƯỜNG (KHÔNG BIẾN THỂ, KHÔNG IMEI)
    // =========================================================================
    const rawStock = Number(product.stock ?? product.stock_quantity ?? 0)
    const inCartQty = props.cart.reduce((sum, item) => {
        const itemProductId = Number(item.product_id ?? item.id)
        if (itemProductId === productId) {
            return sum + cartBaseQuantity(item)
        }
        return sum
    }, 0)

    return sellableQuantity(rawStock - inCartQty)
}

const refreshProducts = () => {
    loadProducts()
}

const categoryOptions = computed(() => [
    {
        value: '',
        label: 'Tất cả danh mục',
    },
    ...categories.value.map(category => ({
        value: category.id,
        label: category.name,
    })),
])
</script>

<template>
    <div class="flex min-h-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm font-sans antialiased">
        
        <!-- THANH LỌC & TÌM KIẾM SẢN PHẨM -->
        <div class="shrink-0 border-b border-slate-100 bg-white p-2 sm:p-3">
            <div class="flex min-w-0 items-center gap-2">
                
                <!-- Ô TÌM KIẾM -->
                <div class="relative min-w-0 flex-1">
                    <FloatingInput
                        v-model="keyword"
                        @keyup.enter="scanImei"
                        type="text"
                        label="Tìm tên, SKU, model hoặc IMEI"
                        input-class="pr-12"
                    />
                    <BarcodeCameraButton class="absolute right-2 top-1/2 z-10 -translate-y-1/2 " @scanned="onCameraScan" />
                </div>

                <button
                    type="button"
                    @click="refreshProducts"
                    title="Tải lại danh sách"
                    class="h-10 w-10 shrink-0 inline-flex items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-600 hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700 active:scale-95 transition-all"
                >
                    <RotateCw class="w-4 h-4" :class="{ 'animate-spin': loading }" />
                </button>
            </div>

            <!-- LỌC DANH MỤC DẠNG CHIP -->
            <div class="pos-category-scroll mt-2 flex items-center gap-1.5 overflow-x-auto pb-0.5" aria-label="Lọc theo danh mục">
                <button
                    v-for="category in categoryOptions"
                    :key="category.value || 'all'"
                    type="button"
                    class="shrink-0 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors"
                    :class="String(categoryId || '') === String(category.value || '')
                        ? 'border-blue-600 bg-blue-600 text-white shadow-sm'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700'"
                    @click="categoryId = category.value"
                >
                    {{ category.label }}
                </button>
            </div>
        </div>

        <!-- DANH SÁCH SẢN PHẨM -->
        <div class="min-h-0 flex-1 overflow-auto bg-slate-50 p-1.5 pr-1 custom-scrollbar sm:p-2">
            
            <!-- LOADING -->
            <div
                v-if="loading"
                class="flex h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white/50 text-slate-400 gap-3"
            >
                <Loader2 class="w-8 h-8 animate-spin text-blue-500" />
                <span class="text-xs font-medium">Đang tải dữ liệu sản phẩm...</span>
            </div>

            <!-- CARD SẢN PHẨM -->
            <div
                v-else-if="products.length"
                class="grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 xl:grid-cols-4 2xl:grid-cols-5"
            >
                <button
                    v-for="product in products"
                    :key="product.id"
                    type="button"
                    :disabled="getDisplayStock(product) <= 0 && !canSellWithoutStock(product)"
                    class="group relative text-left overflow-hidden rounded-xl border transition-all duration-200 flex flex-col justify-between"
                    :class="[
                        getDisplayStock(product) <= 0 && !canSellWithoutStock(product)
                            ? 'opacity-60 border-slate-200 bg-slate-100/50 cursor-not-allowed'
                            : 'border-slate-200 bg-white shadow-sm hover:border-blue-400 hover:shadow-md active:scale-[0.98]'
                    ]"
                    @click="selectProduct(product, $event)"
                >
                    <!-- KHU VỰC ẢNH -->
                    <div
                        class="cost-price-hold-area relative h-24 w-full shrink-0 overflow-hidden bg-slate-100 sm:h-32"
                        :title="costPriceSuggestionEnabled ? 'Nhấn giữ ảnh để xem giá nhập' : undefined"
                        @pointerdown="startShowingCostPrice(product, $event)"
                        @pointerup="stopShowingCostPrice($event)"
                        @pointercancel="stopShowingCostPrice($event)"
                        @lostpointercapture="stopShowingCostPrice($event)"
                        @contextmenu.prevent.stop
                        @click="handleCostImageClick"
                    >
                        <img
                            v-if="product.image_url"
                            :src="product.image_url"
                            :alt="product.name"
                            draggable="false"
                            class="h-full w-full object-cover transition-transform duration-300"
                            :class="{ 'group-hover:scale-105': getDisplayStock(product) > 0 }"
                            @dragstart.prevent
                        />

                        <div
                            v-else
                            class="flex h-full w-full items-center justify-center text-slate-300 bg-slate-100/60"
                        >
                            <Search class="w-8 h-8 stroke-1" />
                        </div>

                        <!-- BADGE HẾT HÀNG NẾU TỒN KHO = 0 -->
                        <div
                            v-if="getDisplayStock(product) <= 0 && !canSellWithoutStock(product)"
                            class="absolute inset-0 bg-slate-900/40 backdrop-blur-[1px] flex items-center justify-center"
                        >
                            <span class="bg-rose-600 text-white font-extrabold text-[11px] uppercase tracking-wider px-2.5 py-1 rounded-lg shadow">
                                Hết hàng
                            </span>
                        </div>

                        <!-- BADGE GIÁ -->
                        <div
                            v-else
                            class="pointer-events-none absolute bottom-2 left-2 select-none rounded-lg bg-rose-600 px-2.5 py-1 text-xs font-bold text-white shadow-sm"
                            :class="isShowingCostPrice(product) ? 'bg-amber-600/95' : ''"
                        >
                            {{ displayedPriceLabel(product) }}
                        </div>

                        <!-- BADGE LOẠI SẢN PHẨM -->
                        <div
                            v-if="product.product_type === 'imei' || product.manage_stock_by_serial"
                            class="absolute top-2 right-2 rounded-md bg-blue-600 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white shadow-sm"
                        >
                            IMEI
                        </div>

                        <div
                            v-else-if="product.variants && product.variants.length"
                            class="absolute top-2 right-2 rounded-md bg-amber-500 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white shadow-sm"
                        >
                            {{ product.variants.length }} bản
                        </div>
                    </div>

                    <!-- THÔNG TIN TÊN & TỒN KHO -->
                    <div class="flex flex-1 flex-col justify-between bg-white p-2.5 sm:p-3">
                        <div
                            class="line-clamp-2 min-h-[32px] text-[11px] font-semibold leading-snug transition-colors sm:min-h-[36px] sm:text-xs"
                            :class="getDisplayStock(product) > 0 ? 'text-slate-800 group-hover:text-blue-600' : 'text-slate-400'"
                            :title="product.name"
                        >
                            {{ product.name }}
                        </div>

                        <div class="mt-2 border-t border-slate-100 pt-1.5 text-[10px] font-medium sm:mt-2.5 sm:pt-2 sm:text-[11px]">
                            <span
                                class="font-bold px-1.5 py-0.5 rounded"
                                :class="getDisplayStock(product) > 0 ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'"
                            >
                                Tồn: {{ getDisplayStock(product) }} {{ product.unit_name || '' }}
                            </span>

                            <span class="hidden text-slate-400 sm:inline">
                                Đã bán: {{ product.sold_count || 0 }}
                            </span>
                        </div>
                    </div>
                </button>
            </div>

            <!-- KHÔNG CÓ KẾT QUẢ -->
            <div
                v-else
                class="flex h-64 flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white/50 text-slate-400 gap-2"
            >
                <PackageX class="w-10 h-10 stroke-1 text-slate-300" />
                <span class="text-sm font-semibold text-slate-600">Không tìm thấy sản phẩm nào</span>
                <span class="text-xs text-slate-400">Vui lòng thử từ khóa khác hoặc thay đổi danh mục</span>
            </div>

        </div>

    </div>
</template>

<style scoped>
.cost-price-hold-area,
.cost-price-hold-area * {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -webkit-user-drag: none;
    user-select: none;
}

.pos-category-scroll { scrollbar-width: none; }
.pos-category-scroll::-webkit-scrollbar { display: none; }
.custom-scrollbar::-webkit-scrollbar { width: 4px; }
.custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
</style>
