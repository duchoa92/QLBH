<script setup>
import { Banknote, CreditCard, Landmark } from 'lucide-vue-next'

const props = defineProps({
    modelValue: {
        type: String,
        default: 'cash',
    },
    disabled: { type: Boolean, default: false },
    methods: { type: Array, default: () => ['cash', 'bank', 'card'] },
})

const emit = defineEmits(['update:modelValue'])

const methods = [
    { id: 'cash', label: 'Tiền mặt', icon: Banknote },
    { id: 'bank', label: 'Chuyển khoản', icon: Landmark },
    { id: 'card', label: 'Thẻ / POS', icon: CreditCard },
]
const visibleMethods = methods.filter(method => props.methods.includes(method.id))
</script>

<template>
    <div class="grid gap-2" :class="visibleMethods.length === 2 ? 'grid-cols-2' : 'grid-cols-3'">
        <button
            v-for="item in visibleMethods"
            :key="item.id"
            type="button"
            class="flex flex-col items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl border text-xs font-bold transition-all"
            :class="props.modelValue === item.id
                ? 'border-blue-600 bg-blue-50/60 text-blue-600 shadow-sm'
                : 'border-slate-200/80 bg-white text-slate-600 hover:border-slate-300'"
            :disabled="props.disabled"
            @click="emit('update:modelValue', item.id)"
        >
            <component :is="item.icon" class="w-4 h-4" />
            <span>{{ item.label }}</span>
        </button>
    </div>
</template>
