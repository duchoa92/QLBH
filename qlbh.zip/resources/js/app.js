import '../css/app.css';
import './bootstrap';

import { createApp, defineAsyncComponent, h } from 'vue';
import { createInertiaApp, router} from '@inertiajs/vue3';
import { Toaster, toast  } from 'vue-sonner';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy';
import 'vue-sonner/style.css'
import clickOutside from '@/Directives/clickOutside'
import ModalRoot from '@/Components/ModalRoot.vue'
import { formatMoney, formatCurrency, formatDate, formatDateTime, getCurrencySymbol, setFormatSettings } from '@/utils/format'
import { notifyReferenceDataChanged } from '@/Stores/referenceData'
import { installAppPathSupport, appBaseUrl } from '@/utils/appPaths'
import { installInsecureNotice } from '@/utils/insecureNotice'

const AdminLayout = defineAsyncComponent(() => import('@/Layouts/AdminLayout.vue'))
const pageComponents = import.meta.glob([
    './Pages/**/*.vue',
    '!./Pages/Backups/Index.vue',
    '!./Pages/Brands/Form.vue',
    '!./Pages/Customers/CustomerFormModal.vue',
    '!./Pages/Customers/Partials/**/*.vue',
    '!./Pages/ProductImeis/PriceFormModal.vue',
    '!./Pages/Products/*Modal.vue',
    '!./Pages/Profile/Partials/**/*.vue',
    '!./Pages/Repairs/Repair*.vue',
    '!./Pages/StockImports/ReplenishmentListModal.vue',
    '!./Pages/StockImports/StockImportFormModal.vue',
    '!./Pages/StockImports/StockImportProductModal.vue',
    '!./Pages/StockImports/SupplierSection.vue',
    '!./Pages/Suppliers/Form.vue',
    '!./Pages/Suppliers/Partials/**/*.vue',
    '!./Pages/Users/FormModal.vue',
    '!./Pages/Users/RoleManagementDialog.vue',
    '!./Pages/Users/RoleManagementModal.vue',
])

installAppPathSupport(router)
installInsecureNotice()

if ('serviceWorker' in navigator && (window.isSecureContext || location.hostname === 'localhost')) {
    navigator.serviceWorker.register(new URL('service-worker.js', appBaseUrl), {
        scope: new URL('./', appBaseUrl).pathname,
        updateViaCache: 'none',
    }).catch(error => console.warn('Không thể đăng ký hỗ trợ offline.', error))
}

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

const pageTitleFor = (page) => {
    const titles = {
        Dashboard: 'Dashboard',
        'Products/Index': 'Sản phẩm', 'Products/Form': 'Thông tin sản phẩm', 'Products/Show': 'Chi tiết sản phẩm',
        'ProductImeis/Index': 'IMEI', 'ProductImeis/Lookup': 'Tra cứu', 'ProductImeis/Show': 'Chi tiết IMEI',
        'Categories/Index': 'Danh mục', 'Categories/Form': 'Thông tin danh mục', 'Brands/Index': 'Thương hiệu',
        'Customers/Index': 'Khách hàng', 'Customers/Create': 'Thêm khách hàng', 'Customers/Edit': 'Sửa khách hàng', 'Customers/Show': 'Chi tiết khách hàng',
        'Sales/Index': 'Hóa đơn bán hàng', 'Sales/Edit': 'Sửa hóa đơn', 'Sales/Receipt': 'Hóa đơn bán hàng',
        'StockImports/List': 'Phiếu nhập hàng',
        'Suppliers/Index': 'Nhà cung cấp', 'Suppliers/Create': 'Thêm nhà cung cấp', 'Suppliers/Edit': 'Sửa nhà cung cấp',
        'Repairs/Index': 'Sửa chữa thiết bị', 'Users/Index': 'Nhân viên', 'Users/Create': 'Thêm nhân viên', 'Users/Edit': 'Sửa nhân viên',
        'Debts/Index': 'Quản lý công nợ', 'Expenses/Index': 'Chi phí cửa hàng',
        'Taxes/Index': 'Khai thuế', 'Reports/Index': 'Báo cáo & Thống kê', 'WorkShifts/History': 'Lịch sử kiểm kê',
        'Settings/Index': 'Thiết lập', 'Profile/Edit': 'Tài khoản cá nhân',
        'Pos/Index': 'POS bán hàng', 'Auth/Login': 'Đăng nhập',
        'Auth/ForgotPassword': 'Quên mật khẩu', 'Auth/ResetPassword': 'Đặt lại mật khẩu', 'Auth/VerifyEmail': 'Xác minh email',
        'Auth/ConfirmPassword': 'Xác nhận mật khẩu', 'Setup/Index': 'Thiết lập ban đầu',
    }
    const title = page?.props?.title || titles[page?.component]
        || page?.component?.split('/').at(-1)?.replace(/([a-z0-9])([A-Z])/g, '$1 $2')
        || 'Dashboard'
    const shopName = page?.props?.settings?.shop_name
    return `${title} - ${shopName || appName}`
}

let resolvedDocumentTitle = `QLBH - ${appName}`

 // ❗ CHẶN ĐĂNG KÝ NHIỀU LẦN
if (!window._inertiaToastRegistered) {

    window._inertiaToastRegistered = true

    let nativeValidationToastTimer = null
    let nativeValidationToastShown = false

    const normalizeFieldName = (name) => String(name || '').replace(/\[([^\]]+)\]/g, '.$1')
    const markInvalidFields = (errors) => {
        const controls = Array.from(document.querySelectorAll('input, select, textarea'))
            .filter((control) => control.name || control.id)
        const firstFieldName = Object.keys(errors || {})[0]
        let firstField = null

        Object.entries(errors || {}).forEach(([name, message]) => {
            const field = controls.find((control) => {
                const controlNames = [control.name, control.id].map(normalizeFieldName).filter(Boolean)
                return controlNames.some((controlName) => controlName === name || controlName.startsWith(`${name}.`))
            })

            if (!field) return

            field.dataset.submitInvalid = 'true'
            field.setAttribute('aria-invalid', 'true')
            if (!firstField && (normalizeFieldName(field.name) === firstFieldName || field.name === firstFieldName)) firstField = field
        })

        return firstField || controls.find((field) => [field.name, field.id].some((value) => normalizeFieldName(value) === firstFieldName)) || null
    }

    document.addEventListener('invalid', (event) => {
        const field = event.target
        if (!(field instanceof HTMLElement)) return

        field.dataset.submitInvalid = 'true'
        field.setAttribute('aria-invalid', 'true')

        if (nativeValidationToastTimer) return
        nativeValidationToastShown = false
        nativeValidationToastTimer = setTimeout(() => {
            nativeValidationToastTimer = null
            if (nativeValidationToastShown) return
            nativeValidationToastShown = true
            const invalidField = document.querySelector('[data-submit-invalid="true"]:invalid')
            const label = invalidField?.labels?.[0]?.textContent?.trim()
            toast.error(label ? `Vui lòng kiểm tra trường: ${label}` : 'Vui lòng điền đầy đủ và đúng các trường bắt buộc.')
        }, 0)
    }, true)

    const clearSubmitInvalid = (event) => {
        const field = event.target
        if (!(field instanceof HTMLElement) || !field.matches('input, select, textarea')) return
        delete field.dataset.submitInvalid
        field.removeAttribute('aria-invalid')
    }

    document.addEventListener('input', clearSubmitInvalid, true)
    document.addEventListener('change', clearSubmitInvalid, true)

    router.on('error', (event) => {

        const errors = event.detail.errors
        if (!errors) return

        const firstMessage = Object.values(errors).flat().find(Boolean)
        if (firstMessage) toast.error(firstMessage)

        setTimeout(() => {
            const el = markInvalidFields(errors)

            if (el) {
                el.focus()
                el.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                })
            }
        }, 100)
    })

    // Lưu dữ liệu bằng form Inertia (nhập hàng, sửa sản phẩm, điều chỉnh kho...) không đi qua axios nên không tự báo
    // cho các tab khác. Phát cùng tín hiệu 'reference-data' để POS và các ô chọn tự nạp lại ngầm.
    let lastVisitMethod = 'get'
    router.on('start', (event) => { lastVisitMethod = String(event.detail?.visit?.method || 'get').toLowerCase() })
    router.on('success', () => {
        if (['get', 'head'].includes(lastVisitMethod)) return
        window.dispatchEvent(new Event('reference-data:changed'))
        try { window.localStorage.setItem('reference-data:version', String(Date.now())) } catch { /* không ảnh hưởng thao tác vừa lưu */ }
        if ('BroadcastChannel' in window) {
            const channel = new BroadcastChannel('reference-data')
            channel.postMessage({ type: 'reference-data:changed' })
            channel.close()
        }
    })

    router.on('success', (event) => {

    const method = event.detail.visit?.method?.toLowerCase()

    if (method && !['get', 'head'].includes(method)) {
        notifyReferenceDataChanged()
    }

    const page = event.detail.page
    const flash = page.props.flash

    if (!flash) return

    if (flash.success) {
        toast.success(flash.success)
    }

    if (flash.error) {
        toast.error(flash.error)
    }

    // QUAN TRỌNG: XÓA FLASH SAU KHI DÙNG
    page.props.flash = {}
})
}

createInertiaApp({
    title: (title) => title ? `${title} - ${appName}` : resolvedDocumentTitle,
    resolve: (name) => resolvePageComponent(
        `./Pages/${name}.vue`,
        pageComponents
    ).then((page) => {


            const adminModules = [

                'Brands/',
                'Categories/',
                'Customers/',
                'ProductImeis/',
                'Products/',
                'Repairs/',
                'Sales/',
                'Suppliers/',
            ]


            if (
                page.default.layout === undefined &&
                adminModules.some(
                    (module) =>
                        name.startsWith(module)
                )
            ) {

                page.default.layout =
                    AdminLayout
            }


            return page

        }),
    setup({ el, App, props, plugin }) {

        const Root = {
            setup() {

               return () => [
                    h(App, props),

                    // 🔥 QUAN TRỌNG: ModalRoot phải ở đây
                    h(ModalRoot),

                    h(Toaster, {
                        richColors: true,
                        position: 'top-right',
                        closeButton: true,
                        style: {
                            zIndex: 9999,
                            position: 'fixed'
                        },
                    }),
                ]
            }
        }

        const app = createApp(Root)

        app.component(
            'Toaster',
            Toaster
        )

        app.directive(
            'click-outside',
            clickOutside
        )

        app.use(plugin)

        
        const applyPageSettings = (page) => {
            const settings = page.props.settings || {}
            setFormatSettings(settings)
            document.documentElement.lang = settings.app_locale || 'vi'

            let printStyle = document.getElementById('configured-print-page')
            if (!printStyle) {
                printStyle = document.createElement('style')
                printStyle.id = 'configured-print-page'
                document.head.appendChild(printStyle)
            }

            const component = page.component || ''
            const printComponents = ['Sales/Receipt']
            if (!printComponents.some((name) => component.endsWith(name))) {
                printStyle.textContent = ''
                return
            }

            const paper = settings.print_paper_size || 'a4'
            const sizes = { a4: 'A4', a5: 'A5', '80mm': '80mm 200mm', '58mm': '58mm 150mm' }
            const thermal = paper === '80mm' || paper === '58mm'
            const orientation = thermal ? '' : ` ${settings.print_orientation === 'landscape' ? 'landscape' : 'portrait'}`
            const pageSize = `${sizes[paper] || sizes.a4}${orientation}`
            const pageMargin = thermal ? '0' : '10mm'
            const receiptWidth = paper === '58mm' ? '54mm' : paper === '80mm' ? '76mm' : '100%'
            printStyle.textContent = `@media print { :root { --configured-receipt-width: ${receiptWidth}; } @page { size: ${pageSize}; margin: ${pageMargin}; } .receipt-container { width: var(--configured-receipt-width) !important; } }`
        }
        applyPageSettings(props.initialPage)
        resolvedDocumentTitle = pageTitleFor(props.initialPage)
        document.title = resolvedDocumentTitle
        router.on('navigate', (event) => {
            const currentPage = event.detail.page
            applyPageSettings(currentPage)
            resolvedDocumentTitle = pageTitleFor(currentPage)
            document.title = resolvedDocumentTitle
            navigator.serviceWorker?.controller?.postMessage({
                type: 'CACHE_OFFLINE_PAGE',
                page: currentPage,
                html: document.documentElement.outerHTML,
            })
        })

        app.config.globalProperties.$money = formatCurrency
        app.config.globalProperties.$currency = getCurrencySymbol
        app.config.globalProperties.$date = formatDate
        app.config.globalProperties.$dateTime = formatDateTime

        app.use(ZiggyVue, window.Ziggy)

            
        app.mount(el)
    },
    progress: {
        color: '#4B5563',
    },
});
