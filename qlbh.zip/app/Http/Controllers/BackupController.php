<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\BackupCloudConnection;
use App\Services\BackupService;
use App\Services\BackupRestoreService;
use App\Services\BackupOperationProgress;
use App\Services\CloudBackupStorage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Throwable;

class BackupController extends Controller
{
    private function backupSettingsRedirect()
    {
        return redirect()->route('settings.index', ['section' => 'backups']);
    }

    public function index(CloudBackupStorage $cloudStorage)
    {
        return redirect()->route('settings.index', ['section' => 'backups']);
    }

    public function pageData(CloudBackupStorage $cloudStorage): array
    {
        $directory = storage_path('app/backups');
        $backups = collect(is_dir($directory) ? File::files($directory) : [])
            ->filter(fn ($file) => preg_match('/^backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:-\d{6})?\.zip$/', $file->getFilename()))
            ->sortByDesc(fn ($file) => $file->getFilename())
            ->map(fn ($file) => [
                'name' => $file->getFilename(),
                'size' => $file->getSize(),
                'created_at' => date('Y-m-d H:i:s', $file->getMTime()),
            ])->values();

        $cloudConnections = BackupCloudConnection::query()->whereIn('provider', BackupCloudConnection::SUPPORTED_PROVIDERS)->orderBy('name')->get()->map(function ($connection) use ($cloudStorage) {
            try {
                return ['id' => $connection->id, 'name' => $connection->name, 'provider' => $connection->provider, 'enabled' => $connection->enabled, 'last_tested_at' => $connection->last_tested_at?->toDateTimeString(), 'backups' => $cloudStorage->backups($connection), 'error' => null];
            } catch (Throwable $exception) {
                return ['id' => $connection->id, 'name' => $connection->name, 'provider' => $connection->provider, 'enabled' => $connection->enabled, 'last_tested_at' => $connection->last_tested_at?->toDateTimeString(), 'backups' => [], 'error' => $exception->getMessage()];
            }
        })->values();

        $redirectBase = rtrim((string) config('services.backup_cloud.redirect_base_url', config('app.url')), '/');
        $redirectHost = strtolower((string) parse_url($redirectBase, PHP_URL_HOST));
        $redirectIsSecure = str_starts_with(strtolower($redirectBase), 'https://')
            || in_array($redirectHost, ['localhost', '127.0.0.1', '[::1]'], true);
        $callbackUri = fn (string $provider) => $redirectBase.route('backups.cloud.oauth.callback', ['provider' => $provider], false);

        return [
            'backups' => $backups,
            'cloud_connections' => $cloudConnections,
            'cloud_oauth' => [
                'google_drive' => filled(config('services.google_drive.client_id')) && filled(config('services.google_drive.client_secret')),
                'onedrive' => filled(config('services.microsoft_onedrive.client_id')) && filled(config('services.microsoft_onedrive.client_secret')),
                'redirect_is_secure' => $redirectIsSecure,
                'redirect_uri' => [
                    'google_drive' => $callbackUri('google_drive'),
                    'onedrive' => $callbackUri('onedrive'),
                ],
            ],
            'restore_preview' => session()->get('restore_preview'),
            'schedule' => [
                'enabled' => (bool) setting('backup_enabled', false),
                'frequency' => setting('backup_frequency', 'daily'),
                'time' => setting('backup_time', '02:00'),
                'weekday' => (int) setting('backup_weekday', 1),
                'monthday' => (int) setting('backup_monthday', 1),
                'last_run' => setting('backup_last_run'),
                'last_error' => setting('backup_last_error'),
            ],
        ];
    }

    public function store(Request $request, BackupService $service, BackupOperationProgress $progress, CloudBackupStorage $cloudStorage)
    {
        $operation = $request->validate(['operation_id' => ['required', 'uuid']])['operation_id'];
        $userId = (int) $request->user()->id;
        $request->session()->save();
        $update = fn ($percent, $message, $state = 'running', $report = null) => $progress->update($userId, $operation, $percent, $message, $state, $report);
        $progress->update($userId, $operation, 1, 'Bắt đầu tạo bản sao lưu.');
        $path = null;
        $uploadedCloudDestinations = [];
        $cloudFailures = [];

        try {
            $connections = BackupCloudConnection::where('enabled', true)->whereIn('provider', BackupCloudConnection::SUPPORTED_PROVIDERS)->get();
            $path = $service->create(fn ($percent, $message) => $update($connections->isEmpty() ? $percent : (int) ($percent * 0.6), $message));
            foreach ($connections as $index => $connection) {
                try {
                    $cloudStorage->upload($connection, $path, basename($path), fn ($percent, $message) => $update(60 + (int) ((($index + $percent / 100) / max(1, $connections->count())) * 39), $message));
                    $uploadedCloudDestinations[] = $connection->name;
                } catch (Throwable $exception) {
                    $cloudFailures[] = ['name' => $connection->name, 'provider' => $connection->provider, 'error' => $exception->getMessage()];
                    $update(60 + (int) ((($index + 1) / max(1, $connections->count())) * 39), 'Không đồng bộ được lên '.$connection->name.': '.$exception->getMessage());
                }
            }
            $contents = $service->manifest($path)['contents'] ?? [];
            $partial = count($cloudFailures) > 0;
            $failureSummary = collect($cloudFailures)->map(fn ($failure) => $failure['name'].': '.$failure['error'])->implode(' | ');
            Setting::set('backup_last_run', now()->toDateTimeString());
            Setting::set('backup_last_error', $partial ? $failureSummary : null);
            $progress->update($userId, $operation, 100, $partial
                ? 'Bản sao lưu cục bộ đã hoàn tất; một số đích đám mây chưa nhận được tệp.'
                : 'Tạo bản sao lưu hoàn tất và đã kiểm tra tính toàn vẹn.', $partial ? 'partial' : 'completed', [
                'title' => $partial ? 'Bản sao lưu cục bộ hoàn tất; đồng bộ đám mây chưa hoàn tất' : 'Báo cáo sao lưu',
                'file' => basename($path),
                'size' => File::size($path),
                'integrity' => 'ZIP hợp lệ; manifest.json và database.sql đã được xác nhận.',
                'database_tables' => $contents['table_count'] ?? 0,
                'database_rows' => $contents['row_count'] ?? 0,
                'table_details' => $contents['tables'] ?? [],
                'uploaded_files' => $contents['uploaded_files'] ?? 0,
                'uploaded_bytes' => $contents['uploaded_bytes'] ?? 0,
                'files_by_disk' => $contents['files_by_disk'] ?? [],
                'uploaded_file_details' => $contents['uploaded_file_details'] ?? [],
                'uploaded_file_details_omitted' => $contents['uploaded_file_details_omitted'] ?? 0,
                'cloud_destinations' => $uploadedCloudDestinations,
                'cloud_failures' => $cloudFailures,
            ]);
            return $this->backupSettingsRedirect()->with('success', $partial
                ? 'Đã tạo bản sao lưu cục bộ; hãy xử lý lỗi đồng bộ đám mây trong báo cáo.'
                : 'Đã tạo bản sao lưu thành công.');
        } catch (Throwable $exception) {
            $report = ['title' => 'Báo cáo sao lưu chưa hoàn tất', 'error' => $exception->getMessage(), 'cloud_destinations' => $uploadedCloudDestinations];
            if ($path && is_file($path)) {
                $contents = $service->manifest($path)['contents'] ?? [];
                $report += [
                    'file' => basename($path), 'size' => File::size($path), 'integrity' => 'Bản backup cục bộ đã được tạo và kiểm tra.',
                    'database_tables' => $contents['table_count'] ?? 0, 'database_rows' => $contents['row_count'] ?? 0,
                    'table_details' => $contents['tables'] ?? [], 'uploaded_files' => $contents['uploaded_files'] ?? 0,
                    'uploaded_bytes' => $contents['uploaded_bytes'] ?? 0, 'files_by_disk' => $contents['files_by_disk'] ?? [],
                    'uploaded_file_details' => $contents['uploaded_file_details'] ?? [],
                    'uploaded_file_details_omitted' => $contents['uploaded_file_details_omitted'] ?? 0,
                ];
            }
            $progress->update($userId, $operation, 100, 'Sao lưu chưa hoàn tất: '.$exception->getMessage(), 'failed', $report);
            return $this->backupSettingsRedirect()->with('error', 'Sao lưu chưa hoàn tất: '.$exception->getMessage());
        }
    }

    public function clearData(Request $request, BackupService $backupService, BackupOperationProgress $progress)
    {
        $data = $request->validate([
            'confirmation' => ['required', 'in:XOA DU LIEU'],
            'operation_id' => ['required', 'uuid'],
        ]);
        $userId = (int) $request->user()->id;
        $operation = $data['operation_id'];
        $request->session()->save();
        $update = fn ($percent, $message, $state = 'running', $report = null) => $progress->update($userId, $operation, $percent, $message, $state, $report);
        $recovery = null;

        try {
            if (DB::connection()->getDriverName() !== 'mysql') {
                throw new \RuntimeException('Chức năng xóa dữ liệu hiện chỉ hỗ trợ MySQL/MariaDB.');
            }
            $update(1, 'Bắt đầu tạo bản sao lưu cứu hộ trước khi xóa.');
            $recovery = $backupService->create(fn ($percent, $message) => $update(2 + (int) ($percent * 0.23), 'Bản cứu hộ: '.$message));

            $preservedTables = [
                'users', 'migrations', 'settings', 'backup_cloud_connections',
                'roles', 'permissions', 'model_has_permissions', 'model_has_roles', 'role_has_permissions',
                'cache', 'cache_locks', 'sessions', 'jobs', 'job_batches', 'failed_jobs',
            ];
            $tables = array_map(fn ($row) => array_values((array) $row)[0], DB::select("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'"));
            $tables = array_values(array_diff($tables, $preservedTables));
            $tableRows = [];
            $totalRows = 0;
            foreach ($tables as $table) {
                $count = (int) DB::table($table)->count();
                $tableRows[$table] = $count;
                $totalRows += $count;
            }

            $update(27, 'Đã tạo bản cứu hộ; bắt đầu xóa dữ liệu nghiệp vụ.');
            DB::statement('SET FOREIGN_KEY_CHECKS=0');
            try {
                $tableCount = max(1, count($tables));
                foreach ($tables as $index => $table) {
                    $quoted = '`'.str_replace('`', '``', $table).'`';
                    DB::statement('TRUNCATE TABLE '.$quoted);
                    $update(27 + (int) floor(($index + 1) / $tableCount * 58), 'Đang làm sạch bảng '.$table.' ('.($index + 1).' / '.count($tables).').');
                }
            } finally {
                DB::statement('SET FOREIGN_KEY_CHECKS=1');
            }

            $filesToDelete = [];
            foreach (['public', 'private'] as $disk) {
                $directory = storage_path('app/'.$disk);
                if (! is_dir($directory)) continue;
                foreach (File::allFiles($directory) as $file) $filesToDelete[] = $file;
            }
            $deletedFiles = 0;
            foreach ($filesToDelete as $file) {
                File::delete($file->getPathname());
                $deletedFiles++;
                $update(85 + (int) floor(($deletedFiles / max(1, count($filesToDelete))) * 13), 'Đang xóa tệp đã tải lên ('.$deletedFiles.' / '.count($filesToDelete).').');
            }

            $update(100, 'Đã xóa dữ liệu nghiệp vụ; tài khoản, quyền và cấu hình được giữ nguyên.', 'completed', [
                'title' => 'Báo cáo xóa dữ liệu',
                'recovery_backup' => basename($recovery),
                'tables_cleared' => count($tables),
                'rows_cleared' => $totalRows,
                'files_cleared' => $deletedFiles,
                'preserved' => 'Tài khoản đăng nhập, phân quyền, cấu hình hệ thống và bản sao lưu.',
            ]);

            return redirect()->route('settings.index', ['section' => 'cleanup'])->with('success', 'Đã xóa dữ liệu nghiệp vụ. Có thể dùng bản cứu hộ để khôi phục.');
        } catch (Throwable $exception) {
            $update(100, 'Không thể hoàn tất việc xóa dữ liệu: '.$exception->getMessage(), 'failed', [
                'title' => 'Xóa dữ liệu thất bại',
                'recovery_backup' => $recovery ? basename($recovery) : null,
                'error' => $exception->getMessage(),
            ]);
            return redirect()->route('settings.index', ['section' => 'cleanup'])->with('error', 'Không thể hoàn tất việc xóa dữ liệu: '.$exception->getMessage());
        }
    }

    public function updateSchedule(Request $request)
    {
        $data = $request->validate([
            'enabled' => ['required', 'boolean'],
            'frequency' => ['required', 'in:daily,weekly,monthly'],
            'time' => ['required', 'date_format:H:i'],
            'weekday' => ['required', 'integer', 'between:0,6'],
            'monthday' => ['required', 'integer', 'between:1,31'],
        ]);

        foreach ($data as $key => $value) {
            Setting::set('backup_'.($key === 'enabled' ? 'enabled' : $key), $value);
        }

        return $this->backupSettingsRedirect()->with('success', 'Đã lưu lịch sao lưu tự động.');
    }

    public function inspect(Request $request, string $backup, BackupRestoreService $restoreService, BackupOperationProgress $progress)
    {
        $operation = $request->validate(['operation_id' => ['required', 'uuid']])['operation_id'];
        $userId = (int) $request->user()->id;
        $request->session()->save();
        $update = fn ($percent, $message, $report = null) => $progress->update($userId, $operation, $percent, $message, 'running', $report);
        try {
            $progress->update($userId, $operation, 1, 'Đang kiểm tra tệp sao lưu.');
            $preview = $restoreService->inspect($backup, $update);
            $progress->update($userId, $operation, 100, 'Đối chiếu hoàn tất.', 'completed');
            return $this->backupSettingsRedirect()->with('restore_preview', $preview)->with('success', 'Đã kiểm tra tính toàn vẹn và đối chiếu cấu trúc bản sao lưu.');
        } catch (Throwable $exception) {
            $progress->update($userId, $operation, 100, 'Đối chiếu thất bại: '.$exception->getMessage(), 'failed');
            return $this->backupSettingsRedirect()->with('error', 'Không thể kiểm tra bản sao lưu: '.$exception->getMessage());
        }
    }

    public function import(Request $request, BackupRestoreService $restoreService, BackupOperationProgress $progress)
    {
        $data = $request->validate([
            'backup_file' => ['required', 'file', 'mimes:zip', 'max:524288'],
            'operation_id' => ['required', 'uuid'],
        ]);
        $operation = $data['operation_id'];
        $userId = (int) $request->user()->id;
        $request->session()->save();
        $progress->update($userId, $operation, 1, 'Đang nhận tệp sao lưu.');

        $filename = 'backup_'.now()->format('Y-m-d_H-i-s-u').'.zip';
        $directory = storage_path('app/backups');
        File::ensureDirectoryExists($directory);
        $data['backup_file']->move($directory, $filename);

        try {
            $progress->update($userId, $operation, 35, 'Đã tải tệp lên; đang kiểm tra cấu trúc và dữ liệu.');
            $preview = $restoreService->inspect($filename, fn ($percent, $message, $report = null) => $progress->update($userId, $operation, 35 + (int) ($percent * 0.64), $message, 'running', $report));
            $progress->update($userId, $operation, 100, 'Tải lên và đối chiếu hoàn tất.', 'completed');
            return $this->backupSettingsRedirect()->with('restore_preview', $preview)->with('success', 'Đã tải tệp lên và kiểm tra cấu trúc bản sao lưu.');
        } catch (Throwable $exception) {
            File::delete($directory.DIRECTORY_SEPARATOR.$filename);
            $progress->update($userId, $operation, 100, 'Kiểm tra tệp sao lưu thất bại: '.$exception->getMessage(), 'failed');
            return $this->backupSettingsRedirect()->with('error', 'Tệp không phải bản sao lưu hợp lệ: '.$exception->getMessage());
        }
    }

    public function restore(Request $request, string $backup, BackupRestoreService $restoreService, BackupService $backupService, BackupOperationProgress $progress)
    {
        $data = $request->validate([
            'mode' => ['required', 'in:replace,merge'],
            'conflict_policy' => ['required', 'in:keep_current,use_backup'],
            'confirmed' => ['required', 'accepted'],
            'operation_id' => ['required', 'uuid'],
        ]);
        $operation = $data['operation_id'];
        $userId = (int) $request->user()->id;
        $request->session()->save();
        $update = fn ($percent, $message, $state = 'running', $report = null) => $progress->update($userId, $operation, $percent, $message, $state, $report);

        try {
            $update(1, 'Bắt đầu kiểm tra dữ liệu để khôi phục.');
            $result = $restoreService->restore($backup, $data['mode'], $data['conflict_policy'], $backupService, $update);
            Setting::set('backup_last_run', now()->toDateTimeString());
            Setting::set('backup_last_error', null);
            $message = $result['mode'] === 'replace'
                ? 'Đã khôi phục toàn bộ cơ sở dữ liệu. Bản dữ liệu trước đó được lưu làm điểm phục hồi.'
                : 'Đã gộp dữ liệu từ bản sao lưu theo lựa chọn xử lý xung đột.';
            $update(100, 'Khôi phục hoàn tất.', 'completed', [
                'title' => 'Báo cáo khôi phục',
                'mode' => $result['mode'] === 'replace' ? 'Thay toàn bộ dữ liệu' : 'Gộp dữ liệu',
                'conflict_policy' => $result['mode'] === 'merge' ? ($data['conflict_policy'] === 'keep_current' ? 'Giữ dữ liệu hiện tại khi trùng' : 'Dùng dữ liệu từ bản sao lưu khi trùng') : null,
                'backup' => $backup,
                'recovery_backup' => $result['recovery_backup'] ?? null,
                'tables' => $result['summary']['backup_tables'],
                'backup_rows' => $result['summary']['backup_rows'],
                'current_rows_before' => $result['summary']['current_rows'],
                'restored_rows' => $result['restored_rows'] ?? null,
                'table_results' => collect($result['merge_report']['tables'] ?? $result['table_report'] ?? [])->map(fn ($counts, $table) => is_int($table) ? $counts : ['table' => $table] + $counts)->values()->all(),
                'files_report' => $result['files'] ?? ($result['merge_report']['files'] ?? ['added' => 0, 'overwritten' => 0, 'skipped' => 0, 'deleted' => 0]),
                'backup_files' => $result['files_count'] ?? 0,
                'backup_files_bytes' => $result['files_total_bytes'] ?? 0,
                'backup_files_omitted' => $result['files_omitted'] ?? 0,
                'backup_file_details' => $result['backup_file_details'] ?? [],
                'tables_missing_from_backup' => $result['summary']['tables_missing_from_backup'] ?? [],
                'tables_missing_from_current' => $result['summary']['tables_missing_from_current'] ?? [],
                'database' => 'Cơ sở dữ liệu đã được xử lý và kiểm tra khóa ngoại.',
                'files' => $result['has_files'] ? 'Tệp đính kèm đã được khôi phục theo chế độ đã chọn.' : 'Bản sao lưu không có tệp đính kèm.',
            ]);
            return $this->backupSettingsRedirect()->with('success', $message)->with('restore_preview', null);
        } catch (Throwable $exception) {
            preg_match('/(backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:-\d{6})?\.zip)/', $exception->getMessage(), $recoveryMatch);
            $update(100, 'Khôi phục thất bại: '.$exception->getMessage(), 'failed', [
                'title' => 'Báo cáo khôi phục thất bại',
                'backup' => $backup,
                'recovery_backup' => $recoveryMatch[1] ?? null,
                'rollback_status' => isset($recoveryMatch[1]) ? 'Đã thử phục hồi từ bản cứu hộ được ghi bên trên.' : 'Chưa có bản cứu hộ; lỗi xảy ra trước bước xử lý dữ liệu.',
                'error' => $exception->getMessage(),
            ]);
            return $this->backupSettingsRedirect()->with('error', 'Khôi phục chưa hoàn tất: '.$exception->getMessage());
        }
    }

    public function progress(Request $request, string $operation, BackupOperationProgress $progress)
    {
        return response()->json($progress->get((int) $request->user()->id, $operation));
    }

    public function destroyCloudConnection(BackupCloudConnection $connection)
    {
        $connection->delete();
        return $this->backupSettingsRedirect()->with('success', 'Đã xóa kết nối đám mây.');
    }

    public function toggleCloudConnection(BackupCloudConnection $connection)
    {
        $connection->enabled = ! $connection->enabled;
        $connection->save();
        return $this->backupSettingsRedirect()->with('success', $connection->enabled ? 'Đã bật sao lưu lên '.$connection->name.'.' : 'Đã tạm dừng sao lưu lên '.$connection->name.'.');
    }

    public function inspectCloudBackup(Request $request, BackupCloudConnection $connection, CloudBackupStorage $cloudStorage, BackupRestoreService $restoreService, BackupOperationProgress $progress)
    {
        $data = $request->validate(['name' => ['required', 'string'], 'operation_id' => ['required', 'uuid']]);
        $userId = (int) $request->user()->id;
        $operation = $data['operation_id'];
        $request->session()->save();
        $localName = 'backup_'.now()->format('Y-m-d_H-i-s-u').'.zip';
        $localPath = storage_path('app/backups/'.$localName);
        File::ensureDirectoryExists(dirname($localPath));
        try {
            $progress->update($userId, $operation, 5, 'Đang tải bản sao lưu từ '.$connection->name.'.');
            $cloudStorage->download($connection, $data['name'], $localPath, fn ($percent, $message) => $progress->update($userId, $operation, 5 + (int) ($percent * 0.44), $message));
            $preview = $restoreService->inspect($localName, fn ($percent, $message, $report = null) => $progress->update($userId, $operation, 50 + (int) ($percent * 0.49), $message, 'running', $report));
            $progress->update($userId, $operation, 100, 'Đã tải xuống và đối chiếu xong.', 'completed');
            return $this->backupSettingsRedirect()->with('restore_preview', $preview)->with('success', 'Đã tải bản sao lưu từ đám mây và kiểm tra dữ liệu.');
        } catch (Throwable $exception) {
            File::delete($localPath);
            $progress->update($userId, $operation, 100, 'Tải hoặc đối chiếu bản sao lưu đám mây thất bại: '.$exception->getMessage(), 'failed');
            return $this->backupSettingsRedirect()->with('error', 'Không thể kiểm tra bản sao lưu đám mây: '.$exception->getMessage());
        }
    }

    public function destroyCloudBackup(Request $request, BackupCloudConnection $connection, CloudBackupStorage $cloudStorage)
    {
        $data = $request->validate(['name' => ['required', 'string']]);
        $cloudStorage->delete($connection, $data['name']);
        return $this->backupSettingsRedirect()->with('success', 'Đã xóa bản sao lưu trên '.$connection->name.'.');
    }

    public function download(string $backup): BinaryFileResponse
    {
        abort_unless(preg_match('/^backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:-\d{6})?\.zip$/', $backup), 404);
        $path = storage_path('app/backups/'.$backup);
        abort_unless(is_file($path), 404);

        return response()->download($path);
    }

    public function destroy(Request $request, string $backup, BackupOperationProgress $progress)
    {
        abort_unless(preg_match('/^backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(?:-\d{6})?\.zip$/', $backup), 404);
        $path = storage_path('app/backups/'.$backup);
        abort_unless(is_file($path), 404);
        $operation = $request->validate(['operation_id' => ['required', 'uuid']])['operation_id'];
        $progress->update((int) $request->user()->id, $operation, 35, 'Đang xóa tệp sao lưu.');
        File::delete($path);
        $progress->update((int) $request->user()->id, $operation, 100, 'Đã xóa tệp sao lưu.', 'completed');

        return $this->backupSettingsRedirect()->with('success', 'Đã xóa bản sao lưu.');
    }

    public function destroyMany(Request $request, BackupOperationProgress $progress)
    {
        $data = $request->validate([
            'names' => ['required', 'array', 'min:1', 'max:100'],
            'names.*' => ['required', 'string', 'distinct', 'regex:/^backup_\\d{4}-\\d{2}-\\d{2}_\\d{2}-\\d{2}-\\d{2}(?:-\\d{6})?\\.zip$/'],
            'operation_id' => ['required', 'uuid'],
        ]);

        $directory = storage_path('app/backups');
        $paths = array_map(fn ($name) => $directory.DIRECTORY_SEPARATOR.$name, $data['names']);
        abort_unless(collect($paths)->every(fn ($path) => is_file($path)), 404, 'Một hoặc nhiều tệp sao lưu không còn tồn tại.');

        $userId = (int) $request->user()->id;
        $total = count($paths);
        foreach ($paths as $index => $path) {
            File::delete($path);
            $percent = (int) floor((($index + 1) / $total) * 100);
            $progress->update($userId, $data['operation_id'], $percent, 'Đang xóa bản sao lưu '.($index + 1).' / '.$total.'.', $index + 1 === $total ? 'completed' : 'running');
        }

        return $this->backupSettingsRedirect()->with('success', 'Đã xóa '.$total.' tệp sao lưu.');
    }
}
