<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Sale;
use App\Models\WorkShift;
use App\Services\PosCheckoutService;
use App\Models\BankPaymentIntent;
use App\Models\Customer;
use App\Notifications\SystemNotification;
use App\Support\NotificationRecipients;
use App\Support\PosTotals;
use Illuminate\Support\Facades\Notification;

class PosController extends Controller
{
    public function paymentSettings()
    {
        $accounts = collect(json_decode((string) setting('bank_accounts', '[]'), true) ?: [])
            ->map(function (array $account): array {
                $apiKey = (string) ($account['payment_api_key'] ?? '');
                $apiAccessKey = (string) ($account['payment_api_access_key'] ?? '');
                $apiSecretKey = (string) ($account['payment_api_secret_key'] ?? '');
                $webhookSecret = (string) ($account['payment_webhook_secret'] ?? '');
                unset($account['payment_api_key'], $account['payment_api_access_key'], $account['payment_api_secret_key'], $account['payment_webhook_secret']);
                $provider = strtolower((string) ($account['payment_provider'] ?? ''));
                $account['payment_auto_enabled'] = $provider === 'apipay'
                    ? (filled($webhookSecret) && filled($apiAccessKey) && filled($apiSecretKey) && filled($account['payment_provider_account_id'] ?? null))
                    : ($provider === 'sepay' && (filled($apiKey) || filled($webhookSecret)));
                return $account;
            })->values()->all();

        return response()->json(['settings' => [
            'bank_bin' => setting('bank_bin', ''),
            'bank_account' => setting('bank_account', ''),
            'bank_account_name' => setting('bank_account_name', ''),
            'bank_accounts' => $accounts,
            'bank_transfer_content' => setting('bank_transfer_content', 'Thanh toan don hang'),
            'bank_qr_theme' => setting('bank_qr_theme', 'classic'),
            'payment_voice_language' => setting('payment_voice_language', 'vi-VN'),
            'payment_voice_enabled' => filter_var(setting('payment_voice_enabled', true), FILTER_VALIDATE_BOOLEAN),
        ]]);
    }

    public function startBankPayment(Request $request)
    {
        $data = $request->validate([
            'items' => ['required', 'array', 'min:1'],
            'items.*.id' => ['required', 'integer', 'exists:products,id'],
            'items.*.price' => ['required', 'numeric', 'min:0'],
            'items.*.apply_vat' => ['sometimes', 'boolean'],
            'items.*.quantity' => ['nullable', 'integer', 'min:1'],
            'items.*.discount_type' => ['nullable', 'in:percent,amount'],
            'items.*.discount_value' => ['nullable', 'numeric', 'min:0'],
            'items.*.variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
            'items.*.imei_id' => ['nullable', 'integer', 'exists:product_imeis,id'],
            'items.*.warranty_days' => ['nullable', 'integer', 'min:0', 'max:3650'],
            'items.*.warranty_value' => ['nullable', 'integer', 'min:0', 'max:3650'],
            'items.*.warranty_unit' => ['nullable', 'in:day,month'],
            'items.*.warranty_note' => ['nullable', 'string', 'max:1000'],
            'items.*.note' => ['nullable', 'string', 'max:1000'],
            'items.*.gifts' => ['nullable', 'array'],
            'items.*.gifts.*.id' => ['required', 'integer', 'exists:products,id'],
            'items.*.gifts.*.quantity' => ['nullable', 'integer', 'min:1'],
            'items.*.gifts.*.variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
            'items.*.gifts.*.imei_id' => ['nullable', 'integer', 'exists:product_imeis,id'],
            'items.*.unit_id' => ['nullable', 'integer', 'exists:units,id'],
            'items.*.unit_name' => ['nullable', 'string', 'max:100'],
            'items.*.conversion_factor' => ['nullable', 'integer', 'min:1'],
            'customer_id' => ['nullable', 'integer', 'exists:customers,id'],
            'pay_old_debt' => ['required', 'boolean'],
            'invoice_code' => ['required', 'string', 'regex:/^INV-[0-9]{14}$/'],
            'expected_amount' => ['required', 'integer', 'min:1', 'max:9999999999999'],
            'invoice_discount' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'invoice_discount_type' => ['nullable', 'in:amount,percent'],
            'extra_fee' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'total_amount' => ['required', 'integer', 'min:1', 'max:9999999999999'],
            'cash_received_amount' => ['nullable', 'integer', 'min:0', 'max:9999999999999'],
            'bank_account' => ['required', 'string', 'max:50'],
        ]);

        $openingCountEnabled = filter_var(setting('work_shift_opening_count_enabled', true), FILTER_VALIDATE_BOOLEAN);
        $shift = WorkShift::query()->where('user_id', $request->user()->id)->whereNull('closed_at')->latest('opened_at')->first();
        abort_if($openingCountEnabled && ! $shift, 422, 'Vui lòng mở ca làm trước khi nhận thanh toán.');
        $exists = BankPaymentIntent::query()->where('invoice_code', $data['invoice_code'])->exists();
        abort_if($exists || Sale::query()->where('code', $data['invoice_code'])->exists(), 422, 'Mã hóa đơn đã được sử dụng.');

        $configuredAccounts = json_decode((string) setting('bank_accounts', '[]'), true) ?: [];
        if (! $configuredAccounts && filled(setting('bank_account', ''))) $configuredAccounts = [['bank_account' => setting('bank_account', '')]];
        $bankAccountConfig = collect($configuredAccounts)->first(fn ($account) => (string) ($account['bank_account'] ?? '') === (string) $data['bank_account']);
        abort_unless($bankAccountConfig, 422, 'Tài khoản nhận tiền không nằm trong danh sách cấu hình.');
        $provider = strtolower((string) ($bankAccountConfig['payment_provider'] ?? ''));
        $decryptSetting = function (string $key) use ($bankAccountConfig): string {
            $value = (string) ($bankAccountConfig[$key] ?? '');
            if ($value === '') return '';
            try { return \Illuminate\Support\Facades\Crypt::decryptString($value); } catch (\Throwable) { return $value; }
        };
        $hasSecret = $decryptSetting('payment_webhook_secret') !== '';
        $hasApiKey = $decryptSetting('payment_api_key') !== '';
        $apiAccessKey = $decryptSetting('payment_api_access_key');
        $apiSecretKey = $decryptSetting('payment_api_secret_key');
        $hasApiPayKeys = $apiAccessKey !== '' && $apiSecretKey !== '';
        abort_unless(($provider === 'apipay' && $hasSecret && $hasApiPayKeys && filled($bankAccountConfig['payment_provider_account_id'] ?? null)) || ($provider === 'sepay' && ($hasSecret || $hasApiKey)), 422, 'Tài khoản ngân hàng này chưa cấu hình đầy đủ dịch vụ nhận giao dịch.');

        $invoiceDiscountType = ($data['invoice_discount_type'] ?? 'amount') === 'percent' ? 'percent' : 'amount';
        abort_if($invoiceDiscountType === 'percent' && (float) ($data['invoice_discount'] ?? 0) > 100, 422, 'Chiết khấu phần trăm không được vượt quá 100%.');
        $vatRate = (float) setting('pos_vat_rate', 10);
        $totals = PosTotals::calculate($data['items'], (float) ($data['invoice_discount'] ?? 0), $invoiceDiscountType, (float) ($data['extra_fee'] ?? 0), $vatRate);
        $extraFee = $totals['extra_fee'];
        $checkoutTotal = (int) round($totals['grand_total']);
        if ($data['pay_old_debt']) {
            $customer = Customer::query()->findOrFail($data['customer_id'] ?? null);
            $checkoutTotal += (int) round((float) $customer->debt_balance);
        }
        abort_unless($checkoutTotal === (int) $data['total_amount'], 422, 'Tổng tiền cần thanh toán đã thay đổi. Vui lòng mở lại QR.');
        $expected = (int) $data['expected_amount'];
        abort_unless($expected <= $checkoutTotal, 422, 'Số tiền chuyển khoản không được lớn hơn tổng tiền cần thanh toán.');
        $cashReceivedAmount = (int) ($data['cash_received_amount'] ?? 0);
        abort_if(! ($data['customer_id'] ?? null) && $expected + $cashReceivedAmount < $checkoutTotal, 422, 'Khách lẻ cần thanh toán đủ tổng tiền bằng tiền mặt và chuyển khoản.');

        $intent = BankPaymentIntent::query()->create([
            'invoice_code' => $data['invoice_code'],
            'user_id' => $request->user()->id,
            'work_shift_id' => $shift?->id,
            'bank_account' => $data['bank_account'],
            'expected_amount' => $expected,
            'received_amount' => 0,
            'checkout_payload' => [
                'items' => $data['items'],
                'customer_id' => $data['customer_id'] ?? null,
                'pay_old_debt' => $data['pay_old_debt'],
                'cash_received_amount' => $cashReceivedAmount,
                // Lưu giá trị gốc người dùng nhập (không phải số tiền đã quy đổi) để webhook tính lại đúng theo loại giảm giá.
                'invoice_discount' => (float) ($data['invoice_discount'] ?? 0),
                'invoice_discount_type' => $invoiceDiscountType,
                'extra_fee' => $extraFee,
                'vat_rate' => $vatRate,
            ],
            'status' => 'waiting',
            'expires_at' => now()->addMinutes(15),
        ]);

        $providerPayment = [];
        if ($provider === 'apipay') {
            $auth = base64_encode($apiAccessKey . ':' . $apiSecretKey);
            try {
                $response = \Illuminate\Support\Facades\Http::timeout(15)
                    ->acceptJson()
                    ->withHeaders(['Authorization' => 'Bearer ' . $auth])
                    ->post('https://app.apipay.vn/v1/client/payment-requests', [
                        'bankPublicId' => $bankAccountConfig['payment_provider_account_id'],
                        'amount' => (string) $expected,
                        // Keep the QLBH invoice code as the transfer memo so
                        // the signed transaction.in webhook maps to this intent.
                        'content' => $intent->invoice_code,
                    ]);
            } catch (\Illuminate\Http\Client\ConnectionException $exception) {
                $intent->delete();
                \Illuminate\Support\Facades\Log::warning('ApiPay payment request connection failed.', ['message' => $exception->getMessage()]);
                abort(502, 'Không kết nối được ApiPay để tạo mã thanh toán. Vui lòng thử lại.');
            }

            $providerPayment = $response->json('data') ?? [];
            if (! $response->successful() || ! filled($providerPayment['payUrl'] ?? null) || ! filled($providerPayment['qrUrl'] ?? null)) {
                $intent->delete();
                \Illuminate\Support\Facades\Log::warning('ApiPay payment request failed.', ['status' => $response->status(), 'response' => $response->json()]);
                abort(502, 'ApiPay không tạo được mã QR. Kiểm tra API keys và Bank Account Public ID.');
            }

            $checkoutPayload = $intent->checkout_payload;
            $checkoutPayload['provider_payment_url'] = $providerPayment['payUrl'];
            $checkoutPayload['provider_qr_url'] = $providerPayment['qrUrl'];
            $intent->update(['checkout_payload' => $checkoutPayload]);
        }

        return response()->json(['success' => true, 'data' => [
            'id' => $intent->id,
            'invoice_code' => $intent->invoice_code,
            'expected_amount' => $expected,
            'expires_at' => $intent->expires_at,
            'provider_payment_url' => $providerPayment['payUrl'] ?? null,
            'provider_qr_url' => $providerPayment['qrUrl'] ?? null,
        ]]);
    }

    public function bankPaymentStatus(Request $request, BankPaymentIntent $intent)
    {
        abort_unless($intent->user_id === $request->user()->id, 404);
        if ($intent->status === 'waiting' && $intent->received_amount == 0 && $intent->expires_at->isPast()) $intent->update(['status' => 'expired']);

        return response()->json(['success' => true, 'data' => [
            'status' => $intent->status,
            'expected_amount' => (int) $intent->expected_amount,
            'received_amount' => (int) $intent->received_amount,
            'difference' => (int) $intent->received_amount - (int) $intent->expected_amount,
            'sale' => $intent->sale_response,
        ]]);
    }

    public function cancelBankPayment(Request $request, BankPaymentIntent $intent)
    {
        abort_unless($intent->user_id === $request->user()->id, 404);
        if ($intent->status === 'waiting' && $intent->received_amount > 0) {
            return response()->json(['success' => false, 'message' => 'Đã nhận một phần tiền. Không thể dừng đối soát; hãy tiếp tục chờ khách chuyển đủ.'], 422);
        }
        if ($intent->status === 'waiting') $intent->update(['status' => 'cancelled']);
        return response()->json(['success' => true]);
    }
    public function index(): Response
    {
        return Inertia::render(
            'Pos/Index'
        );
    }

    // Thanh toán
    public function checkout(
        Request $request,
        PosCheckoutService $service,
    )
    {
        $openingCountEnabled = filter_var(setting('work_shift_opening_count_enabled', true), FILTER_VALIDATE_BOOLEAN);
        $workShift = WorkShift::query()
            ->where('user_id', auth()->id())
            ->whereNull('closed_at')
            ->latest('opened_at')
            ->first();

        if ($openingCountEnabled && ! $workShift) {
            return response()->json(['success' => false, 'message' => 'Vui lòng mở ca làm trước khi bán hàng.'], 422);
        }

        // 1. THÊM VALIDATE: Kiểm tra dữ liệu đầu vào chặt chẽ
        $request->validate([

            'items' => 'required|array|min:1',
            'items.*.id' => 'required|integer|exists:products,id',
            'items.*.price' => 'required|numeric|min:0',
            'items.*.quantity' => 'nullable|numeric|min:0',

            'payment_method' => 'required|in:cash,bank,mixed,card',
            'bank_account' => 'nullable|string|max:50',
            'cash_received_amount' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'bank_received_amount' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'paid_amount' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'invoice_discount' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'invoice_discount_type' => ['nullable', 'in:amount,percent'],
            'extra_fee' => ['nullable', 'numeric', 'min:0', 'max:9999999999999'],
            'invoice_code' => ['nullable', 'string', 'regex:/^INV-[0-9]{14}$/', 'unique:sales,code'],

            'items.*.discount_type' => 'nullable|string',

            'items.*.discount_value' => 'nullable|numeric|min:0',
            'items.*.apply_vat' => 'sometimes|boolean',

            'items.*.variant_id' => 'nullable|integer|exists:product_variants,id',
            
            'items.*.imei_id' => 'nullable|integer|exists:product_imeis,id',

            'items.*.warranty_days' => 'nullable|integer|min:0|max:3650',

            'items.*.warranty_value' => 'nullable|integer|min:0|max:3650',

            'items.*.warranty_unit' => 'nullable|in:day,month',

            'items.*.warranty_note' => 'nullable|string|max:1000',

            'items.*.gift_product_id' => 'nullable|integer',

            'items.*.gifts' => 'nullable|array',

            'items.*.gifts.*.id' => 'required|integer|exists:products,id',

            'items.*.gifts.*.quantity' => 'nullable|integer|min:1',

            'items.*.gifts.*.variant_id' => 'nullable|integer|exists:product_variants,id',

            'items.*.gifts.*.imei_id' => 'nullable|integer|exists:product_imeis,id',

            'items.*.unit_id' => 'nullable|integer|exists:units,id',

            'items.*.unit_name' => 'nullable|string|max:100',

            'items.*.conversion_factor' => 'nullable|integer|min:1',

        ],
        [
            'items.required' => 'Giỏ hàng không được để trống.',
            'items.min' => 'Giỏ hàng không được để trống.',
            'payment_method.required' => 'Vui lòng chọn phương thức thanh toán.',
        ]);

        abort_if(
            $request->input('invoice_discount_type') === 'percent'
                && (float) $request->input('invoice_discount', 0) > 100,
            422,
            'Chiết khấu phần trăm không được vượt quá 100%.'
        );

        if ($request->payment_method === 'mixed') {
            $splitTotal = (float) ($request->cash_received_amount ?? 0) + (float) ($request->bank_received_amount ?? 0);
            abort_unless(abs($splitTotal - (float) ($request->paid_amount ?? 0)) < 0.01, 422, 'Tổng tiền mặt và chuyển khoản không khớp số tiền đã nhận.');
        }

        if ($request->customer_id) {
            Customer::query()->findOrFail($request->customer_id)->assertCanTransact();
        }

        try {

            $sale = $service->checkout(
                items: $request->items,
                customerId: $request->customer_id,
                paidAmount: $request->paid_amount ?? 0,
                paymentMethod: $request->payment_method ?? 'cash',
                payOldDebt: (bool) $request->pay_old_debt,
                userId: auth()->id(),
                invoiceCode: $request->input('invoice_code'),
                cashReceivedAmount: $request->input('cash_received_amount') !== null ? (float) $request->input('cash_received_amount') : null,
                bankReceivedAmount: $request->input('bank_received_amount') !== null ? (float) $request->input('bank_received_amount') : null,
                invoiceDiscount: (float) ($request->input('invoice_discount') ?? 0),
                invoiceDiscountType: ($request->input('invoice_discount_type') ?? 'amount') === 'percent' ? 'percent' : 'amount',
                extraFee: (float) ($request->input('extra_fee') ?? 0),
                vatRate: (float) setting('pos_vat_rate', 10),
                workShiftId: $workShift?->id,
                bankAccount: $request->input('bank_account'),
            );

            $sale->load([
                'items.product.conversionUnit',
                'items.variant',
                'items.productImei',
                'items.gifts.product',
                'customer',
            ]);

            Notification::send(
                NotificationRecipients::withPermission('sales.view'),
                new SystemNotification(
                    'Đơn hàng mới',
                    'Hóa đơn ' . $sale->code . ' đã được tạo cho ' . ($sale->customer?->full_name ?? 'khách lẻ') . '.',
                    'sale',
                    route('sales.index', ['open_sale' => $sale->id], false),
                    ['required_permission' => 'sales.view']
                )
            );

            return response()->json([
                'success' => true,
                'data' => [
                    'id' => $sale->id,
                    'code' => $sale->code,
                    'customer' => [
                        'full_name' => $sale->customer?->full_name ?? 'Khách lẻ',
                    ],
                    'items' => $sale->items->map(function ($item) {

                        return [
                            'id' => $item->id,
                            'quantity' => $item->quantity,
                            'unit_name' => $item->unit_name,
                            'unit_price' => $item->unit_price,
                            'subtotal' => $item->subtotal,
                            'imei' => $item->productImei?->imei,
                            'warranty_days' => $item->warranty_days,
                            'warranty_value' => $item->warranty_value,
                            'warranty_unit' => $item->warranty_unit,
                            'warranty_note' => $item->warranty_note,
                            'warranty_expires_at' => $item->productImei?->customer_warranty_expires_at,
                            'variant' => $item->variant
                                ? [
                                    'id' => $item->variant->id,
                                    'attributes' => $item->variant->attributes,
                                ]
                                : null,
                            'product' => [
                                'name' => $item->product->name,
                            ],
                        ];
                    }),
                    'subtotal' => $sale->subtotal,
                    'discount' => $sale->discount,
                    'paid' => (float) $sale->paid_amount,
                    'cash_received_amount' => (float) $sale->cash_received_amount,
                    'bank_received_amount' => (float) $sale->bank_received_amount,
                    'change' => (float) $sale->change_amount,
                    'payment_method' => $sale->payment_method ?? 'cash',
                ],
            ]);

        } catch (\Exception $e) {

            \Log::error($e);

            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }
}
