<?php

namespace App\Http\Controllers;

use App\Models\StockImport;
use App\Support\DefaultPurchaseContract;
use App\Models\ProductImeiHistory;
use App\Services\Stock\StockImportService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Category;
use App\Models\Supplier;
use App\Models\Product;
use App\Models\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Validation\Rule;

class StockImportController extends Controller
{
    protected StockImportService $service;

    public function __construct(StockImportService $service)
    {
        $this->service = $service;
    }

    /**
     * Danh sách phiếu nhập hàng
     */
    public function index(Request $request): Response|JsonResponse
    {
        $search = $request
            ->string('search')
            ->trim()
            ->toString();
        $partyType = in_array($request->query('party_type'), ['supplier', 'customer'], true)
            ? $request->query('party_type')
            : '';
        $status = in_array($request->query('status'), ['completed', 'draft', 'cancelled'], true)
            ? $request->query('status')
            : '';
        $dateFrom = $request->date('date_from')?->toDateString() ?? '';
        $dateTo = $request->date('date_to')?->toDateString() ?? '';
        $perPage = in_array((int) $request->query('per_page', 20), [10, 20, 50, 100], true)
            ? (int) $request->query('per_page', 20) : 20;
        $sortBy = in_array($request->query('sort_by'), ['code', 'import_date', 'items_count', 'grand_total', 'status'], true)
            ? $request->query('sort_by') : 'id';
        $sortOrder = $request->query('sort_order') === 'asc' ? 'asc' : 'desc';

        $imports = StockImport::query()
            ->with([
                'supplier:id,name,phone',
                'customer:id,code,full_name,phone,cccd,address',
                'user:id,name',
            ])
            ->withCount('items')
            ->when($partyType !== '', fn ($query) => $query->where('party_type', $partyType))
            ->when($status !== '', fn ($query) => $query->where('status', $status))
            ->when($dateFrom !== '', fn ($query) => $query->whereDate('import_date', '>=', $dateFrom))
            ->when($dateTo !== '', fn ($query) => $query->whereDate('import_date', '<=', $dateTo))
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query
                        ->where('code', 'like', "%{$search}%")
                        ->orWhereHas('supplier', function ($supplier) use ($search) {
                            $supplier
                                ->where('name', 'like', "%{$search}%")
                                ->orWhere('phone', 'like', "%{$search}%");
                        })
                        ->orWhereHas('customer', function ($customer) use ($search) {
                            $customer
                                ->where('full_name', 'like', "%{$search}%")
                                ->orWhere('phone', 'like', "%{$search}%")
                                ->orWhere('cccd', 'like', "%{$search}%");
                        })
                        ->orWhere('party_name', 'like', "%{$search}%")
                        ->orWhere('party_phone', 'like', "%{$search}%")
                        ->orWhereHas('user', fn ($user) => $user->where('name', 'like', "%{$search}%"))
                        ->orWhereHas('items.product', fn ($product) => $product
                            ->where('name', 'like', "%{$search}%")
                            ->orWhere('sku', 'like', "%{$search}%"))
                        ->orWhereIn('id', ProductImeiHistory::query()
                            ->where('reference_type', StockImport::class)
                            ->where('type', 'import')
                            ->whereHas('productImei', fn ($imei) => $imei
                                ->where('imei', 'like', "%{$search}%")
                                ->orWhere('serial', 'like', "%{$search}%"))
                            ->select('reference_id'));
                });
            })
            ->when($sortBy === 'items_count', fn ($query) => $query->orderBy('items_count', $sortOrder), fn ($query) => $query->orderBy($sortBy, $sortOrder))
            ->paginate($perPage)
            ->withQueryString();

        if ($search !== '') {
            $this->attachSearchMatches($imports, $search);
        }

        $filters = [
            'search' => $search,
            'party_type' => $partyType,
            'status' => $status,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
            'per_page' => $perPage,
            'sort_by' => $sortBy,
            'sort_order' => $sortOrder,
        ];

        // Tìm kiếm tức thời: giao diện gọi AJAX và chỉ nhận JSON, không tải lại trang
        if ($request->expectsJson()) {
            return response()->json([
                'imports' => $imports,
                'filters' => $filters,
            ]);
        }

        return Inertia::render('StockImports/List', [
            'imports' => $imports,

            'filters' => $filters,

            'categories' => Category::query()
                ->orderBy('name')
                ->get(),

            'suppliers' => Supplier::query()
                ->where('is_active', true)
                ->orderBy('name')
                ->get(),
        ]);
    }

    /**
     * Gắn thêm thông tin "khớp ở đâu" (sản phẩm, SKU, IMEI, Serial) cho từng phiếu
     * trong trang hiện tại để giao diện tô vàng đúng phần người dùng đang tìm.
     */
    private function attachSearchMatches($imports, string $search): void
    {
        $ids = $imports->getCollection()->pluck('id');
        if ($ids->isEmpty()) return;

        $like = '%' . $search . '%';

        $itemMatches = \App\Models\StockImportItem::query()
            ->with('product:id,name,sku')
            ->whereIn('stock_import_id', $ids)
            ->whereHas('product', fn ($product) => $product
                ->where('name', 'like', $like)
                ->orWhere('sku', 'like', $like))
            ->get()
            ->groupBy('stock_import_id');

        $imeiMatches = ProductImeiHistory::query()
            ->with('productImei:id,imei,serial')
            ->where('reference_type', StockImport::class)
            ->where('type', 'import')
            ->whereIn('reference_id', $ids)
            ->whereHas('productImei', fn ($imei) => $imei
                ->where('imei', 'like', $like)
                ->orWhere('serial', 'like', $like))
            ->get()
            ->groupBy('reference_id');

        $imports->getCollection()->transform(function ($import) use ($itemMatches, $imeiMatches) {
            $matches = collect();

            foreach ($itemMatches[$import->id] ?? [] as $row) {
                if ($row->product?->name) $matches->push(['label' => 'Sản phẩm', 'text' => $row->product->name]);
                if ($row->product?->sku) $matches->push(['label' => 'SKU', 'text' => $row->product->sku]);
            }

            foreach ($imeiMatches[$import->id] ?? [] as $row) {
                if ($row->productImei?->imei) $matches->push(['label' => 'IMEI', 'text' => $row->productImei->imei]);
                if ($row->productImei?->serial) $matches->push(['label' => 'Serial', 'text' => $row->productImei->serial]);
            }

            $import->setAttribute(
                'search_matches',
                $matches->unique(fn ($m) => $m['label'] . ':' . $m['text'])->take(12)->values()->all()
            );

            return $import;
        });
    }

    /** Active products with stock normalized across standard, variant, and IMEI inventory. */
    public function replenishmentProducts(): JsonResponse
    {
        $alertsEnabled = filter_var(setting('inventory_alert_enabled', true), FILTER_VALIDATE_BOOLEAN);
        $defaultThreshold = max(0, (int) setting('inventory_alert_threshold', 5));
        $products = Product::query()
            ->where('is_active', true)
            ->select('id', 'category_id', 'name', 'sku', 'model', 'stock', 'alert_stock', 'cost_price', 'unit_id', 'product_type', 'manage_stock_by_serial')
            ->with('category:id,name')
            ->with('unit:id,name,short_name')
            ->with(['variants' => fn ($query) => $query
                ->where('is_active', true)
                ->select('id', 'product_id', 'sku', 'barcode', 'attributes', 'cost_price', 'sell_price', 'stock')])
            ->withCount(['imeis as in_stock_imeis_count' => fn ($query) =>
                $query->where('status', \App\Models\ProductImei::STATUS_IN_STOCK)])
            ->orderBy('stock')
            ->orderBy('name')
            ->get()
            ->map(function (Product $product) use ($alertsEnabled, $defaultThreshold) {
                $stock = $product->manage_stock_by_serial || $product->product_type === 'imei'
                    ? (int) $product->in_stock_imeis_count
                    : ($product->variants->isNotEmpty()
                        ? (float) $product->variants->sum('stock')
                        : (float) $product->stock);

                $productThreshold = (float) $product->alert_stock > 0
                    ? (float) $product->alert_stock
                    : $defaultThreshold;

                return [
                    'id' => $product->id,
                    'category_id' => $product->category_id,
                    'name' => $product->name,
                    'sku' => $product->sku,
                    'model' => $product->model,
                    'stock' => $stock,
                    'alert_stock' => $alertsEnabled ? $productThreshold : 0,
                    'cost_price' => (float) $product->cost_price,
                    'unit_name' => $product->unit?->short_name ?: ($product->unit?->name ?: 'Cái'),
                    'product_type' => $product->product_type,
                    'manage_stock_by_serial' => (bool) $product->manage_stock_by_serial,
                    'variants' => $product->variants->values(),
                ];
            });

        return response()->json([
            'products' => $products,
            'categories' => Category::query()
                ->where('is_active', true)
                ->orderBy('name')
                ->get(['id', 'name']),
            'alerts_enabled' => $alertsEnabled,
            'default_alert_threshold' => $defaultThreshold,
        ]);
    }

    /** Phiếu nhập còn nợ để phân bổ tiền trả nợ cũ ngay khi lập phiếu mới. */
    public function supplierOutstandingOrders(Supplier $supplier): JsonResponse
    {
        $orders = StockImport::query()
            ->where('supplier_id', $supplier->id)
            ->where('status', 'completed')
            ->whereColumn('grand_total', '>', 'paid_amount')
            ->orderBy('import_date')
            ->orderBy('id')
            ->get(['id', 'code', 'import_date', 'grand_total', 'paid_amount'])
            ->map(fn (StockImport $import) => [
                'id' => $import->id,
                'code' => $import->code,
                'date' => optional($import->import_date)->format('d/m/Y'),
                'remaining' => max(0, (float) $import->grand_total - (float) $import->paid_amount),
            ])
            ->filter(fn (array $import) => $import['remaining'] > 0)
            ->values();

        return response()->json(['orders' => $orders]);
    }

    /**
     * Lưu phiếu nhập hàng
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'party_type' => ['required', Rule::in(['supplier', 'customer'])],
            'supplier_id' => ['nullable', 'required_if:party_type,supplier', 'exists:suppliers,id'],
            'customer_id' => ['nullable', 'exists:customers,id'],
            'party_name' => ['nullable', 'required_if:party_type,customer', 'string', 'max:255'],
            'party_phone' => ['nullable', 'string', 'max:30'],
            'party_address' => ['nullable', 'string', 'max:2000'],
            'party_cccd' => ['nullable', 'string', 'max:30'],
            'paid_amount' => ['nullable', 'numeric', 'min:0'],
            'tendered_amount' => ['nullable', 'numeric', 'min:0'],
            'change_amount' => ['nullable', 'numeric', 'min:0'],
            'old_debt_paid' => ['nullable', 'numeric', 'min:0'],
            'old_debt_allocations' => ['nullable', 'array'],
            'old_debt_allocations.*.stock_import_id' => ['required', 'integer', 'distinct', 'exists:stock_imports,id'],
            'old_debt_allocations.*.amount' => ['required', 'numeric', 'gt:0'],
            'payment_reference' => ['nullable', 'string', 'max:80'],
            'payment_method' => ['nullable', Rule::in(['cash', 'bank', 'card'])],

            'import_date' => [
                'required',
                'date',
            ],

            'items' => [
                'required',
                'array',
                'min:1',
            ],

            'items.*.product_id' => [
                'required',
                'exists:products,id',
            ],

            'items.*.variant_id' => [
                'nullable',
                Rule::exists('product_variants', 'id')->where('is_active', true),
            ],

            'items.*.unit_id' => [
                'nullable',
                'exists:units,id',
            ],

            'items.*.unit_name' => [
                'nullable',
                'string',
                'max:50',
            ],

            'items.*.quantity' => [
                'required',
                'integer',
                'min:1',
            ],

            'items.*.cost_price' => [
                'required',
                'numeric',
                'min:0',
            ],

            'items.*.sell_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'items.*.has_vat' => [
                'nullable',
                'boolean',
            ],

            'items.*.is_used' => [
                'nullable',
                'boolean',
            ],

            'items.*.supplier_warranty_value' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'items.*.supplier_warranty_unit' => [
                'nullable',
                'string',
                Rule::in(['days', 'months']),
            ],

            'items.*.extra_info' => ['nullable', 'array'],
            'items.*.extra_info.is_used' => ['nullable', 'boolean'],
            'items.*.extra_info.account' => ['nullable', 'string', 'max:255'],
            'items.*.extra_info.password' => ['nullable', 'string', 'max:255'],

            'items.*.imeis' => [
                'nullable',
                'array',
            ],

            'items.*.imeis.*.imei' => [
                'nullable',
                'string',
                'max:100',
            ],

            // Giá và biến thể của từng IMEI. Thiếu các rule này thì validate()
            // loại bỏ chúng khỏi dữ liệu, khiến giá IMEI lưu thành 0 / không đổi
            // khi nhập mới hoặc sửa phiếu.
            'items.*.imeis.*.cost_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'items.*.imeis.*.sell_price' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'items.*.imeis.*.variant_id' => [
                'nullable',
                'integer',
            ],

            'items.*.imeis.*.extra_info' => [
                'nullable',
                'array',
            ],

            'items.*.imeis.*.extra_info.note' => [
                'nullable',
                'string',
                'max:2000',
            ],

            'items.*.imeis.*.extra_info.is_used' => ['nullable', 'boolean'],
            'items.*.imeis.*.extra_info.account' => ['nullable', 'string', 'max:255'],
            'items.*.imeis.*.extra_info.password' => ['nullable', 'string', 'max:255'],

            'items.*.imeis.*.info_image' => [
                'nullable',
                'image',
                'max:5120',
            ],

            'items.*.imeis.*.warranty_duration_value' => [
                'nullable',
                'integer',
                'min:0',
            ],

            'items.*.imeis.*.warranty_duration_unit' => [
                'nullable',
                'string',
                Rule::in(['days', 'months']),
            ],

            'discount' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'extra_fee' => [
                'nullable',
                'numeric',
                'min:0',
            ],

            'note' => [
                'nullable',
                'string',
            ],
        ]);

        if (($validated['party_type'] ?? 'supplier') === 'customer' && !empty($validated['customer_id'])) {
            $customer = Customer::query()->findOrFail($validated['customer_id']);
            $validated['party_name'] = $customer->full_name;
            $validated['party_phone'] = $customer->phone;
            $validated['party_address'] = $customer->address;
            $validated['party_cccd'] = $customer->cccd;
        } elseif (($validated['party_type'] ?? 'supplier') === 'supplier' && !empty($validated['supplier_id'])) {
            $supplier = Supplier::query()->findOrFail($validated['supplier_id']);
            $validated['party_name'] = $supplier->name;
            $validated['party_phone'] = $supplier->phone;
            $validated['party_address'] = $supplier->address;
            $validated['party_cccd'] = null;
        }

        $replacement = $request->attributes->get('replacement_stock_import');
        if ($replacement instanceof StockImport) {
            $this->service->replace($replacement, $validated);
        } else {
            $this->service->import($validated);
        }

        // Chỉ một thông báo (app.js hiển thị flash.success); FE không toast thêm nữa.
        $paid = (float) ($validated['paid_amount'] ?? 0) + (float) ($validated['old_debt_paid'] ?? 0);

        return back()->with(
            'success',
            $replacement instanceof StockImport
                ? 'Đã cập nhật phiếu nhập thành công.'
                : ($paid > 0
                    ? 'Đã lưu phiếu nhập và ghi nhận thanh toán thành công.'
                    : 'Đã lưu phiếu nhập, công nợ đã được ghi nhận.')
        );
    }

    public function searchCustomers(Request $request): JsonResponse
    {
        $search = trim((string) $request->query('search', ''));
        if (mb_strlen($search) < 2) {
            return response()->json(['customers' => []]);
        }
        $normalizedSearch = Customer::normalizeSearch($search);

        $customers = Customer::query()
            ->where(function ($query) use ($search, $normalizedSearch): void {
                $query->where('search_text', 'like', "%{$normalizedSearch}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('cccd', 'like', "%{$search}%")
                    ->orWhere('code', 'like', "%{$search}%");
            })
            ->orderBy('full_name')
            ->limit(10)
            ->get(['id', 'full_name', 'phone', 'address', 'debt_balance']);

        return response()->json(['customers' => $customers]);
    }

    public function contract(StockImport $stockImport)
    {
        $stockImport->load([
            'supplier:id,name,phone,email,address,tax_code',
            'customer:id,code,full_name,phone,cccd,address',
            'user:id,name',
            'items.product:id,name,sku,model,unit_id,conversion_unit_id',
            'items.product.unit:id,name,short_name',
            'items.product.conversionUnit:id,name,short_name',
            'items.variant:id,product_id,sku,attributes',
            'items.unit:id,name,short_name',
        ]);

        $sellerName = $stockImport->party_name ?: ($stockImport->customer?->full_name ?: ($stockImport->supplier?->name ?: '—'));
        $content = (string) setting('purchase_contract_content', DefaultPurchaseContract::CONTENT);
        $contractContent = strtr($content, [
            '{{date}}' => now()->format('d/m/Y'),
            '{{delivery_date}}' => optional($stockImport->import_date)->format('d/m/Y') ?: '—',
            '{{import_code}}' => $stockImport->code,
            '{{buyer_name}}' => (string) setting('shop_name', config('app.name', 'Cửa hàng')),
            '{{seller_name}}' => $sellerName,
            '{{total}}' => number_format((float) $stockImport->grand_total, 0, ',', '.') . ' đ',
            '{{note}}' => (string) $stockImport->note,
        ]);

        return view('stock-imports.contract', [
            'import' => $stockImport,
            'contractTitle' => setting('purchase_contract_title', DefaultPurchaseContract::TITLE),
            'contractContent' => $contractContent,
            'buyerName' => setting('shop_name', config('app.name', 'Cửa hàng')),
        ]);
    }

    /**
     * Xem chi tiết phiếu nhập
     */
    public function show(
        Request $request,
        StockImport $stockImport
    ): JsonResponse|RedirectResponse {
        $stockImport->load([
            'supplier:id,name,phone,email,address',
            'customer:id,code,full_name,phone,cccd,address',
            'user:id,name',
            'items.product:id,name,sku,model,image,unit_id,conversion_unit_id,sell_price,has_unit_conversion,conversion_factor,manage_stock_by_serial',
            'items.product.unit:id,name,short_name',
            'items.product.conversionUnit:id,name,short_name',
            'items.product.variants:id,product_id,sku,barcode,attributes,cost_price,sell_price,stock,is_active',
            'items.variant:id,product_id,sku,attributes,cost_price,sell_price,stock',
            'items.unit:id,name,short_name',
            'items.stockBatch:id,stock_import_item_id,variant_id,cost_price,sell_price',
        ]);

        $imeiHistories = ProductImeiHistory::query()
            ->with([
                'productImei:id,product_id,variant_id,imei,serial,extra_info,warranty_expired_at,status,cost_price,sell_price',
                'productImei.product:id,name,sku',
                'productImei.variant:id,product_id,sku,attributes',
            ])
            ->where('reference_type', StockImport::class)
            ->where('reference_id', $stockImport->id)
            ->where('type', 'import')
            ->latest('id')
            ->get();

        // Phiếu cũ chưa lưu stock_import_item_id trong meta. Không được gắn cả
        // nhóm IMEI đó vào từng dòng giống nhau, nếu không form sửa sẽ nhân đôi
        // IMEI (2 IMEI thành 4). Phân bổ theo số lượng từng dòng của phiếu cũ.
        $legacyAssignments = [];
        $stockImport->items
            ->groupBy(fn ($item) => $item->product_id . ':' . ($item->variant_id ?? 'none'))
            ->each(function ($items, string $key) use ($imeiHistories, &$legacyAssignments): void {
                [$productId, $variantId] = explode(':', $key, 2);
                $legacyHistories = $imeiHistories
                    ->filter(fn (ProductImeiHistory $history): bool =>
                        empty($history->meta['stock_import_item_id'])
                        && (int) ($history->meta['product_id'] ?? 0) === (int) $productId
                        && (int) ($history->meta['variant_id'] ?? 0) === ($variantId === 'none' ? 0 : (int) $variantId)
                    )
                    ->values();

                $offset = 0;
                foreach ($items as $item) {
                    $quantity = max(0, (int) $item->quantity);
                    $legacyAssignments[$item->id] = $legacyHistories->slice($offset, $quantity)->values();
                    $offset += $quantity;
                }
            });

        $stockImport->items->each(function ($item) use ($imeiHistories, $legacyAssignments): void {
            $linkedHistories = $imeiHistories
                ->filter(fn (ProductImeiHistory $history): bool =>
                    (int) ($history->meta['stock_import_item_id'] ?? 0) === (int) $item->id
                )
                ->values();

            $item->setRelation('import_imeis', $linkedHistories->isNotEmpty()
                ? $linkedHistories
                : ($legacyAssignments[$item->id] ?? collect()));
        });

        if ($request->wantsJson()) {
            return response()->json($stockImport);
        }

        return redirect()->route('stock.index', ['open_import' => $stockImport->id]);
    }

    public function cancel(Request $request, StockImport $stockImport): RedirectResponse
    {
        $data = $request->validate([
            'reason' => ['required', 'string', 'max:1000'],
        ]);

        $this->service->cancel($stockImport, $data['reason']);

        return back()->with('success', 'Đã hủy phiếu nhập và hoàn tác tồn kho, công nợ.');
    }

    public function update(Request $request, StockImport $stockImport): RedirectResponse
    {
        if ($stockImport->status === 'cancelled') {
            return back()->withErrors(['import' => 'Phiếu nhập đã hủy không thể sửa.']);
        }

        $request->attributes->set('replacement_stock_import', $stockImport);
        return $this->store($request);
    }
}
