<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductImei;
use App\Models\StockImportItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $keyword = $request->string('keyword')->toString();

        if (str_starts_with(strtolower($keyword), 'imei/')) {
            $imeiKeyword = substr($keyword, 5);

            $productIds = ProductImei::query()
                ->where('status', ProductImei::STATUS_IN_STOCK)
                ->where('imei', 'like', "%{$imeiKeyword}%")
                ->pluck('product_id');

            $products = Product::query()
                ->with([
                    'unit:id,name,short_name',
                    'conversionUnit:id,name,short_name',
                    'variants' => fn ($query) => $query
                        ->where('is_active', true)
                        ->select('id', 'product_id', 'sku', 'barcode', 'attributes', 'cost_price', 'sell_price', 'stock', 'is_active'),
                    'stockBatches' => fn ($query) => $query
                        ->where('remaining_quantity', '>', 0)
                        ->select('id', 'product_id', 'variant_id', 'remaining_quantity', 'cost_price', 'sell_price', 'imported_at'),
                    'imeis' => fn ($query) => $this->availableImeiScope($query)
                        ->with('variant:id,product_id,sku,barcode,attributes,cost_price,sell_price,stock')
                        ->select([
                            'id',
                            'product_id',
                            'variant_id',
                            'cost_price',
                            'sell_price',
                        ]),
                ])
                ->withCount([
                    'imeis as available_imei_count' => fn ($query) =>
                        $this->availableImeiScope($query),
                ])
                ->whereIn('id', $productIds)
                ->where('is_active', true)
                ->get();
            $vatProductIds = StockImportItem::query()->whereIn('product_id', $products->pluck('id'))->where('has_vat', true)->distinct()->pluck('product_id')->map(fn ($id) => (int) $id)->all();
            $products = $products->map(function ($product) use ($vatProductIds) {
                    $prices = $this->availableSellPrices($product);
                    $costPrices = $this->availableCostPrices($product);
                    $nextBatch = $product->stockBatches->whereNull('variant_id')->sortBy([['imported_at', 'asc'], ['id', 'asc']])->first();

                    return [
                        'id' => $product->id,
                        'name' => $product->name,
                        'sku' => $product->sku,
                        'model' => $product->model,
                        'cost_price' => $nextBatch?->cost_price ?? $product->cost_price,
                        'price' => $nextBatch?->sell_price ?: $product->sell_price,
                        'sell_price' => $nextBatch?->sell_price ?: $product->sell_price,
                        'warranty_days' => (int) $product->warranty_days,
                        'has_vat' => in_array((int) $product->id, $vatProductIds, true),
                        'tax_percent' => (float) ($product->tax_percent ?? 0),
                        'price_min' => $prices['min'],
                        'price_max' => $prices['max'],
                        'price_label' => $prices['label'],
                        'cost_price_min' => $costPrices['min'],
                        'cost_price_max' => $costPrices['max'],
                        'stock' => $product->manage_stock_by_serial || $product->product_type === 'imei'
                            ? $product->available_imei_count
                            : $product->stock,
                        'manage_stock_by_serial' => $product->manage_stock_by_serial,
                        'category_id' => $product->category_id,
                        'unit_id' => $product->unit_id,
                        'unit_name' => $product->unit?->short_name ?: $product->unit?->name,
                        'has_unit_conversion' => $product->has_unit_conversion,
                        'conversion_factor' => 1,
                        'inventory_unit_id' => $product->unit_id,
                        'inventory_unit_name' => $product->unit?->short_name ?: $product->unit?->name,
                        'import_unit_id' => $product->conversionUnit?->id,
                        'import_unit_name' => $product->conversionUnit?->short_name ?: $product->conversionUnit?->name,
                        'import_conversion_factor' => $product->inventoryConversionFactor(),
                        'product_type' => $product->product_type,
                        'sold_count' => $product->sold_count ?? 0,
                        'image_url' => $product->image_url,
                        'stock_batches' => $product->stockBatches
                            ->sortBy([['imported_at', 'asc'], ['id', 'asc']])
                            ->map(fn ($batch) => [
                                'id' => $batch->id,
                                'variant_id' => $batch->variant_id,
                                'remaining_quantity' => (int) $batch->remaining_quantity,
                                'cost_price' => (float) $batch->cost_price,
                                'sell_price' => (float) $batch->sell_price,
                            ])->values(),
                    ];
                });

            return response()->json($products);
        }

        $categoryId = $request->input('category_id');

        $products = Product::query()
            ->with([
                'unit:id,name,short_name',
                'conversionUnit:id,name,short_name',
                    'variants' => fn ($query) => $query
                        ->where('is_active', true)
                        ->select('id', 'product_id', 'sku', 'barcode', 'attributes', 'cost_price', 'sell_price', 'stock', 'is_active'),
                'stockBatches' => fn ($query) => $query
                    ->where('remaining_quantity', '>', 0)
                    ->select('id', 'product_id', 'variant_id', 'remaining_quantity', 'cost_price', 'sell_price', 'imported_at'),
                'imeis' => fn ($query) => $this->availableImeiScope($query)
                    ->with('variant:id,product_id,sku,barcode,attributes,cost_price,sell_price,stock')
                    ->select([
                        'id',
                        'product_id',
                        'variant_id',
                        'cost_price',
                        'sell_price',
                    ]),
            ])
            ->withCount([
                'imeis as available_imei_count' => fn ($query) =>
                    $this->availableImeiScope($query),
            ])
            ->where('is_active', true)
            ->when($keyword, function ($query) use ($keyword) {
                $normalizedKeyword = Product::normalizeSearch($keyword);

                $query->where(function ($sub) use ($keyword, $normalizedKeyword) {
                    $sub->where('model', $keyword)
                        ->orWhere('sku', 'like', $keyword . '%')
                        ->orWhere('search_text', 'like', '%' . $normalizedKeyword . '%')
                        ->orWhereHas('variants', function ($variantQuery) use ($keyword) {
                            $variantQuery->where('barcode', $keyword)
                                ->orWhere('sku', 'like', $keyword . '%');
                        })
                        ->orWhereHas('imeis', function ($q) use ($keyword) {
                            $q->where('imei', 'like', "%{$keyword}%");
                        });
                });
            })
            ->when($categoryId, function ($query) use ($categoryId) {
                $query->where('category_id', $categoryId);
            })
            ->orderByRaw(
                "
                CASE
                    WHEN model = ? THEN 1
                    WHEN sku = ? THEN 2
                    WHEN sku LIKE ? THEN 3
                    ELSE 4
                END
                ",
                [
                    $keyword,
                    $keyword,
                    $keyword . '%',
                ]
            )
            ->orderByDesc('sold_count')
            ->orderByDesc('id')
            ->limit(100)
            ->get();
        $vatProductIds = StockImportItem::query()->whereIn('product_id', $products->pluck('id'))->where('has_vat', true)->distinct()->pluck('product_id')->map(fn ($id) => (int) $id)->all();
        $products = $products->map(function ($product) use ($vatProductIds) {
                $prices = $this->availableSellPrices($product);
                $costPrices = $this->availableCostPrices($product);
                $nextBatch = $product->stockBatches->whereNull('variant_id')->sortBy([['imported_at', 'asc'], ['id', 'asc']])->first();

                return [
                    'id' => $product->id,
                    'name' => $product->name,
                    'sku' => $product->sku,
                    'model' => $product->model,
                    'cost_price' => $nextBatch?->cost_price ?? $product->cost_price,
                    'price' => $nextBatch?->sell_price ?: $product->sell_price,
                    'sell_price' => $nextBatch?->sell_price ?: $product->sell_price,
                    'warranty_days' => (int) $product->warranty_days,
                    'has_vat' => in_array((int) $product->id, $vatProductIds, true),
                    'tax_percent' => (float) ($product->tax_percent ?? 0),
                    'price_min' => $prices['min'],
                    'price_max' => $prices['max'],
                    'price_label' => $prices['label'],
                    'cost_price_min' => $costPrices['min'],
                    'cost_price_max' => $costPrices['max'],
                    'stock' => $product->manage_stock_by_serial || $product->product_type === 'imei'
                        ? (int) $product->available_imei_count
                        : ($product->variants->isNotEmpty()
                            ? (float) $product->variants->sum('stock')
                            : (float) $product->stock),
                    'manage_stock_by_serial' => $product->manage_stock_by_serial,
                    'category_id' => $product->category_id,
                    'unit_id' => $product->unit_id,
                    'unit_name' => $product->unit?->short_name ?: $product->unit?->name,
                    'has_unit_conversion' => $product->has_unit_conversion,
                    'conversion_factor' => 1,
                    'inventory_unit_id' => $product->unit_id,
                    'inventory_unit_name' => $product->unit?->short_name ?: $product->unit?->name,
                    'import_unit_id' => $product->conversionUnit?->id,
                    'import_unit_name' => $product->conversionUnit?->short_name ?: $product->conversionUnit?->name,
                    'import_conversion_factor' => $product->inventoryConversionFactor(),
                    'product_type' => $product->product_type,
                    'sold_count' => $product->sold_count ?? 0,
                    'image_url' => $product->image_url,
                    'stock_batches' => $product->stockBatches
                        ->sortBy([['imported_at', 'asc'], ['id', 'asc']])
                        ->map(fn ($batch) => [
                            'id' => $batch->id,
                            'variant_id' => $batch->variant_id,
                            'remaining_quantity' => (int) $batch->remaining_quantity,
                            'cost_price' => (float) $batch->cost_price,
                            'sell_price' => (float) $batch->sell_price,
                        ])->values(),
                    'variants' => $product->variants
                        ->map(function ($variant) use ($product) {
                            $batch = $product->stockBatches
                                ->where('variant_id', $variant->id)
                                ->sortBy([['imported_at', 'asc'], ['id', 'asc']])
                                ->first();
                            return [
                                'id' => $variant->id,
                                'sku' => $variant->sku,
                                'barcode' => $variant->barcode,
                                'attributes' => $variant->attributes,
                                'cost_price' => $batch?->cost_price ?? $variant->cost_price,
                                'sell_price' => $batch?->sell_price ?: $variant->sell_price,
                                'price' => $batch?->sell_price ?: $variant->sell_price,
                                'stock' => $variant->stock,
                            ];
                        })
                        ->values(),
                ];
            });

        return response()->json($products);
    }

    private function availableSellPrices(Product $product): array
    {
        $prices = collect();

        if ($product->product_type === 'imei' || $product->manage_stock_by_serial) {
            $prices = $product->imeis
                ->map(function (ProductImei $imei) use ($product): float {
                    if ($imei->sell_price > 0) {
                        return (float) $imei->sell_price;
                    }

                    if ($imei->variant?->sell_price > 0) {
                        return (float) $imei->variant->sell_price;
                    }

                    return (float) $product->sell_price;
                })
                ->filter(fn (float $price): bool => $price > 0);
        } elseif ($product->stockBatches->isNotEmpty()) {
            $prices = $product->stockBatches
                ->map(fn ($batch): float => (float) $batch->sell_price)
                ->filter(fn (float $price): bool => $price > 0);
        } elseif ($product->relationLoaded('variants') && $product->variants->isNotEmpty()) {
            $prices = $product->variants
                ->filter(fn ($variant): bool => (int) ($variant->stock ?? 0) > 0)
                ->map(fn ($variant): float => (float) ($variant->sell_price ?: $product->sell_price))
                ->filter(fn (float $price): bool => $price > 0);
        }

        if ($prices->isEmpty() && $product->sell_price > 0) {
            $prices = collect([(float) $product->sell_price]);
        }

        $min = (float) ($prices->min() ?? 0);
        $max = (float) ($prices->max() ?? 0);

        return [
            'min' => $min,
            'max' => $max,
            'label' => $min > 0 && $max > 0 && $min !== $max
                ? number_format($min, 0, ',', '.') . ' - ' . number_format($max, 0, ',', '.')
                : number_format($min ?: $max, 0, ',', '.'),
        ];
    }

    private function availableCostPrices(Product $product): array
    {
        if ($product->product_type === 'imei' || $product->manage_stock_by_serial) {
            $prices = $product->imeis
                ->map(function (ProductImei $imei) use ($product): float {
                    if ($imei->cost_price > 0) {
                        return (float) $imei->cost_price;
                    }

                    if ($imei->variant?->cost_price > 0) {
                        return (float) $imei->variant->cost_price;
                    }

                    return (float) $product->cost_price;
                });
        } elseif ($product->stockBatches->isNotEmpty()) {
            $prices = $product->stockBatches
                ->map(fn ($batch): float => (float) $batch->cost_price);
        } elseif ($product->relationLoaded('variants') && $product->variants->isNotEmpty()) {
            $prices = $product->variants
                ->filter(fn ($variant): bool => (int) ($variant->stock ?? 0) > 0)
                ->map(fn ($variant): float => (float) ($variant->cost_price ?: $product->cost_price));
        } else {
            $prices = collect([(float) $product->cost_price]);
        }

        $prices = $prices->filter(fn (float $price): bool => $price > 0);

        return [
            'min' => (float) ($prices->min() ?? 0),
            'max' => (float) ($prices->max() ?? 0),
        ];
    }

    public function getProductApi($id)
    {
        $product = \App\Models\Product::with([
            'unit:id,name,short_name',
            'conversionUnit:id,name,short_name',
            'variants' => fn ($query) => $query->where('is_active', true),
        ])->find($id);

        if (!$product) {
            return response()->json([
                'message' => 'Không tìm thấy sản phẩm'
            ], 404);
        }

        return response()->json($product);
    }

    /**
     * Danh sách IMEI còn trong kho của 1 sản phẩm (dùng cho màn hình POS
     * khi người dùng bấm chọn sản phẩm quản lý theo IMEI).
     * Có thể lọc theo biến thể qua query `variant_id`.
     */
    public function imeis(Request $request, $id): JsonResponse
    {
        $product = Product::find($id);

        if (!$product) {
            return response()->json([
                'message' => 'Không tìm thấy sản phẩm'
            ], 404);
        }

        $imeis = $this->availableImeiScope($product->imeis())
            ->with('variant:id,product_id,sku,barcode,attributes,cost_price,sell_price,stock')
            ->when(
                $request->filled('variant_id'),
                fn ($query) => $query->where('variant_id', $request->input('variant_id'))
            )
            ->orderBy('imei')
            ->get([
                'id',
                'variant_id',
                'imei',
                'serial',
                'color',
                'storage',
                'extra_info',
                'cost_price',
                'sell_price',
            ])
            ->map(function (ProductImei $imei) use ($product): array {
                $effectiveSellPrice =
                    $imei->sell_price > 0
                        ? (float) $imei->sell_price
                        : ($imei->variant?->sell_price > 0
                            ? (float) $imei->variant->sell_price
                            : (float) $product->sell_price);

                $priceSource =
                    $imei->sell_price > 0
                        ? 'imei'
                        : ($imei->variant?->sell_price > 0 ? 'variant' : 'product');

                return [
                    'id' => $imei->id,
                    'variant_id' => $imei->variant_id,
                    'imei' => $imei->imei,
                    'serial' => $imei->serial,
                    'display_code' => $imei->imei ?: $imei->serial ?: 'IMEI #' . $imei->id,
                    'color' => $imei->color,
                    'storage' => $imei->storage,
                    'extra_info' => $imei->extra_info,
                    'cost_price' => $imei->cost_price,
                    'sell_price' => $imei->sell_price,
                    'effective_sell_price' => $effectiveSellPrice,
                    'price' => $effectiveSellPrice,
                    'price_source' => $priceSource,
                    'variant' => $imei->variant
                        ? [
                            'id' => $imei->variant->id,
                            'sku' => $imei->variant->sku,
                            'barcode' => $imei->variant->barcode,
                            'attributes' => $imei->variant->attributes,
                            'cost_price' => $imei->variant->cost_price,
                            'sell_price' => $imei->variant->sell_price,
                            'price' => $imei->variant->sell_price,
                            'stock' => $imei->variant->stock,
                        ]
                        : null,
                ];
            })
            ->values();

        return response()->json($imeis);
    }

    /*
    |--------------------------------------------------------------------------
    | Điều kiện IMEI "khả dụng để bán"
    |--------------------------------------------------------------------------
    |
    | Dùng chung cho: đếm tồn kho (available_imei_count), danh sách IMEI
    | nạp kèm sản phẩm khi tìm kiếm, và modal chọn IMEI khi thêm vào giỏ.
    | Trước đây available_imei_count chỉ lọc status = in_stock nên đếm
    | luôn cả IMEI thuộc biến thể đã bị vô hiệu (is_active = false), dẫn
    | tới số "Tồn" hiển thị ở danh sách sản phẩm CAO HƠN số IMEI thực sự
    | chọn được trong modal (chỉ lọc biến thể còn active). Gộp về đây để
    | 2 nơi luôn tính cùng một cách, không bị lệch số.
    |
    */
    private function availableImeiScope($query)
    {
        return $query
            ->where('status', ProductImei::STATUS_IN_STOCK)
            ->where(function ($q) {
                $q->whereNull('variant_id')
                    ->orWhereHas('variant', fn ($variantQuery) =>
                        $variantQuery->where('is_active', true)
                    );
            });
    }
}
