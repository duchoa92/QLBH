<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Models\ProductImei;
use App\Models\StockImportItem;

class ProductApiController extends Controller
{
    public function findByBarcode(
        Request $request
    ): JsonResponse {

        $barcode = (string) $request->get(
            'barcode'
        );

        $product = Product::query()

            ->with([
                'imeis',
                'unit:id,name,short_name',
                'conversionUnit:id,name,short_name',
            ])

            ->where(
                'model',
                $barcode
            )

            ->orWhere(
                'sku',
                $barcode
            )

            ->first();

        $imei = null;

        if (! $product) {

            $imei = ProductImei::query()

                ->where(
                    'imei',
                    $barcode
                )

                ->first();

                
            if ($imei) {

                if (
                    $imei->status !==
                    ProductImei::STATUS_IN_STOCK
                ) {

                    return response()->json([
                        'message' => 'IMEI không khả dụng hoặc đã bán',
                    ], 422);
                }

                $product = Product::find(
                    $imei->product_id
                );
            }
        }

        
        if (! $product) {

            return response()->json([
                'message' => 'Không tìm thấy sản phẩm, hoặc sản phẩm đã được bán!',
            ], 404);
        }

        return response()->json([

            'id' => $product->id,

            'name' => $product->name,

            'warranty_days' => (int) $product->warranty_days,

            'has_vat' => StockImportItem::query()->where('product_id', $product->id)->where('has_vat', true)->where('is_used', false)->exists(),

            'tax_percent' => (float) ($product->tax_percent ?? 0),

            'sku' => $product->sku,

            'model' => $product->model,

            'sell_price' => $imei && $imei->sell_price > 0
                ? $imei->sell_price
                : $product->sell_price,

            'stock' => $product->stock,

            'unit_id' => $product->unit_id,

            'unit_name' => $product->unit?->short_name ?: $product->unit?->name,

            'conversion_factor' => 1,

            'inventory_unit_name' => $product->unit?->short_name ?: $product->unit?->name,

            'imei_id' =>
                $imei?->id,

            'imei' =>
                $imei?->imei,

            'serial' =>
                $imei?->serial,

            'color' =>
                $imei?->color,

            'storage' =>
                $imei?->storage,
        ]);
    }
}
