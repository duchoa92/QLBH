<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SaleItem extends Model
{
    protected $fillable = [

        'sale_id',

        'product_id',

        'variant_id',

        'product_imei_id',

        'unit_id',

        'unit_name',

        'quantity',

        'base_quantity',

        'conversion_factor',

        'unit_price',

        'unit_cost',

        'subtotal',
        'has_vat',
        'vat_applied',
        
        'note',

        'discount_type',

        'discount_value',

        'warranty_days',

        'warranty_value',

        'warranty_unit',

        'warranty_note',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'base_quantity' => 'integer',
        'conversion_factor' => 'integer',
        'unit_price' => 'decimal:2',
        'unit_cost' => 'decimal:2',
        'subtotal' => 'decimal:2',
        'has_vat' => 'boolean',
        'vat_applied' => 'boolean',
        'discount_value' => 'decimal:2',
        'warranty_days' => 'integer',
        'warranty_value' => 'integer',
    ];

    /*
    |--------------------------------------------------------------------------
    | Relations
    |--------------------------------------------------------------------------
    */

    public function sale(): BelongsTo
    {
        return $this->belongsTo(
            Sale::class
        );
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(
            Product::class
        );
    }

    public function variant(): BelongsTo
    {
        return $this->belongsTo(
            ProductVariant::class,
            'variant_id'
        );
    }

    public function productImei(): BelongsTo
    {
        return $this->belongsTo(
            ProductImei::class,
            'product_imei_id'
        );
    }


    public function gifts(): HasMany
    {
        return $this->hasMany(
            SaleItemGift::class
        );
    }

    public function stockBatchAllocations(): HasMany
    {
        return $this->hasMany(SaleItemStockBatch::class);
    }
    
}
