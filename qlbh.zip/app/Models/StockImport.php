<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StockImport extends Model
{
    use HasFactory;

    protected $table = 'stock_imports';

    /**
     * Các thuộc tính có thể gán hàng loạt (Mass Assignment).
     */
    protected $fillable = [
        'code',
        'supplier_id',
        'party_type',
        'customer_id',
        'party_name',
        'party_phone',
        'party_cccd',
        'party_address',
        'user_id',
        'import_date',
        'discount',
        'extra_fee',
        'total_amount',
        'grand_total',
        'paid_amount',
        'tendered_amount',
        'change_amount',
        'old_debt_paid',
        'old_debt_allocations',
        'payment_method',
        'payment_reference',
        'note',
        'status',
    ];

    /**
     * Tự động ép kiểu dữ liệu khi lấy ra/lưu vào DB.
     */
    protected $casts = [
        'import_date'  => 'datetime',
        'discount'     => 'decimal:2',
        'extra_fee'    => 'decimal:2',
        'total_amount' => 'decimal:2',
        'grand_total'  => 'decimal:2',
        'paid_amount'  => 'decimal:2',
        'tendered_amount' => 'decimal:2',
        'change_amount' => 'decimal:2',
        'old_debt_paid' => 'decimal:2',
        'old_debt_allocations' => 'array',
    ];

    /*
    |--------------------------------------------------------------------------
    | QUAN HỆ ELOQUENT (RELATIONSHIPS)
    |--------------------------------------------------------------------------
    */

    /**
     * Đơn nhập hàng thuộc về một Nhà cung cấp.
     */
    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class, 'supplier_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    /**
     * Đơn nhập hàng do một Nhân viên/User tạo.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Một đơn nhập hàng có nhiều Chi tiết sản phẩm nhập kho.
     */
    public function items(): HasMany
    {
        return $this->hasMany(StockImportItem::class, 'stock_import_id');
    }
}
