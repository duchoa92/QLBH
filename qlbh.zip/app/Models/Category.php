<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\PreventDeleteIfHasRelations;
use App\Models\CategoryAttribute;

class Category extends Model
{
    use SoftDeletes, PreventDeleteIfHasRelations;

    protected $fillable = [
        'parent_id',
        'name',
        'slug',
        'sort_order',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    // Quan hệ
    public function parent()   { return $this->belongsTo(Category::class, 'parent_id'); }
    public function children() { return $this->hasMany(Category::class, 'parent_id'); }
    public function products() { return $this->hasMany(Product::class); }
    public function brands()   { return $this->belongsToMany(Brand::class, 'brand_category'); }
    public function categoryAttributes()
    {
        return $this->hasMany(CategoryAttribute::class, 'category_id');
    }
}
