<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class StockImportItem extends Model
{
    protected $fillable = [
        'stock_import_id',
        'product_id',
        'variant_id',
        'unit_id',
        'unit_name',
        'quantity',
        'base_quantity',
        'conversion_factor',
        'cost_price',
        'has_vat',
        'supplier_warranty_value',
        'supplier_warranty_unit',
        'extra_info',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'base_quantity' => 'integer',
        'conversion_factor' => 'integer',
        'cost_price' => 'decimal:2',
        'has_vat' => 'boolean',
        'supplier_warranty_value' => 'integer',
        'extra_info' => 'array',
    ];

    public function stockImport(): BelongsTo
    {
        return $this->belongsTo(
            StockImport::class,
            'stock_import_id'
        );
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(
            Product::class,
            'product_id'
        );
    }

    public function variant(): BelongsTo
    {
        return $this->belongsTo(
            ProductVariant::class,
            'variant_id'
        );
    }

    public function unit(): BelongsTo
    {
        return $this->belongsTo(
            Unit::class,
            'unit_id'
        );
    }

    /**
     * Lô tồn kho tạo từ dòng nhập này. Giá bán nhập tay được lưu ở lô (theo đơn
     * vị cơ sở), không ghi đè giá bán hiện tại của sản phẩm/biến thể.
     */
    public function stockBatch(): HasOne
    {
        return $this->hasOne(
            ProductStockBatch::class,
            'stock_import_item_id'
        );
    }
}
