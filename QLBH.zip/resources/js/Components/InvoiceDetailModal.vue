<!-- resources/js/Components/InvoiceDetailModal.vue -->
<script setup>
import { isDebtSale, effectivePaymentMethod } from '@/utils/salePayment'
import { formatCurrency, formatDateTime, formatDate as formatConfiguredDate, formatDatePlusDays, formatNumber } from '@/utils/format'
import { computed, ref } from 'vue'
import { allocateSaleVat } from '@/utils/lineVat'
import {
    CheckCircle2,
    Gift,
    Printer,
    SquarePen,
    Undo2,
    XCircle,
    X,
    FileText,
    User,
    UserCheck,
    CreditCard,
    Hash,
    AlertTriangle,
    Tag,
    MessageSquare
} from 'lucide-vue-next'

const props = defineProps({
    show: {
        type: Boolean,
        default: false,
    },
    invoice: {
        type: Object,
        default: null,
    },
    canCancel: {
        type: Boolean,
        default: false,
    },
    canPrint: {
        type: Boolean,
        default: false,
    },
    canEdit: {
        type: Boolean,
        default: false,
    },
    layerClass: {
        type: String,
        default: 'z-50',
    },
})

const emit = defineEmits(['close', 'cancel', 'print', 'edit'])

const cancelledItems = computed(() => props.invoice?.cancelled_items || [])
const openWarrantyNoteId = ref(null)

const toggleWarrantyNote = (item) => {
    openWarrantyNoteId.value = openWarrantyNoteId.value === item.id ? null : item.id
}

const warrantyEndDate = (item) => {
    const days = Number(item.warranty_days ?? item.product_imei?.customer_warranty_days ?? 0)
    const calculatedExpiry = formatDatePlusDays(props.invoice?.created_at, days)
    if (calculatedExpiry) return calculatedExpiry

    const expiresAt = item.product_imei?.customer_warranty_expires_at
    return expiresAt ? formatConfiguredDate(expiresAt) : ''
}

const paymentMethodLabel = (method) => ({
    debt: 'Nợ',
    cash: 'Tiền mặt',
    bank: 'Chuyển khoản',
    mixed: 'Tiền mặt + Chuyển khoản',
    card: 'Thẻ',
}[String(method || '').toLowerCase()] || method || 'Tiền mặt')

const customerPaymentLabel = (method) => ({
    cash: 'Khách đưa',
    bank: 'Khách chuyển',
    mixed: 'Khách đưa / khách chuyển',
    card: 'Khách thanh toán thẻ',
}[String(method || '').toLowerCase()] || 'Khách đưa')

const customerPaymentRows = computed(() => {
    const invoice = props.invoice || {}
    // Đơn nợ hoàn toàn: chưa có khoản tiền nào của khách cho đơn này.
    if (isDebtSale(invoice)) return []
    const cash = Math.max(0, Number(invoice.cash_received_amount || 0))
    const bank = Math.max(0, Number(invoice.bank_received_amount || 0))
    if (cash > 0 || bank > 0) {
        return [
            ...(cash > 0 ? [{ label: 'Khách đưa', amount: cash }] : []),
            ...(bank > 0 ? [{ label: 'Khách chuyển', amount: bank }] : []),
        ]
    }

    return [{ label: customerPaymentLabel(invoice.payment_method), amount: Math.max(0, Number(invoice.paid_amount || 0)) }]
})

const customerPaymentAmount = computed(() => customerPaymentRows.value.reduce((total, row) => total + row.amount, 0))

// Format tiền tệ
const money = formatCurrency

// Cột VAT: chỉ hiện khi hóa đơn có dòng được tính VAT; số tiền chia theo thành tiền từng dòng.
const lineVats = computed(() => allocateSaleVat(props.invoice?.items, props.invoice?.tax))
const showVatColumn = computed(() => (props.invoice?.items || []).some(item => item.vat_applied))

// Format ngày tháng
const formatDate = (date) => {
    if (!date) return '-'
    return formatDateTime(date)
}

// Lấy thuộc tính biến thể
const attributeText = (attribute) => {
    if (attribute === null || attribute === undefined || attribute === '') return ''
    if (typeof attribute !== 'object') return String(attribute)

    return attribute.value
        || attribute.label
        || attribute.name
        || attribute.title
        || attribute.text
        || ''
}

const variantLabel = (variant) => {
    const attributes = Object.values(variant?.attributes || {})
        .map(attributeText)
        .filter(Boolean)

    return attributes.join(' / ') || variant?.name || variant?.sku || ''
}

// Đơn vị & Số lượng bán
const saleQuantityText = (item) => {
    const qty = Number(item.quantity ?? 0)
    const unit = item.unit_name || 'Chiếc'

    return `${Number.isInteger(qty) ? qty : formatNumber(qty)} ${unit}`
}

// Quy đổi đơn vị gốc
const baseQuantityText = (item) => {
    if (Number(item.conversion_factor || 1) <= 1) return ''

    const unit = item.product?.unit?.short_name
        || item.product?.unit?.name
        || 'đơn vị gốc'

    return ` = ${item.base_quantity} ${unit}`
}

// Tổng tiền hóa đơn
const saleTotal = computed(() =>
    props.invoice?.grand_total
    ?? props.invoice?.total_amount
    ?? props.invoice?.subtotal
    ?? 0
)

// Tên khách hàng
const customerName = computed(() =>
    props.invoice?.customer?.full_name
    || props.invoice?.customer?.name
    || 'Khách lẻ'
)

const isCancelled = computed(() => props.invoice?.status === 'cancelled')

// Trạng thái thanh toán / Hủy
const paymentStatusMeta = computed(() => {
    if (isCancelled.value) {
        return {
            label: 'Đã hủy',
            icon: XCircle,
            class: 'border-rose-200 bg-rose-50 text-rose-700',
        }
    }

    return {
        label: 'Hoàn thành',
        icon: CheckCircle2,
        class: 'border-emerald-200 bg-emerald-50 text-emerald-700',
    }
})

// Tiền thừa / thiếu
const balanceText = computed(() => {
    if (!props.invoice || isCancelled.value) return null

    const total = Number(saleTotal.value || 0)
    const paid = customerPaymentAmount.value
    const change = Math.max(0, Number(props.invoice.change_amount || 0))

    if (paid < total) {
        return {
            label: 'Còn thiếu',
            value: total - paid,
            class: 'text-rose-600',
        }
    }

    if (change > 0) {
        return {
            label: 'Tiền thừa',
            value: change,
            class: 'text-emerald-600',
        }
    }

    return {
        label: 'Đã thanh toán đủ',
        value: null,
        class: 'text-emerald-700',
    }
})

// Lý do hủy
const cancelReason = computed(() =>
    props.invoice?.cancel_reason
    || props.invoice?.reason
    || props.invoice?.cancellation_reason
    || 'Chưa ghi nhận lý do'
)
</script>

<template>
    <Teleport to="body">
    <div
        v-if="show"
        :class="layerClass" class="fixed inset-0 flex items-center justify-center bg-slate-950/60 p-2 sm:p-3 backdrop-blur-xs transition-opacity"
        @click.self="emit('close')"
    >
        <!-- NỀN MODAL DÙNG BG-SLATE-50 ĐỒNG BỘ VỚI HEADER VÀ DÙNG RING BẢO VỆ MÉP -->
        <div class="flex max-h-[92dvh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl bg-slate-50 shadow-2xl ring-1 ring-black/5">
            
            <!-- 1. HEADER CỐ ĐỊNH (MÀU NỀN ĐẶC BG-SLATE-50 VÀ KHÔNG BỊ HỞ VIỀN SÁNG) -->
            <div class="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3 shrink-0">
                <div class="flex items-center gap-2.5">
                    <div class="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 font-bold shrink-0">
                        <FileText :size="18" />
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-base font-extrabold text-slate-900">Chi tiết hóa đơn</h3>
                           
                            <span
                                v-if="invoice"
                                class="inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-bold"
                                :class="paymentStatusMeta.class"
                            >
                                <component :is="paymentStatusMeta.icon" :size="13" />
                                {{ paymentStatusMeta.label }}
                            </span>
                        </div>
                    </div>
                </div>

                <button
                    type="button"
                    class="rounded-lg p-1 text-slate-400 transition hover:bg-slate-200 hover:text-slate-700"
                    @click="emit('close')"
                >
                    <X :size="20" />
                </button>
            </div>

            <!-- 2. BODY SCROLLABLE (MÀU NỀN TRẮNG BG-WHITE BÊN TRONG) -->
            <div v-if="invoice" class="flex-1 overflow-y-auto bg-white p-3.5 space-y-3">
                
                <!-- KHỐI THÔNG BÁO HỦY ĐƠN -->
                <div
                    v-if="isCancelled"
                    class="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50/90 p-3 text-xs text-rose-800"
                >
                    <AlertTriangle :size="18" class="text-rose-600 shrink-0 mt-0.5" />
                    <div class="space-y-0.5">
                        <div class="font-bold text-sm">
                            Hóa đơn hủy do: <span class="italic font-semibold text-xs text-rose-700">{{ cancelReason }}</span>. {{ invoice.cancelled_at ? `lúc ${formatDate(invoice.cancelled_at)}` : '' }}
                        </div>
                        <div class="text-[11px] text-rose-500 italic">
                            * Toàn bộ sản phẩm và mã IMEI/Serial thuộc hóa đơn này đã được hoàn trả về kho.
                        </div>
                    </div>
                </div>

                <!-- THÔNG TIN CHUNG -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div class="rounded-xl border border-slate-200/80 bg-slate-50/60 p-2.5">
                        <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                            <Hash :size="12" /> Mã hóa đơn
                        </div>
                        <div class="mt-0.5 font-bold text-slate-900 text-sm">#{{ invoice.code }}</div>
                        <p v-if="invoice" class="mt-0.5 text-xs font-medium text-slate-500">
                            {{ formatDate(invoice.created_at) }}
                        </p>
                    </div>

                    <div class="rounded-xl border border-slate-200/80 bg-slate-50/60 p-2.5">
                        <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                            <User :size="12" /> Khách hàng
                        </div>
                        <div class="mt-0.5 font-bold text-slate-900 text-sm truncate">{{ customerName }}</div>
                        <div v-if="invoice.customer?.phone" class="text-xs text-slate-400 font-medium">
                            {{ invoice.customer.phone }}
                        </div>
                    </div>

                    <div class="rounded-xl border border-slate-200/80 bg-slate-50/60 p-2.5">
                        <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                            <UserCheck :size="12" /> Thu ngân
                        </div>
                        <div class="mt-0.5 font-bold text-slate-900 text-sm truncate">
                            {{ invoice.user?.name || '-' }}
                        </div>
                    </div>

                    <div class="rounded-xl border border-indigo-100 bg-indigo-50/60 p-2.5">
                        <div class="text-[10px] font-extrabold uppercase tracking-wider text-indigo-500 flex items-center gap-1">
                            <CreditCard :size="12" /> Tổng thanh toán
                        </div>
                        <div class="mt-0.5 font-black text-indigo-700 text-base">
                            {{ money(saleTotal) }}
                        </div>
                    </div>
                </div>

                <!-- BẢNG SẢN PHẨM -->
                <div class="overflow-hidden rounded-xl border border-slate-200/80 shadow-2xs bg-white">
                    <div class="overflow-x-auto">
                        <table class="m-cards w-full min-w-[700px] text-left text-xs border-collapse">
                            <thead>
                                <tr class="bg-slate-50 text-[11px] font-extrabold uppercase tracking-wider text-slate-500 border-b border-slate-200">
                                    <th class="w-10 px-3 py-2 text-center">STT</th>
                                    <th class="px-3 py-2">Sản phẩm</th>
                                    <th class="w-28 min-w-[100px] px-3 py-2 text-center whitespace-nowrap">Loại</th>
                                    <th class="w-24 px-3 py-2 text-center whitespace-nowrap">SL</th>
                                    <th class="w-28 px-3 py-2 text-right whitespace-nowrap">Đơn giá</th>
                                    <th class="w-32 px-3 py-2 text-right whitespace-nowrap">Thành tiền</th>
                                    <th v-if="showVatColumn" class="w-28 px-3 py-2 text-right whitespace-nowrap">VAT</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 font-medium text-xs">
                                <template
                                    v-for="(item, index) in invoice.items || []"
                                    :key="item.id || index"
                                >
                                    <tr class="hover:bg-slate-50/60 transition">
                                        <td class="px-3 py-2.5 text-center text-slate-400 font-bold" data-m-hide>
                                            {{ index + 1 }}
                                        </td>
                                        <td class="px-3 py-2.5" data-m-wide>
                                            <div class="min-w-0 w-full">
                                            <div class="font-bold text-slate-900 text-sm">
                                                <span class="mr-1 text-slate-400 md:hidden">{{ index + 1 }}.</span>{{ item.product?.name || item.product_name || '-' }}
                                            </div>

                                            <div class="mt-1.5 flex flex-wrap items-center gap-1.5">
                                            <div
                                                v-if="variantLabel(item.variant)"
                                                class="inline-flex items-center rounded-md bg-indigo-50 px-2 py-0.5 text-xs font-semibold text-indigo-700"
                                            >
                                                {{ variantLabel(item.variant) }}
                                            </div>

                                            <div v-if="item.product_imei?.imei || item.imei" class="inline-flex items-center gap-1.5">
                                                <span class="inline-flex items-center gap-1 whitespace-nowrap rounded-md bg-blue-50 px-2 py-0.5 text-xs font-mono font-bold text-blue-600 border border-blue-100">
                                                    <Tag :size="11" /> IMEI: {{ item.product_imei?.imei || item.imei }}
                                                </span>
                                                <span v-if="item.product_imei?.is_used" class="inline-flex shrink-0 items-center rounded-md border border-amber-300 bg-amber-100 px-1.5 py-0.5 align-middle text-[10px] font-bold not-italic text-amber-800 font-sans">CŨ</span>
                                            </div>

                                            <div v-if="item.product_imei?.customer_warranty_days !== null && item.product_imei?.customer_warranty_days !== undefined" class="inline-flex items-center gap-1.5">
                                                <span class="inline-flex items-center rounded-md bg-emerald-50 px-2 py-0.5 text-xs font-semibold" :class="warrantyEndDate(item) ? 'text-emerald-700' : 'text-slate-500'">
                                                {{ warrantyEndDate(item)
                                                    ? `Bảo hành đến ${warrantyEndDate(item)}`
                                                    : 'Không áp dụng bảo hành' }}
                                                </span>
                                                <button v-if="item.warranty_note" type="button" class="inline-flex h-6 w-6 items-center justify-center rounded-md text-slate-500 hover:bg-amber-50 hover:text-amber-700" :aria-label="`Xem ghi chú bảo hành ${item.product?.name || ''}`" :aria-expanded="openWarrantyNoteId === item.id" @click.stop="toggleWarrantyNote(item)">
                                                    <MessageSquare :size="14" />
                                                </button>
                                            </div>
                                            <div v-else-if="(item.warranty_days !== null && item.warranty_days !== undefined) || item.warranty_note" class="inline-flex items-center gap-1.5">
                                                <span v-if="item.warranty_days !== null && item.warranty_days !== undefined" class="inline-flex items-center rounded-md bg-emerald-50 px-2 py-0.5 text-xs font-semibold" :class="Number(item.warranty_days) > 0 ? 'text-emerald-700' : 'text-slate-500'">
                                                    {{ Number(item.warranty_days) > 0 && warrantyEndDate(item) ? `Bảo hành đến ${warrantyEndDate(item)}` : 'Không áp dụng bảo hành' }}
                                                </span>
                                                <button v-if="item.warranty_note" type="button" class="inline-flex h-6 w-6 items-center justify-center rounded-md text-slate-500 hover:bg-amber-50 hover:text-amber-700" :aria-label="`Xem ghi chú bảo hành ${item.product?.name || ''}`" :aria-expanded="openWarrantyNoteId === item.id" @click.stop="toggleWarrantyNote(item)">
                                                    <MessageSquare :size="14" />
                                                </button>
                                            </div>
                                            </div>
                                            <div v-if="item.warranty_note && openWarrantyNoteId === item.id" class="mt-1 max-w-sm rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs font-medium text-amber-900 whitespace-pre-line">
                                                {{ item.warranty_note }}
                                            </div>

                                            <div
                                                v-if="Number(item.discount_value || 0) > 0"
                                                class="mt-1 text-xs font-bold text-rose-600"
                                            >
                                                <template v-if="item.discount_type === 'percent'">
                                                    (Giảm {{ item.discount_value }}%)
                                                </template>
                                                <template v-else>
                                                    (Giảm {{ money(item.discount_value) }})
                                                </template>
                                            </div>

                                            <div v-if="item.note" class="mt-1 text-xs italic text-slate-400">
                                                Ghi chú: {{ item.note }}
                                            </div>
                                            </div>
                                        </td>

                                        <td class="px-3 py-2.5 text-center whitespace-nowrap" data-m-hide>
                                            <span class="inline-block rounded-full border border-blue-100 bg-blue-50 px-2.5 py-0.5 text-xs font-bold text-blue-600 whitespace-nowrap">
                                                Sản phẩm
                                            </span>
                                        </td>

                                        <td class="px-3 py-2.5 text-center font-bold text-slate-800 text-xs whitespace-nowrap">
                                            <div>{{ saleQuantityText(item) }}</div>
                                            <div
                                                v-if="baseQuantityText(item)"
                                                class="mt-0.5 text-[11px] font-semibold text-indigo-600"
                                            >
                                                {{ baseQuantityText(item) }}
                                            </div>
                                        </td>

                                        <td class="px-3 py-2.5 text-right font-medium text-slate-700 text-xs whitespace-nowrap">
                                            {{ money(item.unit_price) }}
                                        </td>

                                        <td class="px-3 py-2.5 text-right font-extrabold text-slate-900 text-sm whitespace-nowrap">
                                            {{ money(item.subtotal) }}
                                        </td>

                                        <td v-if="showVatColumn" class="px-3 py-2.5 text-right text-xs font-bold whitespace-nowrap" :class="lineVats[index] > 0 ? 'text-emerald-700' : 'text-slate-300'" :data-m-hide="lineVats[index] > 0 ? null : ''">
                                            {{ lineVats[index] > 0 ? money(lineVats[index]) : '—' }}
                                        </td>
                                    </tr>

                                    <!-- QUÀ TẶNG -->
                                    <tr
                                        v-for="(gift, giftIndex) in item.gifts || []"
                                        :key="`gift-${item.id || index}-${gift.id || giftIndex}`"
                                        class="bg-emerald-50/40 text-xs"
                                    >
                                        <td class="px-3 py-2 text-center text-slate-300" data-m-hide>-</td>
                                        <td class="px-3 py-2 text-emerald-800" data-m-wide>
                                            <span class="inline-flex items-center gap-1 font-bold">
                                                <Gift :size="13" class="text-emerald-600" />
                                                {{ gift.product?.name || gift.product_name || 'Quà tặng' }}
                                                <span class="rounded-full border border-emerald-200 bg-emerald-100/60 px-2 py-0.5 text-[10px] font-bold text-emerald-700 md:hidden">Quà tặng</span>
                                            </span>
                                        </td>
                                        <td class="px-3 py-2 text-center whitespace-nowrap" data-m-hide>
                                            <span class="inline-block rounded-full border border-emerald-200 bg-emerald-100/60 px-2.5 py-0.5 text-xs font-bold text-emerald-700 whitespace-nowrap">
                                                Quà tặng
                                            </span>
                                        </td>
                                        <td class="px-3 py-2 text-center font-bold text-slate-700">
                                            {{ gift.quantity || 1 }}
                                        </td>
                                        <td class="px-3 py-2 text-right text-xs text-slate-400 line-through whitespace-nowrap">
                                            {{ money(gift.product?.retail_price || gift.product?.sell_price || gift.product?.price) }}
                                        </td>
                                        <td class="px-3 py-2 text-right font-bold text-emerald-600 whitespace-nowrap">{{ money(0) }}</td>
                                        <td v-if="showVatColumn" data-m-hide></td>
                                    </tr>

                                    <tr v-if="item.gift_product" class="bg-emerald-50/40 text-xs">
                                        <td class="px-3 py-2 text-center text-slate-300" data-m-hide>-</td>
                                        <td class="px-3 py-2 text-emerald-800" data-m-wide>
                                            <span class="inline-flex items-center gap-1 font-bold">
                                                <Gift :size="13" class="text-emerald-600" />
                                                {{ item.gift_product.name }}
                                                <span class="rounded-full border border-emerald-200 bg-emerald-100/60 px-2 py-0.5 text-[10px] font-bold text-emerald-700 md:hidden">Quà tặng</span>
                                            </span>
                                        </td>
                                        <td class="px-3 py-2 text-center whitespace-nowrap" data-m-hide>
                                            <span class="inline-block rounded-full border border-emerald-200 bg-emerald-100/60 px-2.5 py-0.5 text-xs font-bold text-emerald-700 whitespace-nowrap">
                                                Quà tặng
                                            </span>
                                        </td>
                                        <td class="px-3 py-2 text-center font-bold text-slate-700">1</td>
                                        <td class="px-3 py-2 text-right text-xs text-slate-400 line-through whitespace-nowrap">
                                            {{ money(item.gift_product.retail_price || item.gift_product.sell_price || item.gift_product.price) }}
                                        </td>
                                        <td class="px-3 py-2 text-right font-bold text-emerald-600 whitespace-nowrap">{{ money(0) }}</td>
                                        <td v-if="showVatColumn" data-m-hide></td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- SẢN PHẨM ĐÃ HỦY RIÊNG LẺ -->
                <div v-if="cancelledItems.length" class="overflow-hidden rounded-xl border border-rose-200 bg-rose-50/50">
                    <div class="flex items-center gap-1.5 border-b border-rose-200 bg-rose-50 px-3 py-1.5 text-[11px] font-extrabold uppercase tracking-wider text-rose-700">
                        <XCircle :size="13" /> Sản phẩm đã hủy ({{ cancelledItems.length }})
                    </div>
                    <ul class="divide-y divide-rose-100 text-xs">
                        <li v-for="row in cancelledItems" :key="row.id" class="flex flex-wrap items-start justify-between gap-2 px-3 py-2">
                            <div class="min-w-0">
                                <div class="font-bold text-slate-600 line-through">{{ row.product_name }}<span v-if="row.variant_label" class="ml-1 font-semibold">({{ row.variant_label }})</span></div>
                                <div class="mt-0.5 text-[11px] text-slate-500">
                                    SL: {{ formatNumber(row.quantity) }}<span v-if="row.unit_name"> {{ row.unit_name }}</span>
                                    <span v-if="row.imeis?.length"> · IMEI: <span class="font-mono">{{ row.imeis.join(', ') }}</span></span>
                                </div>
                                <div class="mt-0.5 text-[11px] italic text-rose-700">
                                    Lý do: {{ row.reason || '—' }}<span v-if="row.cancelled_at"> · {{ formatDate(row.cancelled_at) }}</span>
                                </div>
                            </div>
                            <div class="font-bold text-slate-500 line-through whitespace-nowrap">{{ money(row.amount) }}</div>
                        </li>
                    </ul>
                </div>

                <!-- TỔNG TÍNH TIỀN & GHI CHÚ -->
                <div class="grid gap-2.5 lg:grid-cols-[1fr_320px]">
                    <div class="rounded-xl border border-slate-200/80 bg-slate-50/50 p-2.5 text-xs">
                        <div class="font-extrabold uppercase text-[10px] tracking-wider text-slate-400 flex items-center gap-1 mb-1">
                            <MessageSquare :size="12" /> Ghi chú đơn hàng
                        </div>
                        <div class="text-slate-700 font-medium italic text-xs">
                            {{ invoice.note || 'Không có ghi chú.' }}
                        </div>
                    </div>

                    <div class="rounded-xl border border-slate-200/80 p-3 text-xs space-y-1.5 bg-white">
                        <div class="flex justify-between text-slate-500">
                            <span>Tiền hàng:</span>
                            <span class="font-semibold text-slate-800 text-xs">{{ money(invoice.subtotal) }}</span>
                        </div>

                        <div
                            v-if="Number(invoice.discount || 0) > 0"
                            class="flex justify-between text-rose-600 font-medium"
                        >
                            <span>Chiết khấu sản phẩm:</span>
                            <span>-{{ money(invoice.discount) }}</span>
                        </div>

                        <div v-if="Number(invoice.invoice_discount || 0) > 0" class="flex justify-between text-rose-600 font-medium"><span>Chiết khấu đơn:</span><span>-{{ money(invoice.invoice_discount) }}</span></div>
                        <div v-if="Number(invoice.tax || 0) > 0" class="flex justify-between text-emerald-700 font-medium"><span>VAT:</span><span>{{ money(invoice.tax) }}</span></div>
                        <div v-else-if="invoice.items?.some(item => item.has_vat)" class="flex justify-between text-slate-500 font-medium"><span>Nhãn VAT hàng nhập:</span><span>Chỉ để nhận biết</span></div>
                        <div v-if="Number(invoice.extra_fee || 0) > 0" class="flex justify-between text-slate-600 font-medium"><span>Phí phụ thu:</span><span>{{ money(invoice.extra_fee) }}</span></div>

                        <div class="flex justify-between items-center border-t border-slate-200/80 pt-1.5 text-sm">
                            <span class="font-bold text-slate-900">Tổng thanh toán:</span>
                            <span class="font-black text-indigo-600 text-base">{{ money(saleTotal) }}</span>
                        </div>

                        <div v-for="payment in customerPaymentRows" :key="payment.label" class="flex justify-between text-slate-600 border-t border-dashed border-slate-100 pt-1">
                            <span>{{ payment.label }}:</span>
                            <span class="font-bold text-slate-800">{{ money(payment.amount) }}</span>
                        </div>

                        <div v-if="Number(invoice.old_debt_paid || 0) > 0" class="flex justify-between text-blue-700">
                            <span>Trích trả nợ cũ:</span>
                            <span class="font-bold">{{ money(invoice.old_debt_paid) }}</span>
                        </div>

                        <div
                            v-if="balanceText"
                            class="flex justify-between font-bold pt-0.5"
                            :class="balanceText.class"
                        >
                            <span>{{ balanceText.label }}:</span>
                            <span v-if="balanceText.value !== null">{{ money(balanceText.value) }}</span>
                        </div>

                        <div class="flex justify-between text-[11px] uppercase text-slate-400 pt-1 border-t border-slate-100">
                            <span>Phương thức:</span>
                            <span class="font-bold text-slate-700">{{ paymentMethodLabel(effectivePaymentMethod(invoice)) }}</span>
                        </div>
                    </div>
                </div>

            </div>

            <!-- 3. FOOTER CỐ ĐỊNH (MÀU NỀN ĐẶC BG-SLATE-50) -->
            <div class="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-4 py-2.5 shrink-0">
                <div>
                    <button
                        v-if="canCancel && invoice && !isCancelled"
                        type="button"
                        class="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3.5 py-1.5 text-xs font-bold text-rose-600 transition hover:bg-rose-50 active:scale-95"
                        @click="emit('cancel', invoice)"
                    >
                        <Undo2 :size="14" />
                        Hủy hóa đơn
                    </button>
                </div>

                <div class="flex items-center gap-2">
                    <button
                        v-if="canEdit && invoice && !isCancelled"
                        type="button"
                        class="inline-flex items-center gap-1.5 rounded-xl border border-amber-200 bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-700 transition hover:bg-amber-100 active:scale-95"
                        title="Sửa hóa đơn"
                        aria-label="Sửa hóa đơn"
                        @click="emit('edit', invoice)"
                    >
                        <SquarePen :size="14" />
                        <span class="hidden sm:inline">Sửa</span>
                    </button>

                    <button
                        type="button"
                        class="rounded-xl border border-slate-200 bg-white px-4 py-1.5 text-xs font-bold text-slate-700 transition hover:bg-slate-100"
                        @click="emit('close')"
                    >
                        Đóng
                    </button>
                    
                    <button
                        v-if="canPrint && invoice && !isCancelled"
                        type="button"
                        class="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white shadow-xs transition hover:bg-indigo-700 active:scale-95"
                        @click="emit('print', invoice)"
                    >
                        <Printer :size="14" />
                        In hóa đơn
                    </button>
                </div>
            </div>

        </div>
    </div>
    </Teleport>
</template>
